# Guia de Migração para Backend Seguro - ClareoIA

Este documento apresenta estratégias para proteger o código da plataforma ClareoIA, migrando a lógica sensível para um backend seguro sem grandes alterações estruturais.

## Opções de Migração

### 1. Node.js (Recomendado)

**Vantagens:**
- Segurança robusta
- Mesma linguagem (JavaScript) no frontend e backend
- Escalabilidade
- Suporte a APIs RESTful
- Fácil integração com bancos de dados

**Estrutura Proposta:**
```
clareoia/
├── backend/
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── userController.js
│   │   ├── promptController.js
│   │   └── integrationController.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Prompt.js
│   │   └── Training.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── users.js
│   │   ├── prompts.js
│   │   └── integrations.js
│   ├── middleware/
│   │   ├── auth.js
│   │   └── admin.js
│   ├── config/
│   │   └── database.js
│   ├── server.js
│   └── package.json
└── frontend/
    ├── css/
    ├── js/
    │   ├── api.js (novo - para comunicação com backend)
    │   └── ui.js (mantém apenas lógica de UI)
    ├── admin/
    ├── index.html
    ├── login.html
    └── painel.html
```

**Exemplo de Implementação:**

1. **Backend (server.js):**
```javascript
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const promptRoutes = require('./routes/prompts');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('../frontend'));

// Rotas
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/prompts', promptRoutes);

// Conexão com banco de dados
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/clareoia')
  .then(() => {
    console.log('Conectado ao MongoDB');
    app.listen(PORT, () => {
      console.log(`Servidor rodando na porta ${PORT}`);
    });
  })
  .catch(err => console.error('Erro ao conectar ao MongoDB:', err));
```

2. **Rota de Autenticação (routes/auth.js):**
```javascript
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/auth');

router.post('/login', authController.login);
router.post('/register', authController.register);
router.post('/logout', authController.logout);
router.get('/verify', authMiddleware, authController.verifyToken);

module.exports = router;
```

3. **Controlador de Autenticação (controllers/authController.js):**
```javascript
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const JWT_SECRET = process.env.JWT_SECRET || 'clareoia-secret-key';
const TOKEN_EXPIRY = '30m'; // 30 minutos

exports.login = async (req, res) => {
  try {
    const { email, senha } = req.body;
    
    // Busca usuário no banco de dados
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(401).json({ success: false, message: 'Usuário não encontrado' });
    }
    
    // Verifica senha
    const isMatch = await bcrypt.compare(senha, user.senha);
    
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Senha incorreta' });
    }
    
    // Gera token JWT
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: TOKEN_EXPIRY }
    );
    
    // Remove senha do objeto de resposta
    const userResponse = {
      id: user._id,
      nome: user.nome,
      email: user.email,
      role: user.role
    };
    
    res.json({
      success: true,
      message: 'Login realizado com sucesso',
      token,
      user: userResponse
    });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ success: false, message: 'Erro no servidor' });
  }
};

// Implementar demais métodos (register, logout, verifyToken)
```

4. **Frontend (js/api.js):**
```javascript
// API Client para comunicação com backend
const API_URL = '/api';

// Armazenamento de token
const setToken = (token) => {
  localStorage.setItem('clareoia_auth_token', token);
};

const getToken = () => {
  return localStorage.getItem('clareoia_auth_token');
};

const removeToken = () => {
  localStorage.removeItem('clareoia_auth_token');
};

// Configuração de headers para requisições autenticadas
const authHeaders = () => {
  const token = getToken();
  return {
    'Content-Type': 'application/json',
    'Authorization': token ? `Bearer ${token}` : ''
  };
};

// Funções de API
const api = {
  // Autenticação
  login: async (email, senha) => {
    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, senha })
      });
      
      const data = await response.json();
      
      if (data.success && data.token) {
        setToken(data.token);
        localStorage.setItem('clareoia_current_user', JSON.stringify(data.user));
      }
      
      return data;
    } catch (error) {
      console.error('Erro no login:', error);
      return { success: false, message: 'Erro de conexão' };
    }
  },
  
  logout: async () => {
    try {
      await fetch(`${API_URL}/auth/logout`, {
        method: 'POST',
        headers: authHeaders()
      });
      
      removeToken();
      localStorage.removeItem('clareoia_current_user');
      
      return { success: true };
    } catch (error) {
      console.error('Erro no logout:', error);
      return { success: false, message: 'Erro de conexão' };
    }
  },
  
  verificarAutenticacao: async () => {
    try {
      const response = await fetch(`${API_URL}/auth/verify`, {
        headers: authHeaders()
      });
      
      if (response.status === 401) {
        removeToken();
        localStorage.removeItem('clareoia_current_user');
        return false;
      }
      
      return response.status === 200;
    } catch (error) {
      console.error('Erro ao verificar autenticação:', error);
      return false;
    }
  },
  
  // Implementar demais métodos para usuários, prompts, etc.
};

// Exporta para uso global
window.api = api;
```

### 2. PHP (Alternativa Simples)

**Vantagens:**
- Fácil implementação em servidores compartilhados
- Não requer conhecimento de Node.js
- Boa compatibilidade com servidores existentes

**Estrutura Proposta:**
```
clareoia/
├── api/
│   ├── auth.php
│   ├── users.php
│   ├── prompts.php
│   └── integrations.php
├── includes/
│   ├── config.php
│   ├── database.php
│   ├── auth.php
│   └── functions.php
├── admin/
│   ├── login.php (convertido de login.html)
│   └── painel.php (convertido de painel.html)
├── css/
├── js/
│   └── ui.js (mantém apenas lógica de UI)
├── index.php (convertido de index.html)
├── login.php (convertido de login.html)
└── painel.php (convertido de painel.html)
```

**Exemplo de Implementação:**

1. **Configuração (includes/config.php):**
```php
<?php
// Configurações do banco de dados
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'clareoia');

// Configurações de autenticação
define('AUTH_TOKEN_KEY', 'clareoia_auth_token');
define('TOKEN_EXPIRY', 1800); // 30 minutos em segundos

// Iniciar sessão
session_start();

// Conexão com o banco de dados
require_once 'database.php';

// Funções de autenticação
require_once 'auth.php';

// Funções utilitárias
require_once 'functions.php';
?>
```

2. **Autenticação (includes/auth.php):**
```php
<?php
// Função para gerar token de autenticação
function generateAuthToken($userId) {
    $now = time();
    $expiry = $now + TOKEN_EXPIRY;
    $nonce = bin2hex(random_bytes(8));
    
    $tokenData = [
        'userId' => $userId,
        'timestamp' => $now,
        'expiry' => $expiry,
        'nonce' => $nonce
    ];
    
    // Em um ambiente real, este token seria criptografado
    $token = base64_encode(json_encode($tokenData));
    return $token;
}

// Função para verificar validade do token
function verifyAuthToken($token) {
    try {
        $tokenData = json_decode(base64_decode($token), true);
        $now = time();
        
        // Verifica se o token expirou
        if ($tokenData['expiry'] < $now) {
            return false;
        }
        
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// Função para fazer login
function fazerLogin($email, $senha) {
    global $conn;
    
    // Busca o usuário no banco de dados
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'Usuário não encontrado'];
    }
    
    $usuario = $result->fetch_assoc();
    
    // Verifica a senha (em um ambiente real, usaria password_verify)
    if ($usuario['senha'] !== $senha) {
        return ['success' => false, 'message' => 'Senha incorreta'];
    }
    
    // Gera token de autenticação
    $token = generateAuthToken($usuario['id']);
    $_SESSION[AUTH_TOKEN_KEY] = $token;
    
    // Remove a senha do objeto de usuário
    unset($usuario['senha']);
    $_SESSION['current_user'] = $usuario;
    
    return ['success' => true, 'message' => 'Login realizado com sucesso', 'user' => $usuario];
}

// Função para verificar autenticação
function verificarAutenticacao() {
    if (!isset($_SESSION[AUTH_TOKEN_KEY])) {
        return false;
    }
    
    $token = $_SESSION[AUTH_TOKEN_KEY];
    $isValid = verifyAuthToken($token);
    
    if (!$isValid) {
        // Remove o token inválido
        unset($_SESSION[AUTH_TOKEN_KEY]);
        unset($_SESSION['current_user']);
        return false;
    }
    
    return true;
}

// Função para verificar se o usuário é admin
function verificarAdmin() {
    if (!verificarAutenticacao()) {
        return false;
    }
    
    $currentUser = $_SESSION['current_user'];
    return isset($currentUser['role']) && $currentUser['role'] === 'admin';
}

// Função para fazer logout
function fazerLogout() {
    unset($_SESSION[AUTH_TOKEN_KEY]);
    unset($_SESSION['current_user']);
    session_destroy();
}

// Função para proteger páginas que requerem autenticação
function protegerPagina() {
    if (!verificarAutenticacao()) {
        header('Location: login.php');
        exit;
    }
}

// Função para proteger páginas administrativas
function protegerPaginaAdmin() {
    if (!verificarAdmin()) {
        header('Location: ../login.php');
        exit;
    }
}
?>
```

3. **API de Autenticação (api/auth.php):**
```php
<?php
require_once '../includes/config.php';

// Define o tipo de conteúdo como JSON
header('Content-Type: application/json');

// Obtém o método HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Rota de login
if ($method === 'POST' && isset($_GET['action']) && $_GET['action'] === 'login') {
    // Obtém os dados do corpo da requisição
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['email']) || !isset($data['senha'])) {
        echo json_encode(['success' => false, 'message' => 'Dados incompletos']);
        exit;
    }
    
    $resultado = fazerLogin($data['email'], $data['senha']);
    echo json_encode($resultado);
    exit;
}

// Rota de logout
if ($method === 'POST' && isset($_GET['action']) && $_GET['action'] === 'logout') {
    fazerLogout();
    echo json_encode(['success' => true, 'message' => 'Logout realizado com sucesso']);
    exit;
}

// Rota de verificação de autenticação
if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'verify') {
    $isAuthenticated = verificarAutenticacao();
    
    if ($isAuthenticated) {
        echo json_encode(['success' => true, 'user' => $_SESSION['current_user']]);
    } else {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    }
    exit;
}

// Rota não encontrada
http_response_code(404);
echo json_encode(['success' => false, 'message' => 'Rota não encontrada']);
?>
```

4. **Página de Login (login.php):**
```php
<?php
require_once 'includes/config.php';

// Verifica se já existe uma sessão ativa
if (verificarAutenticacao()) {
    $usuario = $_SESSION['current_user'];
    if (isset($usuario['role']) && $usuario['role'] === 'admin') {
        header('Location: admin/painel.php');
    } else {
        header('Location: painel.php');
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Clareo IA</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="login-header">
                <img src="img/clareo.png" alt="Clareo IA" class="logo">
                <h1>Acesse sua conta</h1>
                <p>Entre para descobrir insights comportamentais poderosos</p>
            </div>
            
            <div class="login-form-container">
                <form id="login-form" class="login-form">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Seu email" required autofocus>
                    </div>
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" id="senha" name="senha" placeholder="Sua senha" required>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn primary-btn">
                            <i class="fas fa-sign-in-alt"></i> Entrar
                        </button>
                    </div>
                </form>
                
                <div class="login-options">
                    <a href="recuperar-senha.php" class="forgot-password">Esqueceu sua senha?</a>
                    <a href="cadastro.php" class="register-link">Não tem uma conta? Cadastre-se</a>
                </div>
                
                <div class="social-login">
                    <p>Ou entre com</p>
                    <div class="social-buttons">
                        <button class="social-btn google-btn" id="google-login-btn">
                            <i class="fab fa-google"></i> Google
                        </button>
                        <button class="social-btn github-btn" id="github-login-btn">
                            <i class="fab fa-github"></i> GitHub
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('login-form');
            
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const email = document.getElementById('email').value;
                const senha = document.getElementById('senha').value;
                
                // Envia requisição para a API
                fetch('api/auth.php?action=login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email, senha })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Redireciona com base no papel do usuário
                        if (data.user.role === 'admin') {
                            window.location.href = 'admin/painel.php';
                        } else {
                            window.location.href = 'painel.php';
                        }
                    } else {
                        // Exibe mensagem de erro
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao fazer login. Tente novamente.');
                });
            });
            
            // Configura os botões de login social
            document.getElementById('google-login-btn').addEventListener('click', function() {
                // Implementar login social com Google
                alert('Login com Google será implementado em breve.');
            });
            
            document.getElementById('github-login-btn').addEventListener('click', function() {
                // Implementar login social com GitHub
                alert('Login com GitHub será implementado em breve.');
            });
        });
    </script>
</body>
</html>
```

## Passos para Migração

### Migração para Node.js

1. **Preparação:**
   - Instalar Node.js e npm
   - Criar estrutura de diretórios para backend
   - Inicializar projeto com `npm init`
   - Instalar dependências: `npm install express mongoose jsonwebtoken bcryptjs cors dotenv`

2. **Migração de Dados:**
   - Criar modelos de dados (schemas) no MongoDB
   - Migrar dados do localStorage para o banco de dados
   - Implementar scripts de migração

3. **Implementação do Backend:**
   - Criar rotas de API
   - Implementar controladores
   - Configurar middleware de autenticação
   - Testar endpoints com Postman ou similar

4. **Adaptação do Frontend:**
   - Criar arquivo api.js para comunicação com backend
   - Substituir chamadas diretas ao localStorage por chamadas à API
   - Manter a estrutura de UI existente

5. **Testes e Implantação:**
   - Testar fluxos de autenticação
   - Verificar persistência de dados
   - Implantar em servidor com Node.js

### Migração para PHP

1. **Preparação:**
   - Configurar servidor web com PHP
   - Criar estrutura de diretórios
   - Configurar banco de dados MySQL

2. **Migração de Dados:**
   - Criar tabelas no MySQL
   - Migrar dados do localStorage para o banco de dados
   - Implementar scripts de migração

3. **Implementação do Backend:**
   - Converter arquivos HTML para PHP
   - Implementar funções de autenticação
   - Criar endpoints de API

4. **Adaptação do Frontend:**
   - Ajustar chamadas JavaScript para usar a API PHP
   - Manter a estrutura de UI existente

5. **Testes e Implantação:**
   - Testar fluxos de autenticação
   - Verificar persistência de dados
   - Implantar em servidor com PHP

## Recomendações Finais

1. **Segurança:**
   - Usar HTTPS para todas as comunicações
   - Implementar proteção contra CSRF
   - Sanitizar todas as entradas de usuário
   - Usar prepared statements para consultas SQL

2. **Performance:**
   - Implementar cache para reduzir consultas ao banco de dados
   - Otimizar consultas e índices
   - Considerar CDN para arquivos estáticos

3. **Manutenção:**
   - Documentar APIs
   - Implementar logs para depuração
   - Criar testes automatizados

4. **Escalabilidade:**
   - Considerar arquitetura de microserviços para crescimento futuro
   - Implementar balanceamento de carga
   - Planejar estratégia de backup e recuperação

A migração para um backend seguro é um passo importante para proteger seu código e dados. Embora exija algum esforço inicial, os benefícios em termos de segurança, escalabilidade e manutenção compensam o investimento.
