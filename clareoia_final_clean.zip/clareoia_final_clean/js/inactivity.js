// Função para monitorar inatividade e fazer logout automático
function iniciarMonitorInatividade() {
    // Tempo de inatividade em milissegundos (30 minutos)
    const TEMPO_INATIVIDADE = 30 * 60 * 1000;
    let temporizadorInatividade;
    
    // Função para resetar o temporizador
    function resetarTemporizador() {
        // Limpa o temporizador existente
        if (temporizadorInatividade) {
            clearTimeout(temporizadorInatividade);
        }
        
        // Define um novo temporizador
        temporizadorInatividade = setTimeout(() => {
            console.log("Sessão expirada por inatividade");
            // Exibe notificação
            if (typeof showNotification === 'function') {
                showNotification("Sua sessão expirou por inatividade. Você será redirecionado para a página de login.", "warning");
            } else {
                alert("Sua sessão expirou por inatividade. Você será redirecionado para a página de login.");
            }
            
            // Faz logout após 2 segundos (para dar tempo de ver a notificação)
            setTimeout(() => {
                if (typeof fazerLogout === 'function') {
                    fazerLogout();
                } else {
                    // Fallback caso a função não esteja disponível
                    localStorage.removeItem("clareoia_auth_token");
                    localStorage.removeItem("clareoia_current_user");
                    window.location.href = window.location.pathname.includes('/admin/') ? '../login.html' : 'login.html';
                }
            }, 2000);
        }, TEMPO_INATIVIDADE);
    }
    
    // Eventos que resetam o temporizador
    const eventos = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    
    // Adiciona listeners para cada evento
    eventos.forEach(evento => {
        document.addEventListener(evento, resetarTemporizador, false);
    });
    
    // Inicia o temporizador
    resetarTemporizador();
    
    console.log("Monitor de inatividade iniciado. Logout automático após 30 minutos de inatividade.");
}

// Exporta a função para o escopo global
window.iniciarMonitorInatividade = iniciarMonitorInatividade;
