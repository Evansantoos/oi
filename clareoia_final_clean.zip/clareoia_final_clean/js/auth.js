// Funções de autenticação e gerenciamento de usuários
const AUTH_TOKEN_KEY = "clareoia_auth_token";
const DB_CURRENT_USER_KEY = "clareoia_current_user";
const REDIRECT_COUNT_KEY = "clareoia_redirect_count";
const MAX_REDIRECTS = 3; // Limite máximo de redirecionamentos consecutivos
const TOKEN_EXPIRY = 30 * 60 * 1000; // 30 minutos em milissegundos

// Banco de dados simulado
let usuariosDB = [
    {
        id: 1,
        nome: "Usuário Teste",
        email: "teste@exemplo.com",
        senha: "senha123",
        role: "user"
    },
    {
        id: 2,
        nome: "Admin",
        email: "admin@startinc.com.br",
        senha: "admin2025",
        role: "admin"
    }
];

// Função para gerar token de autenticação
function generateAuthToken(userId) {
    const now = new Date().getTime();
    const expiry = now + TOKEN_EXPIRY;
    const nonce = Math.random().toString(36).substring(2, 15);
    
    const tokenData = {
        userId: userId,
        timestamp: now,
        expiry: expiry,
        nonce: nonce
    };
    
    // Em um ambiente real, este token seria criptografado
    const token = btoa(JSON.stringify(tokenData));
    return token;
}

// Função para verificar validade do token
function verifyAuthToken(token) {
    try {
        const tokenData = JSON.parse(atob(token));
        const now = new Date().getTime();
        
        // Verifica se o token expirou
        if (tokenData.expiry < now) {
            console.log("Token expirado");
            return false;
        }
        
        // Verifica se o token está próximo de expirar (menos de 10 minutos)
        if (tokenData.expiry - now < 10 * 60 * 1000) {
            console.log("Token próximo de expirar, renovando...");
            // Renova o token
            const newToken = generateAuthToken(tokenData.userId);
            localStorage.setItem(AUTH_TOKEN_KEY, newToken);
        }
        
        return true;
    } catch (error) {
        console.error("Erro ao verificar token:", error);
        return false;
    }
}

// Função para fazer login
function fazerLogin(email, senha) {
    console.log(`Tentando login com email: ${email}`);
    
    // Busca o usuário no banco de dados
    const usuario = usuariosDB.find(u => u.email === email);
    
    if (!usuario) {
        return { success: false, message: "Usuário não encontrado" };
    }
    
    if (usuario.senha !== senha) {
        return { success: false, message: "Senha incorreta" };
    }
    
    // Gera token de autenticação
    const token = generateAuthToken(usuario.id);
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    
    // Salva dados do usuário no localStorage (sem a senha)
    const userData = { ...usuario };
    delete userData.senha;
    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(userData));
    
    console.log("Login bem-sucedido:", userData);
    return { success: true, message: "Login realizado com sucesso", user: userData };
}

// Função para login social (Google, GitHub)
function loginSocial(provider) {
    console.log(`Iniciando login com ${provider}...`);
    
    // Simulação de login social
    setTimeout(() => {
        // Gera um ID aleatório para o usuário
        const userId = Math.floor(Math.random() * 1000) + 100;
        
        // Cria um usuário fictício
        const usuario = {
            id: userId,
            nome: `Usuário ${provider}`,
            email: `usuario_${userId}@${provider.toLowerCase()}.com`,
            role: "user",
            provider: provider
        };
        
        // Gera token de autenticação
        const token = generateAuthToken(usuario.id);
        localStorage.setItem(AUTH_TOKEN_KEY, token);
        
        // Salva dados do usuário no localStorage
        localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(usuario));
        
        console.log(`Login com ${provider} bem-sucedido:`, usuario);
        
        // Reseta o contador de redirecionamentos
        resetRedirectCount();
        
        // Redireciona para o painel
        window.location.href = 'painel.html';
    }, 1000);
}

// Função para verificar autenticação
function verificarAutenticacao() {
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    
    if (!token) {
        console.log("Token não encontrado");
        return false;
    }
    
    const isValid = verifyAuthToken(token);
    
    if (!isValid) {
        console.log("Token inválido, removendo...");
        localStorage.removeItem(AUTH_TOKEN_KEY);
        return false;
    }
    
    // Verifica se os dados do usuário estão presentes
    const currentUser = localStorage.getItem(DB_CURRENT_USER_KEY);
    
    if (!currentUser) {
        console.log("Dados do usuário não encontrados, tentando recuperar...");
        
        // Tenta recuperar os dados do usuário a partir do token
        try {
            const tokenData = JSON.parse(atob(token));
            const userId = tokenData.userId;
            
            // Busca o usuário no banco de dados
            const usuario = usuariosDB.find(u => u.id === userId);
            
            if (usuario) {
                // Salva dados do usuário no localStorage (sem a senha)
                const userData = { ...usuario };
                delete userData.senha;
                localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(userData));
                console.log("Dados do usuário recuperados com sucesso");
                return true;
            } else {
                console.log("Usuário não encontrado no banco de dados");
                localStorage.removeItem(AUTH_TOKEN_KEY);
                return false;
            }
        } catch (error) {
            console.error("Erro ao recuperar dados do usuário:", error);
            localStorage.removeItem(AUTH_TOKEN_KEY);
            return false;
        }
    }
    
    return true;
}

// Função para verificar se o usuário é admin
function verificarAdmin() {
    if (!verificarAutenticacao()) {
        return false;
    }
    
    const currentUser = getUsuarioAtual();
    return currentUser && currentUser.role === 'admin';
}

// Função para obter o usuário atual
function getUsuarioAtual() {
    const currentUserStr = localStorage.getItem(DB_CURRENT_USER_KEY);
    
    if (!currentUserStr) {
        return null;
    }
    
    try {
        return JSON.parse(currentUserStr);
    } catch (error) {
        console.error("Erro ao obter usuário atual:", error);
        return null;
    }
}

// Função para fazer logout
function fazerLogout() {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(DB_CURRENT_USER_KEY);
    window.location.href = 'login.html';
}

// Função para proteger páginas que requerem autenticação
function protegerPagina() {
    if (!verificarAutenticacao()) {
        console.log("Usuário não autenticado, redirecionando para login...");
        
        // Incrementa o contador de redirecionamentos
        incrementRedirectCount();
        
        // Redireciona para a página de login
        window.location.href = 'login.html';
        return false;
    }
    
    // Reseta o contador de redirecionamentos
    resetRedirectCount();
    
    // Inicia o timer de inatividade
    iniciarTimerInatividade();
    
    return true;
}

// Função para proteger páginas administrativas
function protegerPaginaAdmin() {
    if (!verificarAdmin()) {
        console.log("Usuário não é admin, redirecionando para login...");
        
        // Incrementa o contador de redirecionamentos
        incrementRedirectCount();
        
        // Redireciona para a página de login
        window.location.href = '../login.html';
        return false;
    }
    
    // Reseta o contador de redirecionamentos
    resetRedirectCount();
    
    // Inicia o timer de inatividade
    iniciarTimerInatividade();
    
    return true;
}

// Função para incrementar o contador de redirecionamentos
function incrementRedirectCount() {
    let count = parseInt(localStorage.getItem(REDIRECT_COUNT_KEY) || "0");
    count++;
    localStorage.setItem(REDIRECT_COUNT_KEY, count.toString());
    
    // Se exceder o limite máximo, mostra um alerta e para o redirecionamento
    if (count >= MAX_REDIRECTS) {
        console.error("Detectado loop de redirecionamento!");
        alert("Detectamos um problema de redirecionamento. Por favor, limpe o cache do navegador e tente novamente.");
        localStorage.setItem(REDIRECT_COUNT_KEY, "0");
        return false;
    }
    
    return true;
}

// Função para resetar o contador de redirecionamentos
function resetRedirectCount() {
    localStorage.setItem(REDIRECT_COUNT_KEY, "0");
}

// Função para iniciar o timer de inatividade (logout após 30 minutos)
let inactivityTimer;
function iniciarTimerInatividade() {
    // Limpa o timer anterior, se existir
    if (inactivityTimer) {
        clearTimeout(inactivityTimer);
    }
    
    // Define o novo timer
    inactivityTimer = setTimeout(() => {
        console.log("Sessão expirada por inatividade");
        fazerLogout();
    }, TOKEN_EXPIRY);
    
    // Reseta o timer em eventos de atividade do usuário
    const resetTimer = () => {
        iniciarTimerInatividade();
    };
    
    // Adiciona listeners para eventos de atividade
    document.addEventListener('mousemove', resetTimer);
    document.addEventListener('keypress', resetTimer);
    document.addEventListener('click', resetTimer);
    document.addEventListener('scroll', resetTimer);
}

// Exporta funções para o escopo global
window.fazerLogin = fazerLogin;
window.loginSocial = loginSocial;
window.verificarAutenticacao = verificarAutenticacao;
window.verificarAdmin = verificarAdmin;
window.getUsuarioAtual = getUsuarioAtual;
window.fazerLogout = fazerLogout;
window.protegerPagina = protegerPagina;
window.protegerPaginaAdmin = protegerPaginaAdmin;
window.resetRedirectCount = resetRedirectCount;
