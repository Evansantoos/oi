// Gerenciamento da base de conhecimento
// Implementação de acesso e permissões por plano

// Chaves para armazenamento no localStorage
const DB_KNOWLEDGE_KEY = "clareoia_knowledge";
const DB_USER_QUESTIONS_KEY = "clareoia_user_questions";

// Inicializar banco de dados de conhecimento
function initializeKnowledgeDB() {
  // Inicializar base de conhecimento se não existir
  if (!localStorage.getItem(DB_KNOWLEDGE_KEY)) {
    localStorage.setItem(DB_KNOWLEDGE_KEY, JSON.stringify({
      categories: [
        {
          id: "comportamental",
          nome: "Comportamental",
          descricao: "Perguntas sobre comportamento e perfil"
        },
        {
          id: "profissional",
          nome: "Profissional",
          descricao: "Perguntas sobre carreira e desenvolvimento"
        },
        {
          id: "lideranca",
          nome: "Liderança",
          descricao: "Perguntas sobre gestão e liderança"
        }
      ],
      questions: [
        {
          id: "q1",
          pergunta: "Como você reage a situações de pressão?",
          categoria: "comportamental",
          criador: "admin",
          dataCriacao: "2025-01-01T00:00:00.000Z",
          ativo: true
        },
        {
          id: "q2",
          pergunta: "Qual sua maior conquista profissional?",
          categoria: "profissional",
          criador: "admin",
          dataCriacao: "2025-01-01T00:00:00.000Z",
          ativo: true
        },
        {
          id: "q3",
          pergunta: "Como você motiva sua equipe?",
          categoria: "lideranca",
          criador: "admin",
          dataCriacao: "2025-01-01T00:00:00.000Z",
          ativo: true
        }
      ]
    }));
  }

  // Inicializar perguntas de usuários se não existir
  if (!localStorage.getItem(DB_USER_QUESTIONS_KEY)) {
    localStorage.setItem(DB_USER_QUESTIONS_KEY, JSON.stringify([]));
  }
}

// API de Base de Conhecimento
const KnowledgeAPI = {
  // Obter todas as categorias
  getCategories: function() {
    initializeKnowledgeDB();
    const knowledge = JSON.parse(localStorage.getItem(DB_KNOWLEDGE_KEY));
    return knowledge.categories;
  },

  // Obter categoria por ID
  getCategoryById: function(categoryId) {
    const categories = this.getCategories();
    return categories.find(cat => cat.id === categoryId);
  },

  // Criar ou atualizar categoria
  saveOrUpdateCategory: function(categoryData) {
    initializeKnowledgeDB();
    const knowledge = JSON.parse(localStorage.getItem(DB_KNOWLEDGE_KEY));
    
    // Validar dados da categoria
    if (!categoryData.id || !categoryData.nome) {
      return {
        success: false,
        error: 'ID e nome da categoria são obrigatórios'
      };
    }
    
    // Verificar se a categoria já existe
    const index = knowledge.categories.findIndex(cat => cat.id === categoryData.id);
    
    if (index >= 0) {
      // Atualizar categoria existente
      knowledge.categories[index] = categoryData;
    } else {
      // Adicionar nova categoria
      knowledge.categories.push(categoryData);
    }
    
    localStorage.setItem(DB_KNOWLEDGE_KEY, JSON.stringify(knowledge));
    
    return {
      success: true,
      category: categoryData
    };
  },

  // Excluir categoria
  deleteCategory: function(categoryId) {
    initializeKnowledgeDB();
    const knowledge = JSON.parse(localStorage.getItem(DB_KNOWLEDGE_KEY));
    
    // Verificar se a categoria existe
    const index = knowledge.categories.findIndex(cat => cat.id === categoryId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Categoria não encontrada'
      };
    }
    
    // Verificar se há perguntas nesta categoria
    const hasQuestions = knowledge.questions.some(q => q.categoria === categoryId);
    
    if (hasQuestions) {
      return {
        success: false,
        error: 'Não é possível excluir uma categoria que possui perguntas'
      };
    }
    
    // Excluir categoria
    knowledge.categories.splice(index, 1);
    localStorage.setItem(DB_KNOWLEDGE_KEY, JSON.stringify(knowledge));
    
    return {
      success: true
    };
  },

  // Obter todas as perguntas
  getAllQuestions: function() {
    initializeKnowledgeDB();
    const knowledge = JSON.parse(localStorage.getItem(DB_KNOWLEDGE_KEY));
    return knowledge.questions;
  },

  // Obter perguntas por categoria
  getQuestionsByCategory: function(categoryId) {
    const questions = this.getAllQuestions();
    return questions.filter(q => q.categoria === categoryId);
  },

  // Obter pergunta por ID
  getQuestionById: function(questionId) {
    const questions = this.getAllQuestions();
    return questions.find(q => q.id === questionId);
  },

  // Obter perguntas do usuário atual
  getUserQuestions: function() {
    initializeKnowledgeDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return [];
    }
    
    const userQuestions = JSON.parse(localStorage.getItem(DB_USER_QUESTIONS_KEY));
    return userQuestions.filter(q => q.userId === currentUser.id);
  },

  // Criar ou atualizar pergunta
  saveOrUpdateQuestion: function(questionData) {
    initializeKnowledgeDB();
    const knowledge = JSON.parse(localStorage.getItem(DB_KNOWLEDGE_KEY));
    const currentUser = getUsuarioAtual();
    
    // Validar dados da pergunta
    if (!questionData.pergunta || !questionData.categoria) {
      return {
        success: false,
        error: 'Pergunta e categoria são obrigatórias'
      };
    }
    
    // Verificar permissão para adicionar perguntas
    if (!window.PlansAPI || !window.PlansAPI.checkPermission('baseConhecimento', 'adicionar')) {
      return {
        success: false,
        error: 'Seu plano não permite adicionar perguntas à base de conhecimento'
      };
    }
    
    // Verificar limite de adições (apenas para plano parceiro)
    const userPlan = window.PlansAPI ? window.PlansAPI.getUserPlan() : null;
    if (userPlan && userPlan.id === 'parceiro') {
      const limiteAdicoes = userPlan.permissoes.baseConhecimento.limiteAdicoes || 0;
      const userQuestions = this.getUserQuestions();
      
      if (userQuestions.length >= limiteAdicoes) {
        return {
          success: false,
          error: `Você atingiu o limite de ${limiteAdicoes} perguntas para seu plano`
        };
      }
    }
    
    // Preparar dados da pergunta
    const newQuestion = {
      id: questionData.id || 'q_' + Math.random().toString(36).substring(2, 9),
      pergunta: questionData.pergunta,
      categoria: questionData.categoria,
      criador: currentUser ? currentUser.id : 'anonymous',
      dataCriacao: questionData.dataCriacao || new Date().toISOString(),
      ativo: questionData.ativo !== undefined ? questionData.ativo : true
    };
    
    // Verificar se a pergunta já existe
    const index = knowledge.questions.findIndex(q => q.id === newQuestion.id);
    
    if (index >= 0) {
      // Atualizar pergunta existente
      knowledge.questions[index] = newQuestion;
    } else {
      // Adicionar nova pergunta
      knowledge.questions.push(newQuestion);
      
      // Adicionar à lista de perguntas do usuário
      if (currentUser) {
        const userQuestions = JSON.parse(localStorage.getItem(DB_USER_QUESTIONS_KEY));
        userQuestions.push({
          questionId: newQuestion.id,
          userId: currentUser.id,
          dateAdded: new Date().toISOString()
        });
        localStorage.setItem(DB_USER_QUESTIONS_KEY, JSON.stringify(userQuestions));
      }
    }
    
    localStorage.setItem(DB_KNOWLEDGE_KEY, JSON.stringify(knowledge));
    
    return {
      success: true,
      question: newQuestion
    };
  },

  // Excluir pergunta
  deleteQuestion: function(questionId) {
    initializeKnowledgeDB();
    const knowledge = JSON.parse(localStorage.getItem(DB_KNOWLEDGE_KEY));
    const currentUser = getUsuarioAtual();
    
    // Verificar se a pergunta existe
    const index = knowledge.questions.findIndex(q => q.id === questionId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Pergunta não encontrada'
      };
    }
    
    // Verificar se o usuário tem permissão para excluir
    const question = knowledge.questions[index];
    const isAdmin = currentUser && currentUser.admin;
    const isCreator = currentUser && question.criador === currentUser.id;
    
    if (!isAdmin && !isCreator) {
      return {
        success: false,
        error: 'Você não tem permissão para excluir esta pergunta'
      };
    }
    
    // Excluir pergunta
    knowledge.questions.splice(index, 1);
    localStorage.setItem(DB_KNOWLEDGE_KEY, JSON.stringify(knowledge));
    
    // Remover da lista de perguntas do usuário
    if (currentUser) {
      const userQuestions = JSON.parse(localStorage.getItem(DB_USER_QUESTIONS_KEY));
      const userQuestionIndex = userQuestions.findIndex(
        uq => uq.questionId === questionId && uq.userId === currentUser.id
      );
      
      if (userQuestionIndex >= 0) {
        userQuestions.splice(userQuestionIndex, 1);
        localStorage.setItem(DB_USER_QUESTIONS_KEY, JSON.stringify(userQuestions));
      }
    }
    
    return {
      success: true
    };
  },

  // Verificar permissão para visualizar base de conhecimento
  canViewKnowledge: function() {
    return !window.PlansAPI || window.PlansAPI.checkPermission('baseConhecimento', 'visualizar');
  },

  // Verificar permissão para adicionar perguntas
  canAddQuestions: function() {
    return window.PlansAPI && window.PlansAPI.checkPermission('baseConhecimento', 'adicionar');
  },

  // Obter estatísticas da base de conhecimento
  getStats: function() {
    initializeKnowledgeDB();
    const knowledge = JSON.parse(localStorage.getItem(DB_KNOWLEDGE_KEY));
    const userQuestions = JSON.parse(localStorage.getItem(DB_USER_QUESTIONS_KEY));
    const currentUser = getUsuarioAtual();
    
    const totalQuestions = knowledge.questions.length;
    const totalCategories = knowledge.categories.length;
    const userQuestionsCount = currentUser ? 
      userQuestions.filter(uq => uq.userId === currentUser.id).length : 0;
    
    // Contagem por categoria
    const questionsByCategory = {};
    knowledge.categories.forEach(cat => {
      questionsByCategory[cat.id] = knowledge.questions.filter(q => q.categoria === cat.id).length;
    });
    
    return {
      totalQuestions,
      totalCategories,
      userQuestionsCount,
      questionsByCategory
    };
  },

  // Obter perguntas para um teste específico
  getQuestionsForTest: function(categoryId, limit) {
    const questions = categoryId ? 
      this.getQuestionsByCategory(categoryId) : 
      this.getAllQuestions();
    
    // Filtrar apenas perguntas ativas
    const activeQuestions = questions.filter(q => q.ativo);
    
    // Embaralhar perguntas
    const shuffled = [...activeQuestions].sort(() => 0.5 - Math.random());
    
    // Limitar quantidade
    return shuffled.slice(0, limit);
  }
};

// Exportar API
window.KnowledgeAPI = KnowledgeAPI;
