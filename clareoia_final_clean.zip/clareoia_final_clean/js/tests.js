// Gerenciamento de testes comportamentais
// Implementação de funcionalidades de testes com regras por plano

// Chaves para armazenamento no localStorage
const DB_TESTS_KEY = "clareoia_tests";
const DB_USER_TESTS_KEY = "clareoia_user_tests";
const DB_TEST_RESULTS_KEY = "clareoia_test_results";

// Inicializar banco de dados de testes
function initializeTestsDB() {
  // Inicializar testes se não existir
  if (!localStorage.getItem(DB_TESTS_KEY)) {
    localStorage.setItem(DB_TESTS_KEY, JSON.stringify([
      {
        id: "disc",
        nome: "DISC",
        descricao: "Avaliação de perfil comportamental baseada em Dominância, Influência, Estabilidade e Conformidade",
        imagem: "../img/tests/disc.png",
        categorias: ["comportamental"],
        tempoEstimado: 15, // minutos
        ativo: true
      },
      {
        id: "temperamento",
        nome: "Temperamento",
        descricao: "Análise dos quatro temperamentos básicos: Sanguíneo, Colérico, Melancólico e Fleumático",
        imagem: "../img/tests/temperamento.png",
        categorias: ["comportamental"],
        tempoEstimado: 10, // minutos
        ativo: true
      },
      {
        id: "perfil_animal",
        nome: "Perfil Animal",
        descricao: "Identificação do seu perfil comportamental através de arquétipos animais",
        imagem: "../img/tests/perfil_animal.png",
        categorias: ["comportamental"],
        tempoEstimado: 8, // minutos
        ativo: true
      },
      {
        id: "lideranca",
        nome: "Estilo de Liderança",
        descricao: "Avaliação do seu estilo de liderança e gestão de equipes",
        imagem: "../img/tests/lideranca.png",
        categorias: ["lideranca"],
        tempoEstimado: 12, // minutos
        ativo: true
      }
    ]));
  }

  // Inicializar testes de usuários se não existir
  if (!localStorage.getItem(DB_USER_TESTS_KEY)) {
    localStorage.setItem(DB_USER_TESTS_KEY, JSON.stringify([]));
  }

  // Inicializar resultados de testes se não existir
  if (!localStorage.getItem(DB_TEST_RESULTS_KEY)) {
    localStorage.setItem(DB_TEST_RESULTS_KEY, JSON.stringify([]));
  }
}

// API de Testes
const TestsAPI = {
  // Obter todos os testes
  getAll: function() {
    initializeTestsDB();
    return JSON.parse(localStorage.getItem(DB_TESTS_KEY));
  },

  // Obter teste por ID
  getById: function(testId) {
    const tests = this.getAll();
    return tests.find(test => test.id === testId);
  },

  // Obter testes disponíveis para o usuário atual
  getAvailableTests: function() {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return [];
    }
    
    const tests = this.getAll().filter(test => test.ativo);
    
    // Verificar plano do usuário
    if (!window.PlansAPI) {
      return tests;
    }
    
    const userPlan = window.PlansAPI.getUserPlan();
    
    if (!userPlan || userPlan.status !== 'active') {
      return [];
    }
    
    // Verificar testes já realizados pelo usuário
    const userTests = this.getUserTests();
    const completedTestIds = userTests
      .filter(ut => ut.status === 'completed')
      .map(ut => ut.testId);
    
    // Para plano gratuito, limitar a 2 testes
    if (userPlan.id === 'free') {
      // Se já completou 2 testes, não mostrar mais nenhum
      if (completedTestIds.length >= 2) {
        return tests.filter(test => completedTestIds.includes(test.id));
      }
      
      // Se ainda não completou 2 testes, mostrar todos
      return tests;
    }
    
    // Para outros planos, mostrar todos os testes
    return tests;
  },

  // Obter testes do usuário atual
  getUserTests: function() {
    initializeTestsDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return [];
    }
    
    const userTests = JSON.parse(localStorage.getItem(DB_USER_TESTS_KEY));
    return userTests.filter(ut => ut.userId === currentUser.id);
  },

  // Verificar se o usuário pode iniciar um teste
  canStartTest: function(testId) {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return {
        canStart: false,
        reason: 'Usuário não autenticado'
      };
    }
    
    // Verificar se o teste existe e está ativo
    const test = this.getById(testId);
    
    if (!test || !test.ativo) {
      return {
        canStart: false,
        reason: 'Teste não disponível'
      };
    }
    
    // Verificar plano do usuário
    if (!window.PlansAPI) {
      return {
        canStart: true
      };
    }
    
    const userPlan = window.PlansAPI.getUserPlan();
    
    if (!userPlan || userPlan.status !== 'active') {
      return {
        canStart: false,
        reason: 'Plano inativo ou inexistente'
      };
    }
    
    // Verificar testes já realizados pelo usuário
    const userTests = this.getUserTests();
    const completedTestIds = userTests
      .filter(ut => ut.status === 'completed')
      .map(ut => ut.testId);
    
    // Para plano gratuito, limitar a 2 testes
    if (userPlan.id === 'free' && completedTestIds.length >= 2 && !completedTestIds.includes(testId)) {
      return {
        canStart: false,
        reason: 'Limite de testes atingido para o plano gratuito',
        upgradeSuggestion: true
      };
    }
    
    // Verificar se o teste já está em andamento
    const inProgressTest = userTests.find(
      ut => ut.testId === testId && ut.status === 'in_progress'
    );
    
    if (inProgressTest) {
      return {
        canStart: true,
        continueTest: true,
        userTestId: inProgressTest.id
      };
    }
    
    return {
      canStart: true
    };
  },

  // Iniciar um teste
  startTest: function(testId) {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return {
        success: false,
        error: 'Usuário não autenticado'
      };
    }
    
    // Verificar se pode iniciar o teste
    const canStart = this.canStartTest(testId);
    
    if (!canStart.canStart) {
      return {
        success: false,
        error: canStart.reason
      };
    }
    
    // Se o teste já está em andamento, retornar o ID
    if (canStart.continueTest) {
      return {
        success: true,
        userTestId: canStart.userTestId,
        continue: true
      };
    }
    
    // Iniciar novo teste
    initializeTestsDB();
    const userTests = JSON.parse(localStorage.getItem(DB_USER_TESTS_KEY));
    
    // Obter perguntas para o teste
    const test = this.getById(testId);
    let questions = [];
    
    // Verificar plano do usuário para determinar número de perguntas
    let questionLimit = 10; // Padrão para plano gratuito
    
    if (window.PlansAPI) {
      const userPlan = window.PlansAPI.getUserPlan();
      
      if (userPlan && userPlan.status === 'active') {
        switch (userPlan.id) {
          case 'intermediario':
            questionLimit = 20;
            break;
          case 'premium':
          case 'parceiro':
            questionLimit = 30;
            break;
          default:
            questionLimit = 10;
        }
      }
    }
    
    // Obter perguntas da base de conhecimento
    if (window.KnowledgeAPI) {
      // Obter perguntas das categorias do teste
      const testCategories = test.categorias || [];
      
      if (testCategories.length > 0) {
        // Obter perguntas para cada categoria
        const categoryQuestions = [];
        
        testCategories.forEach(category => {
          const catQuestions = window.KnowledgeAPI.getQuestionsForTest(
            category, 
            Math.ceil(questionLimit / testCategories.length)
          );
          categoryQuestions.push(...catQuestions);
        });
        
        // Limitar ao número máximo de perguntas
        questions = categoryQuestions.slice(0, questionLimit);
      } else {
        // Se não houver categorias específicas, obter perguntas gerais
        questions = window.KnowledgeAPI.getQuestionsForTest(null, questionLimit);
      }
    }
    
    // Se não houver perguntas suficientes, gerar perguntas padrão
    if (questions.length < questionLimit) {
      const defaultQuestions = [
        { id: 'dq1', pergunta: 'Como você reage a situações de pressão?' },
        { id: 'dq2', pergunta: 'Você prefere trabalhar em equipe ou individualmente?' },
        { id: 'dq3', pergunta: 'Como você lida com críticas?' },
        { id: 'dq4', pergunta: 'Qual sua maior qualidade profissional?' },
        { id: 'dq5', pergunta: 'Qual seu maior desafio profissional?' },
        { id: 'dq6', pergunta: 'Como você estabelece e alcança metas?' },
        { id: 'dq7', pergunta: 'Como você lida com mudanças?' },
        { id: 'dq8', pergunta: 'Você se considera mais analítico ou intuitivo?' },
        { id: 'dq9', pergunta: 'Como você gerencia seu tempo?' },
        { id: 'dq10', pergunta: 'Como você toma decisões importantes?' },
        { id: 'dq11', pergunta: 'O que te motiva profissionalmente?' },
        { id: 'dq12', pergunta: 'Como você lida com conflitos?' },
        { id: 'dq13', pergunta: 'Você prefere seguir regras ou criar novas abordagens?' },
        { id: 'dq14', pergunta: 'Como você reage a feedback negativo?' },
        { id: 'dq15', pergunta: 'Qual ambiente de trabalho te deixa mais produtivo?' },
        { id: 'dq16', pergunta: 'Como você lida com prazos apertados?' },
        { id: 'dq17', pergunta: 'Você se considera mais detalhista ou generalista?' },
        { id: 'dq18', pergunta: 'Como você aborda problemas complexos?' },
        { id: 'dq19', pergunta: 'O que você faz quando discorda de seu superior?' },
        { id: 'dq20', pergunta: 'Como você mantém o equilíbrio entre vida pessoal e profissional?' },
        { id: 'dq21', pergunta: 'Qual sua estratégia para aprender novas habilidades?' },
        { id: 'dq22', pergunta: 'Como você lida com tarefas repetitivas?' },
        { id: 'dq23', pergunta: 'O que você faz quando comete um erro?' },
        { id: 'dq24', pergunta: 'Como você prioriza suas tarefas?' },
        { id: 'dq25', pergunta: 'Você prefere liderar ou ser liderado?' },
        { id: 'dq26', pergunta: 'Como você reage a situações imprevistas?' },
        { id: 'dq27', pergunta: 'O que te causa estresse no trabalho?' },
        { id: 'dq28', pergunta: 'Como você se mantém motivado em projetos longos?' },
        { id: 'dq29', pergunta: 'Qual sua abordagem para resolver conflitos na equipe?' },
        { id: 'dq30', pergunta: 'Como você lida com múltiplas demandas simultâneas?' }
      ];
      
      // Adicionar perguntas padrão até atingir o limite
      const neededQuestions = questionLimit - questions.length;
      const shuffledDefault = [...defaultQuestions].sort(() => 0.5 - Math.random());
      
      questions = [...questions, ...shuffledDefault.slice(0, neededQuestions)];
    }
    
    // Criar novo teste do usuário
    const userTest = {
      id: 'ut_' + Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      testId: testId,
      status: 'in_progress',
      startDate: new Date().toISOString(),
      endDate: null,
      currentQuestion: 0,
      questions: questions.map(q => ({
        id: q.id,
        pergunta: q.pergunta,
        resposta: null
      })),
      results: null
    };
    
    userTests.push(userTest);
    localStorage.setItem(DB_USER_TESTS_KEY, JSON.stringify(userTests));
    
    // Disparar webhook de teste iniciado
    if (window.WebhooksAPI) {
      window.WebhooksAPI.triggerEvent('test_started', {
        userId: currentUser.id,
        testId: testId,
        userTestId: userTest.id,
        startDate: userTest.startDate
      });
    }
    
    return {
      success: true,
      userTestId: userTest.id
    };
  },

  // Obter teste do usuário por ID
  getUserTestById: function(userTestId) {
    initializeTestsDB();
    const userTests = JSON.parse(localStorage.getItem(DB_USER_TESTS_KEY));
    return userTests.find(ut => ut.id === userTestId);
  },

  // Responder pergunta de teste
  answerQuestion: function(userTestId, questionIndex, answer) {
    initializeTestsDB();
    const userTests = JSON.parse(localStorage.getItem(DB_USER_TESTS_KEY));
    const index = userTests.findIndex(ut => ut.id === userTestId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Teste não encontrado'
      };
    }
    
    const userTest = userTests[index];
    
    // Verificar se o teste está em andamento
    if (userTest.status !== 'in_progress') {
      return {
        success: false,
        error: 'Teste não está em andamento'
      };
    }
    
    // Verificar se o índice da pergunta é válido
    if (questionIndex < 0 || questionIndex >= userTest.questions.length) {
      return {
        success: false,
        error: 'Índice de pergunta inválido'
      };
    }
    
    // Salvar resposta
    userTest.questions[questionIndex].resposta = answer;
    userTest.currentQuestion = questionIndex + 1;
    
    // Verificar se todas as perguntas foram respondidas
    const allAnswered = userTest.questions.every(q => q.resposta !== null);
    
    if (allAnswered) {
      userTest.status = 'completed';
      userTest.endDate = new Date().toISOString();
      
      // Gerar resultados
      userTest.results = this.generateResults(userTest);
      
      // Salvar resultados separadamente
      const testResults = JSON.parse(localStorage.getItem(DB_TEST_RESULTS_KEY));
      testResults.push({
        id: 'tr_' + Math.random().toString(36).substring(2, 9),
        userTestId: userTest.id,
        userId: userTest.userId,
        testId: userTest.testId,
        date: userTest.endDate,
        results: userTest.results
      });
      localStorage.setItem(DB_TEST_RESULTS_KEY, JSON.stringify(testResults));
      
      // Disparar webhook de teste concluído
      if (window.WebhooksAPI) {
        window.WebhooksAPI.triggerEvent('test_completed', {
          userId: userTest.userId,
          testId: userTest.testId,
          userTestId: userTest.id,
          startDate: userTest.startDate,
          endDate: userTest.endDate
        });
      }
    }
    
    localStorage.setItem(DB_USER_TESTS_KEY, JSON.stringify(userTests));
    
    return {
      success: true,
      currentQuestion: userTest.currentQuestion,
      completed: userTest.status === 'completed',
      results: userTest.status === 'completed' ? userTest.results : null
    };
  },

  // Gerar resultados do teste
  generateResults: function(userTest) {
    // Obter teste
    const test = this.getById(userTest.testId);
    
    if (!test) {
      return null;
    }
    
    // Implementação básica de geração de resultados
    // Em produção, isso seria feito com algoritmos específicos para cada tipo de teste
    
    let results = null;
    
    switch (test.id) {
      case 'disc':
        results = this.generateDISCResults(userTest);
        break;
      case 'temperamento':
        results = this.generateTemperamentoResults(userTest);
        break;
      case 'perfil_animal':
        results = this.generatePerfilAnimalResults(userTest);
        break;
      case 'lideranca':
        results = this.generateLiderancaResults(userTest);
        break;
      default:
        // Resultados genéricos
        results = {
          summary: 'Resultados do teste ' + test.nome,
          description: 'Análise baseada nas respostas fornecidas',
          scores: {
            comunicacao: Math.floor(Math.random() * 100),
            adaptabilidade: Math.floor(Math.random() * 100),
            resolucaoProblemas: Math.floor(Math.random() * 100),
            trabalhoEquipe: Math.floor(Math.random() * 100)
          },
          strengths: [
            'Comunicação clara',
            'Adaptabilidade a mudanças',
            'Resolução de problemas'
          ],
          weaknesses: [
            'Impaciência',
            'Perfeccionismo'
          ],
          recommendations: [
            'Desenvolver habilidades de escuta ativa',
            'Praticar delegação de tarefas',
            'Buscar feedback constante'
          ]
        };
    }
    
    return results;
  },

  // Gerar resultados específicos para cada tipo de teste
  generateDISCResults: function(userTest) {
    // Simulação de resultados DISC
    const scores = {
      D: Math.floor(Math.random() * 100),
      I: Math.floor(Math.random() * 100),
      S: Math.floor(Math.random() * 100),
      C: Math.floor(Math.random() * 100)
    };
    
    // Determinar perfil predominante
    const maxScore = Math.max(scores.D, scores.I, scores.S, scores.C);
    let primaryProfile = '';
    
    if (scores.D === maxScore) primaryProfile = 'Dominância';
    else if (scores.I === maxScore) primaryProfile = 'Influência';
    else if (scores.S === maxScore) primaryProfile = 'Estabilidade';
    else if (scores.C === maxScore) primaryProfile = 'Conformidade';
    
    return {
      summary: 'Perfil DISC: ' + primaryProfile,
      description: 'O perfil DISC avalia seu comportamento em quatro dimensões: Dominância, Influência, Estabilidade e Conformidade.',
      scores: scores,
      primaryProfile: primaryProfile,
      strengths: this.getDISCStrengths(primaryProfile),
      weaknesses: this.getDISCWeaknesses(primaryProfile),
      recommendations: this.getDISCRecommendations(primaryProfile)
    };
  },

  getDISCStrengths: function(profile) {
    switch (profile) {
      case 'Dominância':
        return ['Liderança', 'Tomada de decisão', 'Foco em resultados'];
      case 'Influência':
        return ['Comunicação', 'Persuasão', 'Entusiasmo'];
      case 'Estabilidade':
        return ['Confiabilidade', 'Paciência', 'Trabalho em equipe'];
      case 'Conformidade':
        return ['Precisão', 'Análise', 'Organização'];
      default:
        return ['Adaptabilidade', 'Equilíbrio', 'Versatilidade'];
    }
  },

  getDISCWeaknesses: function(profile) {
    switch (profile) {
      case 'Dominância':
        return ['Impaciência', 'Insensibilidade', 'Autoritarismo'];
      case 'Influência':
        return ['Desorganização', 'Impulsividade', 'Falta de foco'];
      case 'Estabilidade':
        return ['Resistência a mudanças', 'Passividade', 'Indecisão'];
      case 'Conformidade':
        return ['Perfeccionismo', 'Criticismo', 'Inflexibilidade'];
      default:
        return ['Inconsistência', 'Indecisão', 'Falta de foco'];
    }
  },

  getDISCRecommendations: function(profile) {
    switch (profile) {
      case 'Dominância':
        return [
          'Desenvolver empatia e escuta ativa',
          'Praticar paciência em processos colaborativos',
          'Equilibrar assertividade com diplomacia'
        ];
      case 'Influência':
        return [
          'Implementar sistemas de organização',
          'Desenvolver foco e persistência',
          'Equilibrar socialização com produtividade'
        ];
      case 'Estabilidade':
        return [
          'Praticar adaptabilidade a mudanças',
          'Desenvolver assertividade',
          'Estabelecer limites claros'
        ];
      case 'Conformidade':
        return [
          'Praticar flexibilidade',
          'Desenvolver tolerância a imperfeições',
          'Equilibrar análise com ação'
        ];
      default:
        return [
          'Identificar seus pontos fortes naturais',
          'Desenvolver consistência',
          'Estabelecer metas claras'
        ];
    }
  },

  generateTemperamentoResults: function(userTest) {
    // Simulação de resultados de Temperamento
    const scores = {
      sanguineo: Math.floor(Math.random() * 100),
      colerico: Math.floor(Math.random() * 100),
      melancolico: Math.floor(Math.random() * 100),
      fleumatico: Math.floor(Math.random() * 100)
    };
    
    // Determinar temperamento predominante
    const maxScore = Math.max(scores.sanguineo, scores.colerico, scores.melancolico, scores.fleumatico);
    let primaryTemperament = '';
    
    if (scores.sanguineo === maxScore) primaryTemperament = 'Sanguíneo';
    else if (scores.colerico === maxScore) primaryTemperament = 'Colérico';
    else if (scores.melancolico === maxScore) primaryTemperament = 'Melancólico';
    else if (scores.fleumatico === maxScore) primaryTemperament = 'Fleumático';
    
    return {
      summary: 'Temperamento: ' + primaryTemperament,
      description: 'A análise de temperamento identifica sua disposição natural entre quatro tipos: Sanguíneo, Colérico, Melancólico e Fleumático.',
      scores: scores,
      primaryTemperament: primaryTemperament,
      strengths: this.getTemperamentStrengths(primaryTemperament),
      weaknesses: this.getTemperamentWeaknesses(primaryTemperament),
      recommendations: this.getTemperamentRecommendations(primaryTemperament)
    };
  },

  getTemperamentStrengths: function(temperament) {
    switch (temperament) {
      case 'Sanguíneo':
        return ['Extroversão', 'Entusiasmo', 'Criatividade'];
      case 'Colérico':
        return ['Liderança', 'Determinação', 'Produtividade'];
      case 'Melancólico':
        return ['Perfeccionismo', 'Análise', 'Criatividade'];
      case 'Fleumático':
        return ['Calma', 'Diplomacia', 'Consistência'];
      default:
        return ['Adaptabilidade', 'Equilíbrio', 'Versatilidade'];
    }
  },

  getTemperamentWeaknesses: function(temperament) {
    switch (temperament) {
      case 'Sanguíneo':
        return ['Desorganização', 'Impulsividade', 'Falta de foco'];
      case 'Colérico':
        return ['Impaciência', 'Autoritarismo', 'Insensibilidade'];
      case 'Melancólico':
        return ['Pessimismo', 'Criticismo', 'Indecisão'];
      case 'Fleumático':
        return ['Passividade', 'Procrastinação', 'Resistência a mudanças'];
      default:
        return ['Inconsistência', 'Indecisão', 'Falta de foco'];
    }
  },

  getTemperamentRecommendations: function(temperament) {
    switch (temperament) {
      case 'Sanguíneo':
        return [
          'Implementar sistemas de organização',
          'Desenvolver foco e persistência',
          'Equilibrar socialização com produtividade'
        ];
      case 'Colérico':
        return [
          'Desenvolver empatia e escuta ativa',
          'Praticar paciência em processos colaborativos',
          'Equilibrar assertividade com diplomacia'
        ];
      case 'Melancólico':
        return [
          'Cultivar pensamento positivo',
          'Praticar tomada de decisão',
          'Equilibrar análise com ação'
        ];
      case 'Fleumático':
        return [
          'Desenvolver assertividade',
          'Estabelecer metas e prazos claros',
          'Praticar iniciativa'
        ];
      default:
        return [
          'Identificar seus pontos fortes naturais',
          'Desenvolver consistência',
          'Estabelecer metas claras'
        ];
    }
  },

  generatePerfilAnimalResults: function(userTest) {
    // Simulação de resultados de Perfil Animal
    const profiles = ['Águia', 'Lobo', 'Golfinho', 'Coruja'];
    const primaryProfile = profiles[Math.floor(Math.random() * profiles.length)];
    
    const scores = {};
    profiles.forEach(profile => {
      scores[profile.toLowerCase()] = Math.floor(Math.random() * 100);
    });
    
    // Garantir que o perfil primário tenha a maior pontuação
    const maxScore = Math.max(...Object.values(scores));
    scores[primaryProfile.toLowerCase()] = maxScore + 5;
    
    return {
      summary: 'Perfil Animal: ' + primaryProfile,
      description: 'O perfil animal identifica seu estilo comportamental através de arquétipos animais.',
      scores: scores,
      primaryProfile: primaryProfile,
      strengths: this.getAnimalProfileStrengths(primaryProfile),
      weaknesses: this.getAnimalProfileWeaknesses(primaryProfile),
      recommendations: this.getAnimalProfileRecommendations(primaryProfile)
    };
  },

  getAnimalProfileStrengths: function(profile) {
    switch (profile) {
      case 'Águia':
        return ['Visão estratégica', 'Liderança', 'Foco em resultados'];
      case 'Lobo':
        return ['Trabalho em equipe', 'Lealdade', 'Persistência'];
      case 'Golfinho':
        return ['Comunicação', 'Empatia', 'Adaptabilidade'];
      case 'Coruja':
        return ['Análise', 'Precisão', 'Planejamento'];
      default:
        return ['Adaptabilidade', 'Equilíbrio', 'Versatilidade'];
    }
  },

  getAnimalProfileWeaknesses: function(profile) {
    switch (profile) {
      case 'Águia':
        return ['Impaciência', 'Autoritarismo', 'Insensibilidade'];
      case 'Lobo':
        return ['Territorialismo', 'Resistência a mudanças', 'Desconfiança'];
      case 'Golfinho':
        return ['Evitar conflitos', 'Excesso de socialização', 'Falta de foco'];
      case 'Coruja':
        return ['Perfeccionismo', 'Lentidão', 'Isolamento'];
      default:
        return ['Inconsistência', 'Indecisão', 'Falta de foco'];
    }
  },

  getAnimalProfileRecommendations: function(profile) {
    switch (profile) {
      case 'Águia':
        return [
          'Desenvolver empatia e escuta ativa',
          'Praticar paciência em processos colaborativos',
          'Equilibrar assertividade com diplomacia'
        ];
      case 'Lobo':
        return [
          'Desenvolver abertura a novas ideias',
          'Praticar confiança em novos relacionamentos',
          'Equilibrar lealdade com flexibilidade'
        ];
      case 'Golfinho':
        return [
          'Desenvolver assertividade em conflitos',
          'Equilibrar socialização com produtividade',
          'Praticar foco e persistência'
        ];
      case 'Coruja':
        return [
          'Praticar tomada de decisão rápida',
          'Desenvolver habilidades sociais',
          'Equilibrar análise com ação'
        ];
      default:
        return [
          'Identificar seus pontos fortes naturais',
          'Desenvolver consistência',
          'Estabelecer metas claras'
        ];
    }
  },

  generateLiderancaResults: function(userTest) {
    // Simulação de resultados de Estilo de Liderança
    const styles = ['Autocrático', 'Democrático', 'Liberal', 'Transformacional'];
    const primaryStyle = styles[Math.floor(Math.random() * styles.length)];
    
    const scores = {};
    styles.forEach(style => {
      scores[style.toLowerCase()] = Math.floor(Math.random() * 100);
    });
    
    // Garantir que o estilo primário tenha a maior pontuação
    const maxScore = Math.max(...Object.values(scores));
    scores[primaryStyle.toLowerCase()] = maxScore + 5;
    
    return {
      summary: 'Estilo de Liderança: ' + primaryStyle,
      description: 'A análise de estilo de liderança identifica sua abordagem natural para liderar e gerenciar equipes.',
      scores: scores,
      primaryStyle: primaryStyle,
      strengths: this.getLeadershipStyleStrengths(primaryStyle),
      weaknesses: this.getLeadershipStyleWeaknesses(primaryStyle),
      recommendations: this.getLeadershipStyleRecommendations(primaryStyle)
    };
  },

  getLeadershipStyleStrengths: function(style) {
    switch (style) {
      case 'Autocrático':
        return ['Tomada de decisão rápida', 'Clareza de direção', 'Eficiência'];
      case 'Democrático':
        return ['Colaboração', 'Engajamento da equipe', 'Inovação'];
      case 'Liberal':
        return ['Autonomia', 'Criatividade', 'Desenvolvimento de talentos'];
      case 'Transformacional':
        return ['Inspiração', 'Visão de futuro', 'Desenvolvimento de pessoas'];
      default:
        return ['Adaptabilidade', 'Equilíbrio', 'Versatilidade'];
    }
  },

  getLeadershipStyleWeaknesses: function(style) {
    switch (style) {
      case 'Autocrático':
        return ['Baixo engajamento da equipe', 'Resistência', 'Dependência do líder'];
      case 'Democrático':
        return ['Lentidão nas decisões', 'Conflitos de opinião', 'Falta de direção clara'];
      case 'Liberal':
        return ['Falta de coordenação', 'Baixa produtividade', 'Falta de direção'];
      case 'Transformacional':
        return ['Expectativas irrealistas', 'Burnout', 'Foco excessivo no futuro'];
      default:
        return ['Inconsistência', 'Indecisão', 'Falta de foco'];
    }
  },

  getLeadershipStyleRecommendations: function(style) {
    switch (style) {
      case 'Autocrático':
        return [
          'Desenvolver escuta ativa e valorização de opiniões',
          'Implementar processos de feedback da equipe',
          'Equilibrar controle com delegação'
        ];
      case 'Democrático':
        return [
          'Estabelecer processos de decisão mais ágeis',
          'Desenvolver habilidades de mediação de conflitos',
          'Equilibrar colaboração com direcionamento'
        ];
      case 'Liberal':
        return [
          'Implementar estruturas de acompanhamento',
          'Estabelecer metas e expectativas claras',
          'Equilibrar autonomia com direcionamento'
        ];
      case 'Transformacional':
        return [
          'Equilibrar visão de futuro com necessidades presentes',
          'Estabelecer metas realistas e graduais',
          'Desenvolver processos de gestão do dia a dia'
        ];
      default:
        return [
          'Identificar seu estilo natural de liderança',
          'Desenvolver versatilidade de estilos',
          'Adaptar seu estilo ao contexto e equipe'
        ];
    }
  },

  // Obter resultados de testes do usuário
  getUserResults: function() {
    initializeTestsDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return [];
    }
    
    const testResults = JSON.parse(localStorage.getItem(DB_TEST_RESULTS_KEY));
    return testResults.filter(tr => tr.userId === currentUser.id);
  },

  // Verificar se o usuário pode acessar a Análise 360
  canAccessAnalysis360: function() {
    // Verificar plano do usuário
    if (!window.PlansAPI) {
      return {
        canAccess: false,
        reason: 'Módulo de planos não disponível'
      };
    }
    
    const hasPermission = window.PlansAPI.checkPermission('analise360');
    
    if (!hasPermission) {
      return {
        canAccess: false,
        reason: 'Seu plano não inclui acesso à Análise 360',
        upgradeSuggestion: true
      };
    }
    
    // Verificar se completou todos os testes necessários
    const progress = window.PlansAPI.getAnalysis360Progress();
    
    if (!progress.available) {
      return {
        canAccess: false,
        reason: `Complete todos os testes necessários (${progress.completedTests}/${progress.requiredTests})`,
        progress: progress.progress
      };
    }
    
    return {
      canAccess: true,
      progress: 100
    };
  },

  // Gerar Análise 360
  generateAnalysis360: function() {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return {
        success: false,
        error: 'Usuário não autenticado'
      };
    }
    
    // Verificar acesso
    const accessCheck = this.canAccessAnalysis360();
    
    if (!accessCheck.canAccess) {
      return {
        success: false,
        error: accessCheck.reason
      };
    }
    
    // Obter resultados de todos os testes do usuário
    const userResults = this.getUserResults();
    
    if (userResults.length === 0) {
      return {
        success: false,
        error: 'Nenhum resultado de teste encontrado'
      };
    }
    
    // Simulação de Análise 360
    // Em produção, isso seria feito com algoritmos avançados e IA
    
    const analysis = {
      id: 'a360_' + Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      date: new Date().toISOString(),
      summary: 'Análise 360: Perfil Completo',
      description: 'Análise integrada baseada em todos os testes realizados',
      profileSummary: 'Seu perfil indica uma combinação de habilidades analíticas e interpessoais, com forte tendência à liderança colaborativa e foco em resultados.',
      strengths: [
        'Comunicação clara e assertiva',
        'Capacidade analítica e resolução de problemas',
        'Adaptabilidade a diferentes contextos',
        'Liderança inspiradora'
      ],
      weaknesses: [
        'Tendência ao perfeccionismo',
        'Impaciência em processos lentos',
        'Dificuldade em delegar tarefas importantes'
      ],
      careerFit: [
        'Gestão de projetos',
        'Consultoria estratégica',
        'Liderança de equipes multidisciplinares',
        'Desenvolvimento de negócios'
      ],
      developmentAreas: [
        'Inteligência emocional',
        'Gestão do tempo',
        'Delegação efetiva',
        'Comunicação em situações de conflito'
      ],
      actionPlan: [
        'Estabelecer metas de desenvolvimento para inteligência emocional',
        'Implementar técnicas de gestão do tempo e priorização',
        'Praticar delegação progressiva de responsabilidades',
        'Buscar feedback constante sobre seu estilo de comunicação'
      ]
    };
    
    // Salvar análise
    const analyses = localStorage.getItem('clareoia_analyses') ? 
      JSON.parse(localStorage.getItem('clareoia_analyses')) : [];
    
    analyses.push(analysis);
    localStorage.setItem('clareoia_analyses', JSON.stringify(analyses));
    
    // Disparar webhook de análise 360 gerada
    if (window.WebhooksAPI) {
      window.WebhooksAPI.triggerEvent('analysis360_generated', {
        userId: currentUser.id,
        analysisId: analysis.id,
        date: analysis.date
      });
    }
    
    return {
      success: true,
      analysis: analysis
    };
  },

  // Obter estatísticas de testes
  getStats: function() {
    initializeTestsDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return null;
    }
    
    const userTests = this.getUserTests();
    const completedTests = userTests.filter(ut => ut.status === 'completed');
    const inProgressTests = userTests.filter(ut => ut.status === 'in_progress');
    
    // Estatísticas por tipo de teste
    const testStats = {};
    const tests = this.getAll();
    
    tests.forEach(test => {
      const testCompleted = completedTests.filter(ut => ut.testId === test.id).length;
      const testInProgress = inProgressTests.filter(ut => ut.testId === test.id).length;
      
      testStats[test.id] = {
        completed: testCompleted,
        inProgress: testInProgress,
        total: testCompleted + testInProgress
      };
    });
    
    return {
      totalTests: userTests.length,
      completedTests: completedTests.length,
      inProgressTests: inProgressTests.length,
      testStats: testStats,
      analysis360: window.PlansAPI ? window.PlansAPI.getAnalysis360Progress() : null
    };
  }
};

// Exportar API
window.TestsAPI = TestsAPI;
