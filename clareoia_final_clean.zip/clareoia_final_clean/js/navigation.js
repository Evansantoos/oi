/**
 * Navegação do painel do usuário
 * Este arquivo gerencia a navegação entre as abas do painel do usuário
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar navegação
    initNavigation();
    
    // Verificar autenticação
    if (typeof verificarAutenticacao === 'function') {
        if (!verificarAutenticacao()) {
            window.location.href = 'login.html';
            return;
        }
    }
});

/**
 * Inicializa a navegação do painel
 */
function initNavigation() {
    // Obter todos os links de navegação
    const navLinks = document.querySelectorAll('nav ul li a');
    
    // Adicionar evento de clique a cada link
    navLinks.forEach(link => {
        if (!link.id || link.id !== 'logout-btn') {
            link.addEventListener('click', function(e) {
                // Verificar se é um link interno (com #)
                if (this.getAttribute('href').startsWith('#')) {
                    e.preventDefault();
                    
                    // Obter o ID da seção alvo
                    const targetId = this.getAttribute('href');
                    
                    // Navegar para a seção
                    navigateToSection(targetId);
                }
            });
        }
    });
    
    // Verificar se há uma seção específica na URL
    const hash = window.location.hash;
    if (hash) {
        navigateToSection(hash);
    }
    
    // Inicializar navegação de abas
    initTabNavigation();
}

/**
 * Navega para uma seção específica
 * @param {string} sectionId - ID da seção alvo
 */
function navigateToSection(sectionId) {
    // Remover 'active' de todos os links
    const navLinks = document.querySelectorAll('nav ul li a');
    navLinks.forEach(link => {
        link.classList.remove('active');
    });
    
    // Adicionar 'active' ao link correspondente
    const activeLink = document.querySelector(`nav ul li a[href="${sectionId}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Ocultar todas as seções
    const sections = document.querySelectorAll('main section');
    sections.forEach(section => {
        section.style.display = 'none';
    });
    
    // Mostrar a seção alvo
    const targetSection = document.querySelector(sectionId);
    if (targetSection) {
        targetSection.style.display = 'block';
    }
}

/**
 * Inicializa a navegação por abas
 */
function initTabNavigation() {
    // Obter todas as abas
    const tabs = document.querySelectorAll('.tab-nav li a');
    
    // Adicionar evento de clique a cada aba
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Obter o ID do conteúdo da aba
            const tabId = this.getAttribute('href');
            
            // Navegar para a aba
            navigateToTab(tabId);
        });
    });
    
    // Ativar a primeira aba por padrão
    if (tabs.length > 0) {
        const firstTabId = tabs[0].getAttribute('href');
        navigateToTab(firstTabId);
    }
}

/**
 * Navega para uma aba específica
 * @param {string} tabId - ID da aba alvo
 */
function navigateToTab(tabId) {
    // Remover 'active' de todas as abas
    const tabs = document.querySelectorAll('.tab-nav li a');
    tabs.forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Adicionar 'active' à aba correspondente
    const activeTab = document.querySelector(`.tab-nav li a[href="${tabId}"]`);
    if (activeTab) {
        activeTab.classList.add('active');
    }
    
    // Ocultar todos os conteúdos de aba
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.style.display = 'none';
    });
    
    // Mostrar o conteúdo da aba alvo
    const targetContent = document.querySelector(tabId);
    if (targetContent) {
        targetContent.style.display = 'block';
    }
}

/**
 * Navega para uma página específica
 * @param {string} page - URL da página
 */
function navigateToPage(page) {
    window.location.href = page;
}
