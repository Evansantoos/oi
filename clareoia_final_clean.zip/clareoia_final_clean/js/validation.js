// Funções para validação do fluxo visual e funcional
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se o script de navegação está carregado
    if (typeof initNavigation === 'function') {
        console.log('✅ Script de navegação carregado com sucesso');
    } else {
        console.error('❌ Script de navegação não encontrado');
    }
    
    // Verificar se o script de autenticação está carregado
    if (typeof verificarAutenticacao === 'function') {
        console.log('✅ Script de autenticação carregado com sucesso');
    } else {
        console.error('❌ Script de autenticação não encontrado');
    }
    
    // Verificar se os elementos principais estão presentes
    const mainElements = [
        { selector: 'header', name: 'Cabeçalho' },
        { selector: 'nav', name: 'Navegação' },
        { selector: 'main', name: 'Conteúdo principal' },
        { selector: 'footer', name: 'Rodapé' }
    ];
    
    mainElements.forEach(element => {
        if (document.querySelector(element.selector)) {
            console.log(`✅ ${element.name} encontrado`);
        } else {
            console.error(`❌ ${element.name} não encontrado`);
        }
    });
    
    // Verificar links de navegação
    const navLinks = document.querySelectorAll('nav ul li a');
    if (navLinks.length > 0) {
        console.log(`✅ ${navLinks.length} links de navegação encontrados`);
        
        // Adicionar evento de clique para validação
        navLinks.forEach(link => {
            if (!link.hasAttribute('data-validated')) {
                const originalHref = link.getAttribute('href');
                
                // Não modificar o link de logout
                if (!link.id || link.id !== 'logout-btn') {
                    link.addEventListener('click', function(e) {
                        if (!originalHref.startsWith('#')) {
                            e.preventDefault();
                            console.log(`✅ Link clicado: ${originalHref}`);
                            
                            // Simular navegação
                            setTimeout(() => {
                                console.log(`✅ Navegação simulada para: ${originalHref}`);
                            }, 500);
                        }
                    });
                    
                    // Marcar como validado
                    link.setAttribute('data-validated', 'true');
                }
            }
        });
    } else {
        console.error('❌ Nenhum link de navegação encontrado');
    }
    
    // Verificar botões interativos
    const buttons = document.querySelectorAll('button, .btn, .btn-primary, .btn-secondary');
    if (buttons.length > 0) {
        console.log(`✅ ${buttons.length} botões interativos encontrados`);
        
        // Adicionar evento de clique para validação
        buttons.forEach(button => {
            if (!button.hasAttribute('data-validated')) {
                button.addEventListener('click', function(e) {
                    // Não prevenir o comportamento padrão para manter a funcionalidade
                    console.log(`✅ Botão clicado: ${button.textContent.trim()}`);
                });
                
                // Marcar como validado
                button.setAttribute('data-validated', 'true');
            }
        });
    } else {
        console.error('❌ Nenhum botão interativo encontrado');
    }
    
    // Verificar responsividade
    const viewportWidth = window.innerWidth;
    console.log(`📱 Largura atual do viewport: ${viewportWidth}px`);
    
    if (viewportWidth < 768) {
        console.log('📱 Visualizando em modo mobile');
    } else if (viewportWidth < 992) {
        console.log('📱 Visualizando em modo tablet');
    } else {
        console.log('🖥️ Visualizando em modo desktop');
    }
    
    // Verificar se o menu mobile está funcionando
    const mobileMenuBtn = document.getElementById('mobile-menu-toggle');
    const mainMenu = document.getElementById('main-menu');
    
    if (mobileMenuBtn && mainMenu) {
        console.log('✅ Menu mobile encontrado');
        
        // Verificar se o evento já está registrado
        if (!mobileMenuBtn.hasAttribute('data-validated')) {
            mobileMenuBtn.addEventListener('click', function() {
                console.log('✅ Botão do menu mobile clicado');
                mainMenu.classList.toggle('active');
                
                if (mainMenu.classList.contains('active')) {
                    console.log('✅ Menu mobile aberto');
                } else {
                    console.log('✅ Menu mobile fechado');
                }
            });
            
            // Marcar como validado
            mobileMenuBtn.setAttribute('data-validated', 'true');
        }
    } else if (viewportWidth < 768) {
        console.error('❌ Menu mobile não encontrado em viewport mobile');
    }
    
    // Verificar carregamento de CSS
    const styles = document.querySelectorAll('link[rel="stylesheet"]');
    if (styles.length > 0) {
        console.log(`✅ ${styles.length} arquivos CSS carregados`);
        
        styles.forEach(style => {
            console.log(`  - ${style.getAttribute('href')}`);
        });
    } else {
        console.error('❌ Nenhum arquivo CSS carregado');
    }
    
    // Verificar carregamento de scripts
    const scripts = document.querySelectorAll('script');
    if (scripts.length > 0) {
        console.log(`✅ ${scripts.length} scripts carregados`);
    } else {
        console.error('❌ Nenhum script carregado');
    }
    
    console.log('✅ Validação de fluxo visual e funcional concluída');
});
