// Inicialização do banco de dados local com usuário admin padrão
function inicializarBancoDados() {
    // Verifica se já existe um banco de dados no localStorage
    const dbExistente = localStorage.getItem('clareoia_database');
    
    if (!dbExistente) {
        console.log("Inicializando banco de dados local...");
        
        // Cria o banco de dados inicial com usuário admin padrão
        const bancoDados = {
            usuarios: [
                {
                    id: 1,
                    nome: "Administrador",
                    email: "admin@startinc.com.br",
                    senha: "admin2025",
                    role: "admin",
                    protegido: true, // Flag para proteger contra exclusão
                    dataCriacao: new Date().toISOString()
                }
            ],
            prompts: [],
            treinamentos: [],
            configuracoes: {
                versao: "1.0.0",
                ultimaAtualizacao: new Date().toISOString()
            }
        };
        
        // Salva o banco de dados no localStorage
        localStorage.setItem('clareoia_database', JSON.stringify(bancoDados));
        console.log("Banco de dados inicializado com sucesso!");
    } else {
        console.log("Banco de dados já existe, verificando usuário admin padrão...");
        
        // Carrega o banco de dados existente
        const bancoDados = JSON.parse(dbExistente);
        
        // Verifica se o usuário admin padrão existe
        const adminPadrao = bancoDados.usuarios.find(u => 
            u.email === "admin@startinc.com.br" && u.role === "admin"
        );
        
        if (!adminPadrao) {
            console.log("Usuário admin padrão não encontrado, criando...");
            
            // Cria o usuário admin padrão
            bancoDados.usuarios.push({
                id: bancoDados.usuarios.length > 0 ? 
                    Math.max(...bancoDados.usuarios.map(u => u.id)) + 1 : 1,
                nome: "Administrador",
                email: "admin@startinc.com.br",
                senha: "admin2025",
                role: "admin",
                protegido: true,
                dataCriacao: new Date().toISOString()
            });
            
            // Atualiza o banco de dados
            localStorage.setItem('clareoia_database', JSON.stringify(bancoDados));
            console.log("Usuário admin padrão criado com sucesso!");
        } else if (!adminPadrao.protegido) {
            console.log("Adicionando proteção ao usuário admin padrão...");
            
            // Adiciona a flag de proteção ao usuário admin padrão
            adminPadrao.protegido = true;
            
            // Atualiza o banco de dados
            localStorage.setItem('clareoia_database', JSON.stringify(bancoDados));
            console.log("Proteção adicionada ao usuário admin padrão!");
        } else {
            console.log("Usuário admin padrão já existe e está protegido.");
        }
    }
}

// Função para obter usuários do banco de dados
function getUsuarios() {
    const bancoDados = JSON.parse(localStorage.getItem('clareoia_database') || '{"usuarios":[]}');
    return bancoDados.usuarios;
}

// Função para adicionar um novo usuário
function adicionarUsuario(usuario) {
    const bancoDados = JSON.parse(localStorage.getItem('clareoia_database') || '{"usuarios":[]}');
    
    // Gera um ID para o novo usuário
    usuario.id = bancoDados.usuarios.length > 0 ? 
        Math.max(...bancoDados.usuarios.map(u => u.id)) + 1 : 1;
    
    // Adiciona data de criação
    usuario.dataCriacao = new Date().toISOString();
    
    // Adiciona o usuário ao banco de dados
    bancoDados.usuarios.push(usuario);
    
    // Atualiza o banco de dados
    localStorage.setItem('clareoia_database', JSON.stringify(bancoDados));
    
    return usuario;
}

// Função para atualizar um usuário existente
function atualizarUsuario(id, dadosAtualizados) {
    const bancoDados = JSON.parse(localStorage.getItem('clareoia_database') || '{"usuarios":[]}');
    
    // Encontra o índice do usuário
    const index = bancoDados.usuarios.findIndex(u => u.id === id);
    
    if (index === -1) {
        return null; // Usuário não encontrado
    }
    
    // Verifica se o usuário é protegido e está tentando alterar role ou email
    if (bancoDados.usuarios[index].protegido) {
        // Não permite alterar o email ou role do usuário protegido
        delete dadosAtualizados.email;
        delete dadosAtualizados.role;
        delete dadosAtualizados.protegido; // Não permite remover a proteção
    }
    
    // Atualiza os dados do usuário
    bancoDados.usuarios[index] = {
        ...bancoDados.usuarios[index],
        ...dadosAtualizados,
        dataAtualizacao: new Date().toISOString()
    };
    
    // Atualiza o banco de dados
    localStorage.setItem('clareoia_database', JSON.stringify(bancoDados));
    
    return bancoDados.usuarios[index];
}

// Função para excluir um usuário
function excluirUsuario(id) {
    const bancoDados = JSON.parse(localStorage.getItem('clareoia_database') || '{"usuarios":[]}');
    
    // Encontra o usuário
    const usuario = bancoDados.usuarios.find(u => u.id === id);
    
    if (!usuario) {
        return false; // Usuário não encontrado
    }
    
    // Verifica se o usuário é protegido
    if (usuario.protegido) {
        console.error("Não é possível excluir um usuário protegido!");
        return false;
    }
    
    // Remove o usuário do banco de dados
    bancoDados.usuarios = bancoDados.usuarios.filter(u => u.id !== id);
    
    // Atualiza o banco de dados
    localStorage.setItem('clareoia_database', JSON.stringify(bancoDados));
    
    return true;
}

// Exporta as funções para o escopo global
window.inicializarBancoDados = inicializarBancoDados;
window.getUsuarios = getUsuarios;
window.adicionarUsuario = adicionarUsuario;
window.atualizarUsuario = atualizarUsuario;
window.excluirUsuario = excluirUsuario;

// Inicializa o banco de dados ao carregar o script
inicializarBancoDados();
