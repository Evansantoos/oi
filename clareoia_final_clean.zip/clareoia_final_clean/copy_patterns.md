# Padrões de Copy Persuasiva - Influenciadores Brasileiros

## Elementos Comuns de Persuasão

Após análise das páginas de vendas e materiais de Pablo Marçal, Paulo Vieira (Febracis), Elton Luiz, Wendell Carvalho e outros influenciadores do mercado de desenvolvimento pessoal e empresarial, identifiquei os seguintes padrões de copy persuasiva:

### 1. Dores Ocultas (Problemas que as pessoas têm mas não percebem)

- **Estagnação invisível**: "Você acha que está progredindo, mas está apenas girando em círculos"
- **Autoengano**: "A mentira que você conta para si mesmo todos os dias"
- **Potencial desperdiçado**: "O que você poderia ter conquistado se tivesse clareza há 5 anos"
- **Cegueira de padrões**: "O padrão que está sabotando seus resultados sem você perceber"
- **Falsa competência**: "Você se acha bom, mas não sabe o que realmente está perdendo"
- **Zona de conforto disfarçada**: "O que parece segurança é na verdade sua prisão"
- **Decisões baseadas em percepções erradas**: "Você está tomando decisões com dados falsos"

### 2. Antecipação de Objeções

- **Preço**: "Não é sobre quanto custa, mas quanto custa NÃO ter essa clareza"
- **Tempo**: "Se você acha que não tem tempo para isso, é exatamente por isso que precisa"
- **Ceticismo**: "Para os céticos: não acredite em mim, acredite nos resultados documentados"
- **Já tentei antes**: "Se outros métodos falharam, é porque não tinham esta abordagem científica"
- **Não é para mim**: "Você acha que não precisa disso até descobrir o que está perdendo"
- **Timing**: "Esperar o momento perfeito é garantia de nunca começar"
- **Complexidade**: "Parece complexo, mas o sistema foi desenhado para ser simples e direto"

### 3. Universalização da Necessidade

- **Todos têm pontos cegos**: "Até os mais bem-sucedidos têm áreas de cegueira comportamental"
- **Ninguém escapa dos padrões**: "Seu cérebro segue padrões, queira você ou não"
- **Clareza como necessidade universal**: "Sem clareza, até gênios fracassam"
- **Aplicação em múltiplos contextos**: "Funciona para profissionais, empreendedores e líderes"
- **Problema fundamental**: "Este é o problema raiz que causa todos os outros problemas"
- **Inevitabilidade**: "Não é questão de SE você vai precisar, mas QUANDO"

### 4. Gatilhos Emocionais Recorrentes

- **Medo de perder**: "Enquanto você lê isso, seus concorrentes já estão usando"
- **Urgência**: "Esta oferta expira em X horas" ou "Vagas limitadas a X pessoas"
- **Exclusividade**: "Apenas para quem realmente quer resultados extraordinários"
- **Autoridade**: Uso de dados científicos, estudos de caso e credenciais
- **Prova social**: Depoimentos detalhados com resultados específicos
- **Escassez**: "Apenas X vagas disponíveis nesta turma"
- **Reciprocidade**: Oferta de bônus valiosos "gratuitos"

### 5. Estrutura Narrativa

- **Jornada do herói**: Apresentação do problema → Agravamento → Solução → Transformação
- **Antes/Depois**: Contraste claro entre a vida antes e depois da solução
- **Storytelling pessoal**: História de superação do próprio mentor/criador
- **Vilão identificável**: Identificação clara do "inimigo" (sistema, crenças limitantes, etc.)
- **Momento de virada**: O ponto específico onde tudo mudou para o mentor/criador
- **Futuro projetado**: Descrição vívida do futuro após a transformação

### 6. Elementos Visuais e Formatação

- **Destaque em cores**: Uso de cores contrastantes para pontos-chave
- **Negrito e sublinhado**: Ênfase visual em frases de impacto
- **Blocos curtos de texto**: Parágrafos de 1-3 linhas para facilitar leitura
- **Perguntas retóricas**: Uso frequente para engajar o leitor
- **Bullets e numeração**: Listas para benefícios e transformações
- **Imagens antes/depois**: Representações visuais da transformação
- **Contadores regressivos**: Elementos de urgência visual

### 7. Chamadas para Ação (CTAs)

- **Imperativas**: "Clique agora", "Garanta sua vaga", "Transforme sua vida hoje"
- **Benefício no botão**: "Quero clareza comportamental agora"
- **Eliminação de risco**: "Teste por 7 dias sem compromisso"
- **Decisão binária**: "Continuar na mediocridade ou transformar sua vida agora?"
- **Custo de inação**: "Cada dia sem clareza custa R$ X em oportunidades perdidas"

## Aplicação para a ClareoIA

Estes padrões serão aplicados na nova copy da landing page da ClareoIA, com foco em:

1. Revelar dores ocultas relacionadas à falta de clareza comportamental
2. Antecipar e neutralizar objeções sobre a necessidade do produto
3. Universalizar a necessidade de clareza comportamental para todos
4. Utilizar gatilhos emocionais estratégicos para despertar desejo
5. Estruturar uma narrativa envolvente e transformadora
6. Formatar o texto para máximo impacto visual e legibilidade
7. Criar CTAs poderosos que eliminem barreiras à decisão

A copy final será longa, persuasiva e focada em despertar o desejo mesmo em quem inicialmente não percebe a necessidade do produto.
