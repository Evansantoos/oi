# Documentação de Fluxos de Autenticação - ClareoIA

## Fluxos de Login Implementados

### 1. Login Tradicional (Email/Senha)
- **Status**: Totalmente funcional
- **Implementação**: Autenticação real com validação de credenciais no localStorage
- **Fluxo**:
  1. Usuário insere email e senha
  2. Sistema valida credenciais contra banco de dados local
  3. Se válido, gera token de autenticação e armazena no localStorage
  4. Redireciona para painel.html (usuário comum) ou admin/painel.html (admin)

### 2. Login Social (Google)
- **Status**: Simulado
- **Implementação**: Simulação de OAuth sem integração real com API do Google
- **Fluxo**:
  1. Usuário clica no botão "Google"
  2. Sistema simula processo de autenticação (sem redirecionamento real para Google)
  3. Cria usuário fictício com role "user"
  4. Gera token de autenticação e armazena no localStorage
  5. Redireciona para painel.html

### 3. Login Social (GitHub)
- **Status**: Simulado
- **Implementação**: Simulação de OAuth sem integração real com API do GitHub
- **Fluxo**:
  1. Usuário clica no botão "GitHub"
  2. Sistema simula processo de autenticação (sem redirecionamento real para GitHub)
  3. Cria usuário fictício com role "user"
  4. Gera token de autenticação e armazena no localStorage
  5. Redireciona para painel.html

### 4. Login Administrativo
- **Status**: Totalmente funcional
- **Implementação**: Autenticação real com validação de credenciais e role no localStorage
- **Fluxo**:
  1. Usuário acessa admin/login.html diretamente
  2. Insere credenciais administrativas
  3. Sistema valida credenciais e verifica se role é "admin"
  4. Se válido, gera token de autenticação e armazena no localStorage
  5. Redireciona para admin/painel.html

## Persistência de Dados

### Token de Autenticação
- **Chave**: `clareoia_auth_token`
- **Formato**: Base64 de JSON com userId, timestamp, expiry e nonce
- **Duração**: 30 minutos
- **Renovação**: Automática se faltar menos de 10 minutos para expirar

### Dados do Usuário
- **Chave**: `clareoia_current_user`
- **Formato**: JSON com id, nome, email, role e provider (se aplicável)
- **Persistência**: Mantido até logout ou expiração de sessão

### Contador de Redirecionamentos
- **Chave**: `clareoia_redirect_count`
- **Função**: Prevenir loops infinitos de redirecionamento
- **Limite**: 3 redirecionamentos consecutivos

## Segurança Implementada

### Proteção de Páginas
- **Usuário Comum**: Verificação de token válido para acesso ao painel.html
- **Admin**: Verificação de token válido E role "admin" para acesso ao admin/painel.html

### Logout Automático
- **Inatividade**: Sessão expira após 30 minutos de inatividade
- **Eventos de Atividade**: mousemove, keypress, click, scroll

### Prevenção de Loops
- **Detecção**: Contador de redirecionamentos incrementado a cada redirecionamento
- **Ação**: Interrompe redirecionamentos e mostra alerta após 3 tentativas consecutivas

## Melhorias Futuras Recomendadas

### Integração Real com OAuth
- Implementar autenticação real com Google e GitHub usando suas respectivas APIs
- Configurar callback URLs e gerenciar tokens OAuth reais

### Armazenamento Seguro
- Migrar de localStorage para HttpOnly cookies para armazenamento de tokens
- Implementar refresh tokens para renovação segura de sessões

### Autenticação Avançada
- Implementar autenticação de dois fatores (2FA)
- Adicionar opção de "Lembrar-me" para sessões mais longas
