# Documentação do Projeto ClareoIA

## Visão Geral

ClareoIA é uma plataforma de inteligência comportamental que integra múltiplas metodologias de avaliação para fornecer uma análise holística do indivíduo. O sistema identifica perfis comportamentais, barreiras emocionais e cognitivas, fornecendo insights personalizados para tomada de decisões estratégicas.

## Estrutura do Projeto

```
clareoia/
├── index.html              # Landing page principal
├── login.html              # Página de login de usuários
├── painel.html             # Painel do usuário
├── admin/                  # Área administrativa
│   ├── login.html          # Login administrativo
│   ├── painel.html         # Painel administrativo
│   ├── integrations.html   # Configuração de integrações
│   └── webhooks.html       # Configuração de webhooks
├── css/                    # Estilos CSS
│   ├── styles.css          # Estilos globais
│   ├── landing.css         # Estilos da landing page
│   ├── login.css           # Estilos da página de login
│   └── responsive.css      # Ajustes responsivos
├── js/                     # Scripts JavaScript
│   ├── auth.js             # Autenticação e gestão de usuários
│   ├── database.js         # Simulação de banco de dados
│   ├── navigation.js       # Navegação entre páginas e abas
│   ├── tests.js            # Lógica dos testes comportamentais
│   ├── integrations.js     # Integração com APIs externas
│   ├── webhooks.js         # Gestão de webhooks
│   ├── inactivity.js       # Monitoramento de inatividade
│   └── validation.js       # Validação de fluxos e funcionalidades
└── img/                    # Imagens e recursos visuais
```

## Funcionalidades Principais

### 1. Sistema de Autenticação

- Login com e-mail e senha
- Login social (Google e GitHub)
- Proteção de rotas com verificação de token
- Logout automático após 30 minutos de inatividade
- Área administrativa protegida

### 2. Painel do Usuário

- Visualização de testes disponíveis
- Realização de testes comportamentais
- Visualização de resultados
- Análise 360° (após completar todos os testes)
- Gerenciamento de perfil

### 3. Painel Administrativo

- Gestão de usuários
- Configuração de prompts e treinamentos
- Integração com APIs externas (OpenAI, DeepSeek, GROK, Gemini)
- Configuração de webhooks
- Gestão de planos e permissões

### 4. Planos e Níveis de Acesso

- **Plano Gratuito**: 2 testes com 10 perguntas cada
- **Plano Intermediário**: Todos os testes com 20 perguntas cada
- **Plano Premium (Verdade)**: Todos os testes com 30 perguntas + Análise 360°

## Correções Implementadas

### 1. Correção do Loop Infinito de Login

O problema de loop infinito após o login foi corrigido através das seguintes alterações:

- Implementação de detecção e prevenção de loops de redirecionamento
- Correção da função `verificarAutenticacao()` para validar corretamente o token
- Ajuste dos caminhos de redirecionamento para usar referências absolutas
- Correção da persistência de dados do usuário no localStorage

### 2. Melhorias Visuais e de Usabilidade

- Aplicação correta de CSS em todas as páginas
- Implementação de design responsivo para todos os dispositivos
- Restauração da navegação funcional no painel do usuário
- Melhoria da experiência visual da landing page

### 3. Segurança e Proteção

- Implementação de token de autenticação seguro
- Proteção da área administrativa
- Validação de sessão ativa
- Logout automático por inatividade

## Integrações com APIs Externas

O sistema está preparado para integração com as seguintes APIs:

- **OpenAI**: Para geração de conteúdo e análise de dados
- **DeepSeek**: Para processamento de linguagem natural avançado
- **GROK**: Para análise comportamental
- **Gemini (Google)**: Para geração de conteúdo e análise
- **Evolution API**: Para integrações não oficiais
- **zAPI**: Para envio de mensagens via WhatsApp

## Instruções de Implementação

### Requisitos do Servidor

- Servidor web com suporte a HTML, CSS e JavaScript
- Para implementação backend: Node.js ou PHP

### Instalação

1. Faça upload de todos os arquivos para o diretório raiz do seu servidor web
2. Configure as chaves de API nas integrações (se aplicável)
3. Teste o acesso à página principal (index.html)
4. Verifique o login e navegação no painel do usuário

### Credenciais Padrão

**Administrador:**
- Email: admin@startinc.com.br
- Senha: admin2025

**Usuário de Teste:**
- Email: teste@exemplo.com
- Senha: senha123

## Recomendações para Segurança

Para proteger o código e os dados sensíveis, recomendamos a migração para uma arquitetura com backend. Duas opções são sugeridas:

### 1. Migração para Node.js

Vantagens:
- Mesma linguagem (JavaScript) no frontend e backend
- Fácil implementação de APIs RESTful
- Boa escalabilidade

### 2. Migração para PHP

Vantagens:
- Fácil implementação em servidores compartilhados
- Ampla disponibilidade de hospedagem
- Integração simples com bancos de dados

Consulte o arquivo `backend_migration.md` para instruções detalhadas sobre a migração.

## Suporte e Contato

Para suporte técnico ou dúvidas sobre a implementação, entre em contato:

- Email: contato@clareo.ai
- WhatsApp: (51) 99149-0515

---

© 2025 ClareoIA. Todos os direitos reservados.
