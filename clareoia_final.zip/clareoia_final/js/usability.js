// Melhorias de usabilidade e funcionalidades gerais
// Implementação de cadastro, login social, recuperação de senha e validações

// Chaves para armazenamento no localStorage
const DB_USER_PREFERENCES_KEY = "clareoia_user_preferences";
const DB_USER_ACTIVITY_KEY = "clareoia_user_activity";

// Inicializar banco de dados de usabilidade
function initializeUsabilityDB() {
  // Inicializar preferências de usuários se não existir
  if (!localStorage.getItem(DB_USER_PREFERENCES_KEY)) {
    localStorage.setItem(DB_USER_PREFERENCES_KEY, JSON.stringify({}));
  }

  // Inicializar atividades de usuários se não existir
  if (!localStorage.getItem(DB_USER_ACTIVITY_KEY)) {
    localStorage.setItem(DB_USER_ACTIVITY_KEY, JSON.stringify([]));
  }
}

// API de Usabilidade
const UsabilityAPI = {
  // Registrar atividade do usuário
  logActivity: function(action, details = {}) {
    initializeUsabilityDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return false;
    }
    
    const activities = JSON.parse(localStorage.getItem(DB_USER_ACTIVITY_KEY));
    
    activities.push({
      userId: currentUser.id,
      action: action,
      details: details,
      timestamp: new Date().toISOString()
    });
    
    // Limitar o número de atividades armazenadas (manter apenas as 100 mais recentes)
    const limitedActivities = activities.slice(-100);
    
    localStorage.setItem(DB_USER_ACTIVITY_KEY, JSON.stringify(limitedActivities));
    
    return true;
  },

  // Obter atividades do usuário atual
  getUserActivities: function(limit = 10) {
    initializeUsabilityDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return [];
    }
    
    const activities = JSON.parse(localStorage.getItem(DB_USER_ACTIVITY_KEY));
    
    return activities
      .filter(activity => activity.userId === currentUser.id)
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(0, limit);
  },

  // Salvar preferências do usuário
  saveUserPreference: function(key, value) {
    initializeUsabilityDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return false;
    }
    
    const preferences = JSON.parse(localStorage.getItem(DB_USER_PREFERENCES_KEY));
    
    if (!preferences[currentUser.id]) {
      preferences[currentUser.id] = {};
    }
    
    preferences[currentUser.id][key] = value;
    localStorage.setItem(DB_USER_PREFERENCES_KEY, JSON.stringify(preferences));
    
    return true;
  },

  // Obter preferências do usuário
  getUserPreference: function(key, defaultValue = null) {
    initializeUsabilityDB();
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return defaultValue;
    }
    
    const preferences = JSON.parse(localStorage.getItem(DB_USER_PREFERENCES_KEY));
    
    if (!preferences[currentUser.id] || preferences[currentUser.id][key] === undefined) {
      return defaultValue;
    }
    
    return preferences[currentUser.id][key];
  },

  // Validar formato de e-mail
  validateEmail: function(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  },

  // Validar força da senha
  validatePasswordStrength: function(password) {
    // Obter configurações de segurança
    let minLength = 8;
    let requireUppercase = true;
    let requireLowercase = true;
    let requireNumber = true;
    let requireSpecial = false;
    
    // Se o módulo de configurações estiver disponível, usar suas configurações
    if (window.ConfigAPI) {
      const config = window.ConfigAPI.getAll();
      minLength = config.passwordMinLength || minLength;
      requireUppercase = config.passwordRequireUppercase !== undefined ? config.passwordRequireUppercase : requireUppercase;
      requireLowercase = config.passwordRequireLowercase !== undefined ? config.passwordRequireLowercase : requireLowercase;
      requireNumber = config.passwordRequireNumber !== undefined ? config.passwordRequireNumber : requireNumber;
      requireSpecial = config.passwordRequireSpecial !== undefined ? config.passwordRequireSpecial : requireSpecial;
    }
    
    // Verificar comprimento mínimo
    if (password.length < minLength) {
      return {
        valid: false,
        message: `A senha deve ter pelo menos ${minLength} caracteres`
      };
    }
    
    // Verificar requisitos de caracteres
    if (requireUppercase && !/[A-Z]/.test(password)) {
      return {
        valid: false,
        message: 'A senha deve conter pelo menos uma letra maiúscula'
      };
    }
    
    if (requireLowercase && !/[a-z]/.test(password)) {
      return {
        valid: false,
        message: 'A senha deve conter pelo menos uma letra minúscula'
      };
    }
    
    if (requireNumber && !/[0-9]/.test(password)) {
      return {
        valid: false,
        message: 'A senha deve conter pelo menos um número'
      };
    }
    
    if (requireSpecial && !/[^A-Za-z0-9]/.test(password)) {
      return {
        valid: false,
        message: 'A senha deve conter pelo menos um caractere especial'
      };
    }
    
    return {
      valid: true,
      message: 'Senha válida'
    };
  },

  // Cadastrar novo usuário
  registerUser: function(userData) {
    // Validar dados do usuário
    if (!userData.nome || !userData.email || !userData.senha) {
      return {
        success: false,
        error: 'Nome, e-mail e senha são obrigatórios'
      };
    }
    
    // Validar formato de e-mail
    if (!this.validateEmail(userData.email)) {
      return {
        success: false,
        error: 'Formato de e-mail inválido'
      };
    }
    
    // Validar força da senha
    const passwordValidation = this.validatePasswordStrength(userData.senha);
    if (!passwordValidation.valid) {
      return {
        success: false,
        error: passwordValidation.message
      };
    }
    
    // Verificar se o e-mail já está em uso
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY) || '[]');
    if (users.some(user => user.email === userData.email)) {
      return {
        success: false,
        error: 'Este e-mail já está cadastrado'
      };
    }
    
    // Criar novo usuário
    const newUser = {
      id: 'user_' + Math.random().toString(36).substring(2, 9),
      nome: userData.nome,
      email: userData.email,
      senha: generatePasswordHash(userData.senha),
      dataCadastro: new Date().toISOString(),
      ultimoLogin: null,
      ativo: true,
      admin: false,
      verificado: false,
      tokenVerificacao: Math.random().toString(36).substring(2, 15)
    };
    
    // Salvar usuário
    users.push(newUser);
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    
    // Atribuir plano gratuito ao usuário
    if (window.PlansAPI) {
      window.PlansAPI.assignPlanToUser(newUser.id, 'free');
    }
    
    // Enviar e-mail de confirmação (simulado)
    this.sendVerificationEmail(newUser.email, newUser.tokenVerificacao);
    
    // Disparar webhook de cadastro
    if (window.WebhooksAPI) {
      window.WebhooksAPI.triggerEvent('user_registered', {
        userId: newUser.id,
        email: newUser.email,
        date: newUser.dataCadastro
      });
    }
    
    // Registrar atividade
    this.logActivity('register', {
      userId: newUser.id,
      email: newUser.email
    });
    
    return {
      success: true,
      user: {
        id: newUser.id,
        nome: newUser.nome,
        email: newUser.email,
        dataCadastro: newUser.dataCadastro,
        verificado: newUser.verificado
      }
    };
  },

  // Enviar e-mail de verificação (simulado)
  sendVerificationEmail: function(email, token) {
    console.log(`[SIMULAÇÃO] E-mail de verificação enviado para ${email} com token ${token}`);
    
    // Em produção, isso seria feito pelo backend com SMTP real
    return {
      success: true,
      message: 'E-mail de verificação enviado com sucesso'
    };
  },

  // Verificar e-mail com token
  verifyEmail: function(email, token) {
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY) || '[]');
    const userIndex = users.findIndex(user => user.email === email && user.tokenVerificacao === token);
    
    if (userIndex === -1) {
      return {
        success: false,
        error: 'Token de verificação inválido'
      };
    }
    
    // Atualizar status de verificação
    users[userIndex].verificado = true;
    users[userIndex].tokenVerificacao = null;
    
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    
    // Registrar atividade
    this.logActivity('verify_email', {
      userId: users[userIndex].id,
      email: users[userIndex].email
    });
    
    return {
      success: true,
      message: 'E-mail verificado com sucesso'
    };
  },

  // Solicitar redefinição de senha
  requestPasswordReset: function(email) {
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY) || '[]');
    const userIndex = users.findIndex(user => user.email === email);
    
    if (userIndex === -1) {
      // Por segurança, não informar que o e-mail não existe
      return {
        success: true,
        message: 'Se o e-mail estiver cadastrado, você receberá instruções para redefinir sua senha'
      };
    }
    
    // Gerar token de redefinição
    const resetToken = Math.random().toString(36).substring(2, 15);
    const expiration = new Date();
    expiration.setHours(expiration.getHours() + 1); // Token válido por 1 hora
    
    users[userIndex].resetToken = resetToken;
    users[userIndex].resetTokenExpiration = expiration.toISOString();
    
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    
    // Enviar e-mail de redefinição (simulado)
    console.log(`[SIMULAÇÃO] E-mail de redefinição enviado para ${email} com token ${resetToken}`);
    
    // Registrar atividade
    this.logActivity('request_password_reset', {
      userId: users[userIndex].id,
      email: users[userIndex].email
    });
    
    return {
      success: true,
      message: 'Instruções para redefinir sua senha foram enviadas para seu e-mail'
    };
  },

  // Redefinir senha com token
  resetPassword: function(email, token, newPassword) {
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY) || '[]');
    const userIndex = users.findIndex(user => user.email === email && user.resetToken === token);
    
    if (userIndex === -1) {
      return {
        success: false,
        error: 'Token de redefinição inválido'
      };
    }
    
    // Verificar se o token expirou
    const expiration = new Date(users[userIndex].resetTokenExpiration);
    if (expiration < new Date()) {
      return {
        success: false,
        error: 'Token de redefinição expirado'
      };
    }
    
    // Validar força da senha
    const passwordValidation = this.validatePasswordStrength(newPassword);
    if (!passwordValidation.valid) {
      return {
        success: false,
        error: passwordValidation.message
      };
    }
    
    // Atualizar senha
    users[userIndex].senha = generatePasswordHash(newPassword);
    users[userIndex].resetToken = null;
    users[userIndex].resetTokenExpiration = null;
    
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    
    // Registrar atividade
    this.logActivity('reset_password', {
      userId: users[userIndex].id,
      email: users[userIndex].email
    });
    
    return {
      success: true,
      message: 'Senha redefinida com sucesso'
    };
  },

  // Completar perfil após login social
  completeProfile: function(userData) {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return {
        success: false,
        error: 'Usuário não autenticado'
      };
    }
    
    // Validar dados do usuário
    if (!userData.nome) {
      return {
        success: false,
        error: 'Nome é obrigatório'
      };
    }
    
    // Atualizar dados do usuário
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY) || '[]');
    const userIndex = users.findIndex(user => user.id === currentUser.id);
    
    if (userIndex === -1) {
      return {
        success: false,
        error: 'Usuário não encontrado'
      };
    }
    
    // Atualizar campos
    users[userIndex].nome = userData.nome;
    
    if (userData.telefone) {
      users[userIndex].telefone = userData.telefone;
    }
    
    if (userData.empresa) {
      users[userIndex].empresa = userData.empresa;
    }
    
    if (userData.cargo) {
      users[userIndex].cargo = userData.cargo;
    }
    
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    
    // Atualizar usuário atual no localStorage
    const updatedUser = { ...currentUser, ...userData };
    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(updatedUser));
    
    // Registrar atividade
    this.logActivity('complete_profile', {
      userId: currentUser.id,
      email: currentUser.email
    });
    
    return {
      success: true,
      user: updatedUser
    };
  },

  // Verificar se o perfil está completo
  isProfileComplete: function() {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return false;
    }
    
    // Verificar campos obrigatórios
    return !!(currentUser.nome && currentUser.email);
  },

  // Verificar inatividade e fazer logout automático
  checkInactivity: function() {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return false;
    }
    
    // Obter última atividade
    const lastActivity = this.getUserPreference('lastActivity');
    
    if (!lastActivity) {
      // Registrar atividade atual
      this.saveUserPreference('lastActivity', new Date().toISOString());
      return false;
    }
    
    // Obter tempo de inatividade configurado (em minutos)
    let inactivityTimeout = 30; // Padrão: 30 minutos
    
    if (window.ConfigAPI) {
      const config = window.ConfigAPI.getAll();
      inactivityTimeout = config.sessionTimeout || inactivityTimeout;
    }
    
    // Verificar se passou o tempo de inatividade
    const lastActivityTime = new Date(lastActivity);
    const currentTime = new Date();
    const diffMinutes = (currentTime - lastActivityTime) / (1000 * 60);
    
    if (diffMinutes >= inactivityTimeout) {
      // Fazer logout automático
      fazerLogout();
      return true;
    }
    
    // Atualizar última atividade
    this.saveUserPreference('lastActivity', new Date().toISOString());
    return false;
  },

  // Registrar atividade para evitar logout por inatividade
  updateActivity: function() {
    this.saveUserPreference('lastActivity', new Date().toISOString());
  },

  // Obter sugestões de upgrade de plano
  getUpgradeSuggestions: function() {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser || !window.PlansAPI) {
      return [];
    }
    
    const userPlan = window.PlansAPI.getUserPlan();
    
    if (!userPlan) {
      return [];
    }
    
    const suggestions = [];
    
    // Verificar limitações do plano atual
    switch (userPlan.id) {
      case 'free':
        suggestions.push({
          feature: 'Testes',
          current: 'Apenas 2 testes com 10 perguntas cada',
          upgrade: 'Plano Intermediário: Todos os testes com 20 perguntas cada',
          planId: 'intermediario'
        });
        suggestions.push({
          feature: 'Análise 360',
          current: 'Não disponível',
          upgrade: 'Plano Premium: Análise 360 completa',
          planId: 'premium'
        });
        break;
      case 'intermediario':
        suggestions.push({
          feature: 'Perguntas por teste',
          current: '20 perguntas por teste',
          upgrade: 'Plano Premium: 30 perguntas por teste',
          planId: 'premium'
        });
        suggestions.push({
          feature: 'Análise 360',
          current: 'Não disponível',
          upgrade: 'Plano Premium: Análise 360 completa',
          planId: 'premium'
        });
        break;
      case 'premium':
        suggestions.push({
          feature: 'Base de Conhecimento',
          current: 'Adição ilimitada de perguntas',
          upgrade: 'Plano Parceiro: Recursos personalizados',
          planId: 'parceiro'
        });
        break;
    }
    
    return suggestions;
  },

  // Inicializar eventos de usabilidade
  initializeUsabilityEvents: function() {
    // Verificar inatividade a cada minuto
    setInterval(() => {
      this.checkInactivity();
    }, 60000);
    
    // Registrar atividade em interações do usuário
    document.addEventListener('click', () => {
      this.updateActivity();
    });
    
    document.addEventListener('keydown', () => {
      this.updateActivity();
    });
    
    // Registrar visualização de página
    this.logActivity('page_view', {
      url: window.location.href,
      title: document.title
    });
  }
};

// Exportar API
window.UsabilityAPI = UsabilityAPI;

// Inicializar eventos de usabilidade quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
  UsabilityAPI.initializeUsabilityDB();
  UsabilityAPI.initializeUsabilityEvents();
});
