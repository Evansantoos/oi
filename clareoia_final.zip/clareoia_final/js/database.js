// Simulação de banco de dados usando localStorage
// Estruturado para facilitar migração para PostgreSQL, Supabase ou outras soluções

// Chaves para armazenamento no localStorage
const DB_PROMPTS_KEY = "clareoia_prompts";
const DB_TRAININGS_KEY = "clareoia_trainings";

// Inicializar banco de dados
function initializeDatabase() {
  // Inicializar prompts se não existir
  if (!localStorage.getItem(DB_PROMPTS_KEY)) {
    localStorage.setItem(DB_PROMPTS_KEY, JSON.stringify({}));
  }

  // Inicializar treinamentos se não existir
  if (!localStorage.getItem(DB_TRAININGS_KEY)) {
    localStorage.setItem(DB_TRAININGS_KEY, JSON.stringify({}));
  }
}

// Gerar ID único
function generateId() {
  return 'id' + Math.random().toString(36).substring(2, 9);
}

// API de Prompts
const PromptsAPI = {
  // Obter todos os prompts
  getAll: function() {
    initializeDatabase();
    return JSON.parse(localStorage.getItem(DB_PROMPTS_KEY));
  },

  // Obter prompt por ID
  getById: function(id) {
    const prompts = this.getAll();
    return prompts[id];
  },

  // Obter prompts por treinamento
  getByTrainingId: function(trainingId) {
    const prompts = this.getAll();
    const result = {};
    
    Object.keys(prompts).forEach(id => {
      if (prompts[id].treinamentoId === trainingId) {
        result[id] = prompts[id];
      }
    });
    
    return result;
  },

  // Criar novo prompt
  create: function(promptData) {
    const prompts = this.getAll();
    const id = generateId();
    
    prompts[id] = {
      ...promptData,
      id: id,
      dataCriacao: new Date().toISOString()
    };
    
    localStorage.setItem(DB_PROMPTS_KEY, JSON.stringify(prompts));
    
    // Se o prompt estiver associado a um treinamento, atualizar o treinamento
    if (promptData.treinamentoId) {
      const training = TrainingsAPI.getById(promptData.treinamentoId);
      if (training) {
        if (!training.prompts) {
          training.prompts = [];
        }
        training.prompts.push(id);
        TrainingsAPI.update(promptData.treinamentoId, training);
      }
    }
    
    return { id, ...prompts[id] };
  },

  // Atualizar prompt existente
  update: function(id, promptData) {
    const prompts = this.getAll();
    
    if (!prompts[id]) {
      return null;
    }
    
    // Verificar se o treinamento foi alterado
    const oldTrainingId = prompts[id].treinamentoId;
    const newTrainingId = promptData.treinamentoId;
    
    if (oldTrainingId !== newTrainingId) {
      // Remover do treinamento antigo
      if (oldTrainingId) {
        const oldTraining = TrainingsAPI.getById(oldTrainingId);
        if (oldTraining && oldTraining.prompts) {
          oldTraining.prompts = oldTraining.prompts.filter(promptId => promptId !== id);
          TrainingsAPI.update(oldTrainingId, oldTraining);
        }
      }
      
      // Adicionar ao novo treinamento
      if (newTrainingId) {
        const newTraining = TrainingsAPI.getById(newTrainingId);
        if (newTraining) {
          if (!newTraining.prompts) {
            newTraining.prompts = [];
          }
          newTraining.prompts.push(id);
          TrainingsAPI.update(newTrainingId, newTraining);
        }
      }
    }
    
    prompts[id] = {
      ...prompts[id],
      ...promptData,
      dataAtualizacao: new Date().toISOString()
    };
    
    localStorage.setItem(DB_PROMPTS_KEY, JSON.stringify(prompts));
    return prompts[id];
  },

  // Excluir prompt
  delete: function(id) {
    const prompts = this.getAll();
    
    if (!prompts[id]) {
      return false;
    }
    
    // Remover do treinamento, se estiver associado
    const trainingId = prompts[id].treinamentoId;
    if (trainingId) {
      const training = TrainingsAPI.getById(trainingId);
      if (training && training.prompts) {
        training.prompts = training.prompts.filter(promptId => promptId !== id);
        TrainingsAPI.update(trainingId, training);
      }
    }
    
    delete prompts[id];
    localStorage.setItem(DB_PROMPTS_KEY, JSON.stringify(prompts));
    return true;
  }
};

// API de Treinamentos
const TrainingsAPI = {
  // Obter todos os treinamentos
  getAll: function() {
    initializeDatabase();
    return JSON.parse(localStorage.getItem(DB_TRAININGS_KEY));
  },

  // Obter treinamento por ID
  getById: function(id) {
    const trainings = this.getAll();
    return trainings[id];
  },

  // Obter treinamentos por plano
  getByPlan: function(planType) {
    const trainings = this.getAll();
    const result = {};
    
    Object.keys(trainings).forEach(id => {
      if (trainings[id].planoDisponivel && trainings[id].planoDisponivel.includes(planType)) {
        result[id] = trainings[id];
      }
    });
    
    return result;
  },

  // Obter treinamentos ativos
  getActive: function() {
    const trainings = this.getAll();
    const result = {};
    
    Object.keys(trainings).forEach(id => {
      if (trainings[id].ativo) {
        result[id] = trainings[id];
      }
    });
    
    return result;
  },

  // Criar novo treinamento
  create: function(trainingData) {
    const trainings = this.getAll();
    const id = generateId();
    
    trainings[id] = {
      ...trainingData,
      id: id,
      dataCriacao: new Date().toISOString(),
      prompts: trainingData.prompts || []
    };
    
    localStorage.setItem(DB_TRAININGS_KEY, JSON.stringify(trainings));
    
    // Atualizar os prompts associados
    if (trainingData.prompts && trainingData.prompts.length > 0) {
      trainingData.prompts.forEach(promptId => {
        const prompt = PromptsAPI.getById(promptId);
        if (prompt) {
          prompt.treinamentoId = id;
          PromptsAPI.update(promptId, prompt);
        }
      });
    }
    
    return { id, ...trainings[id] };
  },

  // Atualizar treinamento existente
  update: function(id, trainingData) {
    const trainings = this.getAll();
    
    if (!trainings[id]) {
      return null;
    }
    
    // Verificar se os prompts foram alterados
    const oldPrompts = trainings[id].prompts || [];
    const newPrompts = trainingData.prompts || [];
    
    // Prompts removidos
    oldPrompts.filter(promptId => !newPrompts.includes(promptId)).forEach(promptId => {
      const prompt = PromptsAPI.getById(promptId);
      if (prompt && prompt.treinamentoId === id) {
        prompt.treinamentoId = null;
        PromptsAPI.update(promptId, prompt);
      }
    });
    
    // Prompts adicionados
    newPrompts.filter(promptId => !oldPrompts.includes(promptId)).forEach(promptId => {
      const prompt = PromptsAPI.getById(promptId);
      if (prompt) {
        prompt.treinamentoId = id;
        PromptsAPI.update(promptId, prompt);
      }
    });
    
    trainings[id] = {
      ...trainings[id],
      ...trainingData,
      dataAtualizacao: new Date().toISOString()
    };
    
    localStorage.setItem(DB_TRAININGS_KEY, JSON.stringify(trainings));
    return trainings[id];
  },

  // Excluir treinamento
  delete: function(id) {
    const trainings = this.getAll();
    
    if (!trainings[id]) {
      return false;
    }
    
    // Desassociar todos os prompts
    const prompts = trainings[id].prompts || [];
    prompts.forEach(promptId => {
      const prompt = PromptsAPI.getById(promptId);
      if (prompt && prompt.treinamentoId === id) {
        prompt.treinamentoId = null;
        PromptsAPI.update(promptId, prompt);
      }
    });
    
    delete trainings[id];
    localStorage.setItem(DB_TRAININGS_KEY, JSON.stringify(trainings));
    return true;
  }
};

// Exportar APIs
window.PromptsAPI = PromptsAPI;
window.TrainingsAPI = TrainingsAPI;
