// Funções para o painel administrativo
document.addEventListener("DOMContentLoaded", () => {
  // Variáveis globais
  let sidebarCollapsed = false

  // Inicialização
  initSidebar()
  initNavigation()
  initModals()
  initPasswordToggles()
  loadDashboardData()

  // Inicializar sidebar
  function initSidebar() {
    const toggleBtn = document.getElementById("toggle-sidebar")
    const sidebar = document.querySelector(".sidebar")
    const content = document.querySelector(".content")

    toggleBtn.addEventListener("click", () => {
      sidebarCollapsed = !sidebarCollapsed

      if (sidebarCollapsed) {
        sidebar.classList.add("collapsed")
        content.classList.add("expanded")
      } else {
        sidebar.classList.remove("collapsed")
        content.classList.remove("expanded")
      }
    })
  }

  // Inicializar navegação
  function initNavigation() {
    const navItems = document.querySelectorAll(".nav-item")
    const sectionTitle = document.getElementById("section-title")

    navItems.forEach((item) => {
      item.addEventListener("click", function () {
        // Remover classe active de todos os itens
        navItems.forEach((i) => i.classList.remove("active"))

        // Adicionar classe active ao item clicado
        this.classList.add("active")

        // Obter a seção correspondente
        const sectionId = this.getAttribute("data-section")
        const sectionElement = document.getElementById(`${sectionId}-section`)

        // Esconder todas as seções
        document.querySelectorAll(".content-section").forEach((section) => {
          section.classList.remove("active")
        })

        // Mostrar a seção correspondente
        if (sectionElement) {
          sectionElement.classList.add("active")
          sectionTitle.textContent = this.querySelector("span").textContent
        }
      })
    })

    // Inicializar links "Ver Todos"
    document.querySelectorAll(".view-all").forEach((link) => {
      link.addEventListener("click", function (e) {
        e.preventDefault()

        const sectionId = this.getAttribute("data-section")
        if (sectionId) {
          // Encontrar o item de navegação correspondente e clicar nele
          const navItem = document.querySelector(`.nav-item[data-section="${sectionId}"]`)
          if (navItem) {
            navItem.click()
          }
        }
      })
    })
  }

  // Inicializar modais
  function initModals() {
    // Abrir modal de detalhes do usuário
    document.querySelectorAll(".view-user-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const userId = this.getAttribute("data-user-id")
        openUserDetailsModal(userId)
      })
    })

    // Abrir modal de upload de conhecimento
    document.getElementById("upload-knowledge-btn").addEventListener("click", () => {
      document.getElementById("upload-knowledge-modal").style.display = "block"
    })

    // Abrir modal de adicionar plano
    document.getElementById("add-plan-btn").addEventListener("click", () => {
      document.getElementById("add-plan-modal").style.display = "block"
    })

    // Fechar modais
    document.querySelectorAll(".close-modal").forEach((closeBtn) => {
      closeBtn.addEventListener("click", function () {
        this.closest(".modal").style.display = "none"
      })
    })

    // Fechar modal ao clicar fora
    window.addEventListener("click", (event) => {
      document.querySelectorAll(".modal").forEach((modal) => {
        if (event.target === modal) {
          modal.style.display = "none"
        }
      })
    })

    // Botões de cancelar
    document.getElementById("cancel-upload-btn").addEventListener("click", () => {
      document.getElementById("upload-knowledge-modal").style.display = "none"
    })

    document.getElementById("cancel-plan-btn").addEventListener("click", () => {
      document.getElementById("add-plan-modal").style.display = "none"
    })
  }

  // Inicializar toggles de senha
  function initPasswordToggles() {
    document.querySelectorAll(".toggle-password-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const targetId = this.getAttribute("data-target")
        const inputElement = document.getElementById(targetId)

        if (inputElement.type === "password") {
          inputElement.type = "text"
          this.innerHTML = '<i class="fas fa-eye-slash"></i>'
        } else {
          inputElement.type = "password"
          this.innerHTML = '<i class="fas fa-eye"></i>'
        }
      })
    })
  }

  // Carregar dados do dashboard
  function loadDashboardData() {
    // Simulação de dados para demonstração
    document.getElementById("total-users").textContent = "127"
    document.getElementById("total-tests").textContent = "438"
    document.getElementById("premium-users").textContent = "42"
    document.getElementById("total-360").textContent = "18"

    // Carregar usuários recentes
    const recentUsersTable = document.getElementById("recent-users-table")
    recentUsersTable.innerHTML = `
            <tr>
                <td>João Silva</td>
                <td>joao.silva@exemplo.com</td>
                <td>17/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Maria Oliveira</td>
                <td>maria.oliveira@exemplo.com</td>
                <td>16/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Carlos Santos</td>
                <td>carlos.santos@exemplo.com</td>
                <td>15/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Ana Pereira</td>
                <td>ana.pereira@exemplo.com</td>
                <td>15/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Roberto Almeida</td>
                <td>roberto.almeida@exemplo.com</td>
                <td>14/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
        `

    // Carregar testes recentes
    const recentTestsTable = document.getElementById("recent-tests-table")
    recentTestsTable.innerHTML = `
            <tr>
                <td>João Silva</td>
                <td>DISC</td>
                <td>Verdade</td>
                <td>17/05/2025</td>
            </tr>
            <tr>
                <td>Maria Oliveira</td>
                <td>Temperamento</td>
                <td>Clareza</td>
                <td>16/05/2025</td>
            </tr>
            <tr>
                <td>Carlos Santos</td>
                <td>Perfil Animal</td>
                <td>Verdade</td>
                <td>15/05/2025</td>
            </tr>
            <tr>
                <td>Ana Pereira</td>
                <td>DISC</td>
                <td>Essência</td>
                <td>15/05/2025</td>
            </tr>
            <tr>
                <td>Roberto Almeida</td>
                <td>Emoções</td>
                <td>Clareza</td>
                <td>14/05/2025</td>
            </tr>
        `

    // Inicializar lista de usuários
    initUsersList()

    // Inicializar lista de prompts
    initPromptsList()

    // Inicializar lista de arquivos de conhecimento
    initKnowledgeList()
  }

  // Inicializar lista de usuários
  function initUsersList() {
    const usersTable = document.getElementById("users-table")
    usersTable.innerHTML = `
            <tr>
                <td>João Silva</td>
                <td>joao.silva@exemplo.com</td>
                <td>(11) 98765-4321</td>
                <td>DISC, Temperamento, Perfil Animal</td>
                <td>17/05/2025 14:30</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="1">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Maria Oliveira</td>
                <td>maria.oliveira@exemplo.com</td>
                <td>(21) 98765-4321</td>
                <td>DISC, Temperamento</td>
                <td>16/05/2025 10:15</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="2">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Carlos Santos</td>
                <td>carlos.santos@exemplo.com</td>
                <td>(31) 98765-4321</td>
                <td>DISC, Perfil Animal</td>
                <td>15/05/2025 16:45</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="3">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Ana Pereira</td>
                <td>ana.pereira@exemplo.com</td>
                <td>(41) 98765-4321</td>
                <td>DISC</td>
                <td>15/05/2025 09:20</td>
                <td><span class="badge badge-secondary">Gratuito</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="4">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Roberto Almeida</td>
                <td>roberto.almeida@exemplo.com</td>
                <td>(51) 98765-4321</td>
                <td>DISC, Emoções</td>
                <td>14/05/2025 11:30</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="5">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
        `

    // Adicionar evento aos botões de visualização
    document.querySelectorAll(".view-user-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const userId = this.getAttribute("data-user-id")
        openUserDetailsModal(userId)
      })
    })
  }

  // Inicializar lista de prompts
  function initPromptsList() {
    const promptsList = document.getElementById("prompts-list")
    const promptItems = promptsList.querySelectorAll(".prompt-item")

    promptItems.forEach((item) => {
      item.addEventListener("click", function () {
        // Remover classe active de todos os itens
        promptItems.forEach((i) => i.classList.remove("active"))

        // Adicionar classe active ao item clicado
        this.classList.add("active")

        // Obter o tipo de teste
        const testType = this.getAttribute("data-test")

        // Atualizar título do prompt
        document.getElementById("current-prompt-title").textContent =
          `Prompt para ${this.querySelector("h4").textContent}`

        // Carregar conteúdo do prompt (simulado)
        loadPromptContent(testType)
      })
    })

    // Inicializar controle de temperatura
    const temperatureSlider = document.getElementById("prompt-temperature")
    const temperatureValue = document.getElementById("temperature-value")

    temperatureSlider.addEventListener("input", function () {
      temperatureValue.textContent = this.value
    })

    // Botões de salvar e testar prompt
    document.getElementById("save-prompt-btn").addEventListener("click", () => {
      alert("Prompt salvo com sucesso!")
    })

    document.getElementById("test-prompt-btn").addEventListener("click", () => {
      alert("Teste de prompt iniciado. Isso pode levar alguns segundos...")
    })
  }

  // Carregar conteúdo do prompt
  function loadPromptContent(testType) {
    const promptName = document.getElementById("prompt-name")
    const promptText = document.getElementById("prompt-text")
    const promptModel = document.getElementById("prompt-model")
    const promptTemperature = document.getElementById("prompt-temperature")
    const temperatureValue = document.getElementById("temperature-value")

    // Conteúdo simulado para cada tipo de teste
    const promptContents = {
      disc: {
        name: "Prompt para análise DISC",
        text: `Você é um Especialista DISC. Com base nas respostas a seguir, identifique o perfil comportamental do usuário segundo o método DISC: Dominância (D), Influência (I), Estabilidade (S) e Conformidade (C).

Analise as respostas e determine:
1. Perfil dominante (letra com maior pontuação)
2. Perfil secundário (segunda letra com maior pontuação)
3. Pontuação para cada perfil (D, I, S, C)
4. 5 pontos fortes baseados no perfil
5. 5 pontos a desenvolver
6. Um resumo comportamental

Formato da resposta:
{
  "perfil_dominante": "D/I/S/C",
  "perfil_dominante_nome": "Nome do perfil dominante",
  "perfil_secundario": "D/I/S/C",
  "perfil_secundario_nome": "Nome do perfil secundário",
  "pontuacao": {
    "D": X,
    "I": X,
    "S": X,
    "C": X
  },
  "pontos_fortes": [
    "Ponto forte 1",
    "Ponto forte 2",
    "Ponto forte 3",
    "Ponto forte 4",
    "Ponto forte 5"
  ],
  "pontos_desenvolver": [
    "Ponto a desenvolver 1",
    "Ponto a desenvolver 2",
    "Ponto a desenvolver 3",
    "Ponto a desenvolver 4",
    "Ponto a desenvolver 5"
  ],
  "resumo": "Texto detalhado com análise comportamental"
}`,
        model: "gpt-4",
        temperature: 0.7,
      },
      temperamento: {
        name: "Prompt para análise de Temperamento",
        text: `Você é um Especialista em Temperamentos. Com base nas respostas a seguir, identifique o temperamento predominante do usuário: Sanguíneo, Colérico, Melancólico ou Fleumático.

Analise as respostas e determine:
1. Temperamento dominante (com maior pontuação)
2. Temperamento secundário (segundo com maior pontuação)
3. Pontuação para cada temperamento
4. 5 pontos fortes baseados no perfil
5. 5 pontos a desenvolver
6. Um resumo comportamental

Formato da resposta:
{
  "temperamento_dominante": "Sanguíneo/Colérico/Melancólico/Fleumático",
  "temperamento_secundario": "Sanguíneo/Colérico/Melancólico/Fleumático",
  "pontuacao": {
    "Sanguíneo": X,
    "Colérico": X,
    "Melancólico": X,
    "Fleumático": X
  },
  "pontos_fortes": [
    "Ponto forte 1",
    "Ponto forte 2",
    "Ponto forte 3",
    "Ponto forte 4",
    "Ponto forte 5"
  ],
  "pontos_desenvolver": [
    "Ponto a desenvolver 1",
    "Ponto a desenvolver 2",
    "Ponto a desenvolver 3",
    "Ponto a desenvolver 4",
    "Ponto a desenvolver 5"
  ],
  "resumo": "Texto detalhado com análise comportamental"
}`,
        model: "gpt-4",
        temperature: 0.7,
      },
      personalidade: {
        name: "Prompt para análise de Personalidade",
        text: `Você é um Especialista em Personalidade. Com base nas respostas a seguir, identifique os traços de personalidade predominantes do usuário.

Analise as respostas e determine:
1. Traços dominantes de personalidade
2. Traços secundários de personalidade
3. 5 pontos fortes baseados no perfil
4. 5 pontos a desenvolver
5. Um resumo comportamental

Formato da resposta:
{
  "tracos_dominantes": ["Traço 1", "Traço 2"],
  "tracos_secundarios": ["Traço 3", "Traço 4"],
  "pontos_fortes": [
    "Ponto forte 1",
    "Ponto forte 2",
    "Ponto forte 3",
    "Ponto forte 4",
    "Ponto forte 5"
  ],
  "pontos_desenvolver": [
    "Ponto a desenvolver 1",
    "Ponto a desenvolver 2",
    "Ponto a desenvolver 3",
    "Ponto a desenvolver 4",
    "Ponto a desenvolver 5"
  ],
  "resumo": "Texto detalhado com análise comportamental"
}`,
        model: "gpt-4",
        temperature: 0.7,
      },
      animal: {
        name: "Prompt para análise de Perfil Animal",
        text: `Você é um Especialista em Perfil Animal. Com base nas respostas a seguir, identifique o perfil animal predominante do usuário: Águia, Lobo, Tubarão ou Gato.

Analise as respostas e determine:
1. Perfil animal dominante
2. Perfil animal secundário
3. 5 pontos fortes baseados no perfil
4. 5 pontos a desenvolver
5. Um resumo comportamental

Formato da resposta:
{
  "perfil_dominante": "Águia/Lobo/Tubarão/Gato",
  "perfil_secundario": "Águia/Lobo/Tubarão/Gato",
  "pontos_fortes": [
    "Ponto forte 1",
    "Ponto forte 2",
    "Ponto forte 3",
    "Ponto forte 4",
    "Ponto forte 5"
  ],
  "pontos_desenvolver": [
    "Ponto a desenvolver 1",
    "Ponto a desenvolver 2",
    "Ponto a desenvolver 3",
    "Ponto a desenvolver 4",
    "Ponto a desenvolver 5"
  ],
  "resumo": "Texto detalhado com análise comportamental"
}`,
        model: "gpt-4",
        temperature: 0.7,
      },
      emocoes: {
        name: "Prompt para análise de Emoções",
        text: `Você é um Especialista em Inteligência Emocional. Com base nas respostas a seguir, identifique o perfil emocional do usuário.

Analise as respostas e determine:
1. Padrões emocionais dominantes
2. Padrões emocionais secundários
3. 5 pontos fortes baseados no perfil
4. 5 pontos a desenvolver
5. Um resumo comportamental

Formato da resposta:
{
  "padroes_dominantes": ["Padrão 1", "Padrão 2"],
  "padroes_secundarios": ["Padrão 3", "Padrão 4"],
  "pontos_fortes": [
    "Ponto forte 1",
    "Ponto forte 2",
    "Ponto forte 3",
    "Ponto forte 4",
    "Ponto forte 5"
  ],
  "pontos_desenvolver": [
    "Ponto a desenvolver 1",
    "Ponto a desenvolver 2",
    "Ponto a desenvolver 3",
    "Ponto a desenvolver 4",
    "Ponto a desenvolver 5"
  ],
  "resumo": "Texto detalhado com análise comportamental"
}`,
        model: "gpt-4",
        temperature: 0.7,
      },
      analise360: {
        name: "Prompt para Análise 360°",
        text: `Você é um Especialista em Análise Comportamental 360°. Com base nos resultados dos testes DISC, Temperamento, Perfil Animal e Emoções, faça uma análise completa e integrada do perfil comportamental do usuário.

Analise os resultados e determine:
1. Perfil comportamental integrado
2. Tendência comportamental dominante
3. Modo de agir, pensar e sentir
4. Reações sob pressão e mudança
5. Estilo de trabalho ideal
6. Estilo de liderança e comunicação
7. Sugestão de caminhos profissionais
8. Recomendações com base nos objetivos do usuário

Formato da resposta:
{
  "perfil_integrado": "Descrição do perfil integrado",
  "tendencia_dominante": "Descrição da tendência dominante",
  "modo_agir_pensar_sentir": "Descrição do modo de agir, pensar e sentir",
  "reacoes_pressao_mudanca": "Descrição das reações sob pressão e mudança",
  "estilo_trabalho_ideal": "Descrição do estilo de trabalho ideal",
  "estilo_lideranca_comunicacao": "Descrição do estilo de liderança e comunicação",
  "caminhos_profissionais": [
    "Caminho 1",
    "Caminho 2",
    "Caminho 3"
  ],
  "recomendacoes": [
    "Recomendação 1",
    "Recomendação 2",
    "Recomendação 3",
    "Recomendação 4",
    "Recomendação 5"
  ],
  "resumo": "Texto detalhado com análise comportamental integrada"
}`,
        model: "gpt-4",
        temperature: 0.7,
      },
    }

    // Definir valores
    const content = promptContents[testType] || promptContents["disc"]

    promptName.value = content.name
    promptText.value = content.text
    promptModel.value = content.model
    promptTemperature.value = content.temperature
    temperatureValue.textContent = content.temperature
  }

  // Inicializar lista de arquivos de conhecimento
  function initKnowledgeList() {
    const knowledgeTable = document.getElementById("knowledge-table")
    knowledgeTable.innerHTML = `
            <tr>
                <td>DISC_Teoria_Completa.pdf</td>
                <td>PDF</td>
                <td>DISC</td>
                <td>2.4 MB</td>
                <td>15/05/2025</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>Temperamentos_Guia_Completo.pdf</td>
                <td>PDF</td>
                <td>Temperamento</td>
                <td>1.8 MB</td>
                <td>14/05/2025</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>Perfil_Animal_Referencia.docx</td>
                <td>DOCX</td>
                <td>Perfil Animal</td>
                <td>1.2 MB</td>
                <td>13/05/2025</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>Inteligencia_Emocional.pdf</td>
                <td>PDF</td>
                <td>Emoções</td>
                <td>3.1 MB</td>
                <td>12/05/2025</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>Analise_360_Metodologia.md</td>
                <td>MD</td>
                <td>Análise 360°</td>
                <td>0.5 MB</td>
                <td>10/05/2025</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `
  }

  // Abrir modal de detalhes do usuário
  function openUserDetailsModal(userId) {
    const modal = document.getElementById("user-details-modal")

    // Carregar dados do usuário (simulado)
    document.getElementById("user-detail-name").textContent = "João Silva"
    document.getElementById("user-detail-email").textContent = "joao.silva@exemplo.com"
    document.getElementById("user-detail-phone").textContent = "(11) 98765-4321"
    document.getElementById("user-detail-profession").textContent = "Gerente de RH"
    document.getElementById("user-detail-segment").textContent = "Tecnologia"
    document.getElementById("user-detail-position").textContent = "Gerente"
    document.getElementById("user-detail-cnpj").textContent = "12.345.678/0001-90"
    document.getElementById("user-detail-register-date").textContent = "10/05/2025"
    document.getElementById("user-detail-last-activity").textContent = "17/05/2025 14:30"

    document.getElementById("user-detail-plan").textContent = "Nível Verdade"
    document.getElementById("user-detail-status").textContent = "Ativo"
    document.getElementById("user-detail-expiration").textContent = "10/06/2025"
    document.getElementById("user-detail-360-credits").textContent = "1"

    // Carregar testes do usuário (simulado)
    const userTestsTable = document.getElementById("user-tests-table")
    userTestsTable.innerHTML = `
            <tr>
                <td>DISC</td>
                <td>Verdade</td>
                <td>17/05/2025</td>
                <td>Dominância (D) - Influência (I)</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-file-pdf"></i> PDF
                    </button>
                </td>
            </tr>
            <tr>
                <td>Temperamento</td>
                <td>Verdade</td>
                <td>15/05/2025</td>
                <td>Colérico - Sanguíneo</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-file-pdf"></i> PDF
                    </button>
                </td>
            </tr>
            <tr>
                <td>Perfil Animal</td>
                <td>Verdade</td>
                <td>12/05/2025</td>
                <td>Águia - Lobo</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-file-pdf"></i> PDF
                    </button>
                </td>
            </tr>
            <tr>
                <td>Análise 360°</td>
                <td>Completo</td>
                <td>17/05/2025</td>
                <td>Perfil Integrado</td>
                <td>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                    <button class="btn btn-sm btn-outline">
                        <i class="fas fa-file-pdf"></i> PDF
                    </button>
                </td>
            </tr>
        `

    // Exibir modal
    modal.style.display = "block"

    // Adicionar eventos aos botões de ação
    document.getElementById("grant-access-btn").addEventListener("click", () => {
      alert("Acesso liberado para o usuário João Silva!")
    })

    document.getElementById("add-360-credit-btn").addEventListener("click", () => {
      alert("Crédito de Análise 360° adicionado para o usuário João Silva!")
    })

    document.getElementById("reset-password-btn").addEventListener("click", () => {
      alert("Senha resetada para o usuário João Silva! Um e-mail foi enviado com as instruções.")
    })
  }

  // Inicializar botões de ação
  document.getElementById("export-users-btn").addEventListener("click", () => {
    alert("Exportação de usuários iniciada. O arquivo será baixado em breve.")
  })

  document.getElementById("user-search-btn").addEventListener("click", () => {
    const searchTerm = document.getElementById("user-search").value
    alert(`Pesquisando por: ${searchTerm}`)
  })

  document.getElementById("confirm-upload-btn").addEventListener("click", () => {
    alert("Upload de arquivo iniciado. Isso pode levar alguns segundos...")
    document.getElementById("upload-knowledge-modal").style.display = "none"
  })

  document.getElementById("confirm-plan-btn").addEventListener("click", () => {
    alert("Novo plano adicionado com sucesso!")
    document.getElementById("add-plan-modal").style.display = "none"
  })

  document.getElementById("grant-free-access-btn").addEventListener("click", () => {
    const email = document.getElementById("free-access-email").value
    const level = document.getElementById("free-access-level").value
    const duration = document.getElementById("free-access-duration").value

    if (email) {
      alert(`Acesso gratuito ao nível ${level} liberado para ${email} por ${duration} dias!`)
    } else {
      alert("Por favor, informe o e-mail do usuário.")
    }
  })

  // Botões de teste de integração
  document.getElementById("test-openai-btn").addEventListener("click", () => {
    //alert("Teste de conexão com OpenAI bem-sucedido!")
    const apiKey = document.getElementById("openai-api-key").value
    testOpenAIConnection(apiKey)
      .then((isConnected) => {
        if (isConnected) {
          alert("Teste de conexão com OpenAI bem-sucedido!")
        } else {
          alert("Teste de conexão com OpenAI falhou. Verifique a chave.")
        }
      })
      .catch((error) => {
        console.error("Erro ao testar conexão com OpenAI:", error)
        alert("Erro ao testar conexão com OpenAI. Verifique o console.")
      })
  })

  document.getElementById("test-evolution-btn").addEventListener("click", () => {
    alert("Teste de conexão com Evolution API falhou. Verifique as credenciais.")
  })

  document.getElementById("test-webhook-btn").addEventListener("click", () => {
    alert("Teste de webhook enviado com sucesso!")
  })

  document.getElementById("test-sheets-btn").addEventListener("click", () => {
    alert("Teste de conexão com Google Sheets bem-sucedido!")
  })

  // Botões de salvar configurações
  document.getElementById("save-openai-btn").addEventListener("click", () => {
    alert("Configurações da OpenAI salvas com sucesso!")
  })

  document.getElementById("save-evolution-btn").addEventListener("click", () => {
    alert("Configurações da Evolution API salvas com sucesso!")
  })

  document.getElementById("save-webhook-btn").addEventListener("click", () => {
    alert("Configurações de webhook salvas com sucesso!")
  })

  document.getElementById("save-sheets-btn").addEventListener("click", () => {
    alert("Configurações do Google Sheets salvas com sucesso!")
  })

  document.getElementById("save-general-settings-btn").addEventListener("click", () => {
    alert("Configurações gerais salvas com sucesso!")
  })

  document.getElementById("save-admin-settings-btn").addEventListener("click", () => {
    const password = document.getElementById("admin-password").value
    const confirmPassword = document.getElementById("admin-password-confirm").value

    if (password && password === confirmPassword) {
      alert("Configurações de administrador salvas com sucesso!")
    } else {
      alert("As senhas não coincidem ou estão em branco.")
    }
  })

  document.getElementById("save-notification-settings-btn").addEventListener("click", () => {
    alert("Configurações de notificação salvas com sucesso!")
  })

  // Botões de edição de planos
  document.getElementById("edit-free-plan-btn").addEventListener("click", () => {
    alert("Edição do plano Nível Essência iniciada.")
  })

  document.getElementById("edit-clarity-plan-btn").addEventListener("click", () => {
    alert("Edição do plano Nível Clareza iniciada.")
  })

  document.getElementById("edit-truth-plan-btn").addEventListener("click", () => {
    alert("Edição do plano Nível Verdade iniciada.")
  })

  document.getElementById("edit-complete-plan-btn").addEventListener("click", () => {
    alert("Edição do plano Completo iniciada.")
  })

  // Logout
  document.getElementById("logout-btn").addEventListener("click", (e) => {
    e.preventDefault()
    if (confirm("Tem certeza que deseja sair?")) {
      window.location.href = "../login.html"
    }
  })
})

// Função para testar conexão com OpenAI
async function testOpenAIConnection(apiKey) {
  // Em produção, fazer uma requisição real para a API da OpenAI
  // Aqui, implementamos uma validação mais robusta
  return new Promise((resolve, reject) => {
    // Verificar formato básico da chave
    if (!apiKey.startsWith("sk-") || apiKey.length < 20) {
      resolve(false)
      return
    }

    // Simular uma requisição real à API
    setTimeout(() => {
      try {
        // Fazer uma requisição de teste para a API da OpenAI
        // Em um ambiente real, isso seria uma chamada fetch real
        console.log("Testando conexão com OpenAI usando a chave:", apiKey.substring(0, 5) + "...")

        // Validação mais robusta (simulada)
        const isValid = apiKey.startsWith("sk-") && apiKey.length >= 30

        if (isValid) {
          console.log("Conexão com OpenAI validada com sucesso")
          resolve(true)
        } else {
          console.log("Falha na validação da chave OpenAI")
          resolve(false)
        }
      } catch (error) {
        console.error("Erro ao validar chave OpenAI:", error)
        reject(error)
      }
    }, 1500)
  })
}
