// Funções de autenticação e gerenciamento de usuários

// Variáveis globais
let currentUser = null
const DB_USERS_KEY = "multitests_users"
const DB_ADMINS_KEY = "multitests_admins"
const DB_CURRENT_USER_KEY = "multitests_current_user"
const AUTH_TOKEN_KEY = "multitests_auth_token"
const RESET_TOKENS_KEY = "multitests_reset_tokens"
const REDIRECT_COUNT_KEY = "multitests_redirect_count" // Nova chave para controlar redirecionamentos

// Inicializar banco de dados local (simulação)
function initializeLocalDB() {
  // Inicializar usuários se não existir
  if (!localStorage.getItem(DB_USERS_KEY)) {
    localStorage.setItem(DB_USERS_KEY, JSON.stringify([]))
  }

  // Inicializar administradores se não existir
  if (!localStorage.getItem(DB_ADMINS_KEY)) {
    // Criar administrador padrão
    const defaultAdmin = {
      id: generateUUID(),
      nome: "Administrador",
      email: "admin@startinc.com.br",
      telefone: "(51) 99149-0515",
      senha: hashPassword("admin2025"),
      data_cadastro: new Date().toISOString(),
      ultimo_acesso: new Date().toISOString(),
      role: "admin",
    }

    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify([defaultAdmin]))
    console.log("Administrador padrão criado com sucesso!")
    console.log("Email: admin@startinc.com.br")
    console.log("Senha: admin2025")
  }

  // Inicializar tokens de redefinição se não existir
  if (!localStorage.getItem(RESET_TOKENS_KEY)) {
    localStorage.setItem(RESET_TOKENS_KEY, JSON.stringify([]))
  }
}

// Gerar UUID
function generateUUID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === "x" ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

// Gerar hash de senha (simulação - em produção usar bcrypt ou similar)
function hashPassword(password) {
  // Em produção, usar bcrypt ou similar
  // Esta é apenas uma simulação básica de hash
  return btoa(password + "salt_random_for_security")
}

// Verificar senha (simulação - em produção usar bcrypt.compare ou similar)
function verifyPassword(password, hashedPassword) {
  // Em produção, usar bcrypt.compare ou similar
  // Esta é apenas uma simulação básica de verificação
  return hashedPassword === btoa(password + "salt_random_for_security")
}

// Gerar token de autenticação mais seguro
function generateAuthToken(userId, isAdmin = false) {
  // Criar dados do token com timestamp e expiração
  const tokenData = {
    userId: userId,
    isAdmin: isAdmin,
    timestamp: new Date().getTime(),
    expiry: new Date().getTime() + 30 * 60 * 1000, // 30 minutos
    // Adicionar um nonce aleatório para aumentar a segurança
    nonce: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
  }

  // Em produção, usar JWT ou similar
  // Esta é uma simulação básica de token criptografado
  const tokenString = JSON.stringify(tokenData)
  // Criptografia mais robusta para demonstração
  return btoa(tokenString + "_" + Math.random().toString(36).substring(2) + "_" + new Date().getTime())
}

// Verificar token de autenticação
function verifyAuthToken(token) {
  try {
    // Decodificar o token (remover a parte aleatória após o "_")
    const tokenParts = atob(token).split("_")
    const tokenData = JSON.parse(tokenParts[0])
    const now = new Date().getTime()

    // Verificar se o token expirou
    if (tokenData.expiry < now) {
      console.log("Token expirado")
      return null
    }

    // Renovar o token para estender a sessão
    if (tokenData.expiry - now < 10 * 60 * 1000) {
      const renewedToken = generateAuthToken(tokenData.userId, tokenData.isAdmin)
      localStorage.setItem(AUTH_TOKEN_KEY, renewedToken)
    }

    return {
      userId: tokenData.userId,
      isAdmin: tokenData.isAdmin,
    }
  } catch (error) {
    console.error("Erro ao verificar token:", error)
    return null
  }
}

// Cadastrar novo usuário
function cadastrarUsuario(nome, email, telefone, senha, dadosAdicionais = {}) {
  initializeLocalDB()

  // Verificar se o e-mail já está cadastrado (usuários)
  const users = JSON.parse(localStorage.getItem(DB_USERS_KEY))
  const userExists = users.some((user) => user.email === email)

  if (userExists) {
    showNotification("Este e-mail já está cadastrado.", "error")
    return false
  }

  // Verificar se o e-mail já está cadastrado (administradores)
  const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY))
  const adminExists = admins.some((admin) => admin.email === email)

  if (adminExists) {
    showNotification("Este e-mail já está cadastrado.", "error")
    return false
  }

  // Criar novo usuário
  const newUser = {
    id: generateUUID(),
    nome: nome,
    email: email,
    telefone: telefone,
    senha: hashPassword(senha),
    data_cadastro: new Date().toISOString(),
    ultimo_acesso: new Date().toISOString(),
    role: "user",
    ...dadosAdicionais,
  }

  // Adicionar ao banco de dados local
  users.push(newUser)
  localStorage.setItem(DB_USERS_KEY, JSON.stringify(users))

  // Gerar token de autenticação
  const authToken = generateAuthToken(newUser.id, false)
  localStorage.setItem(AUTH_TOKEN_KEY, authToken)

  // Salvar usuário atual
  const currentUserData = { ...newUser }
  delete currentUserData.senha // Não armazenar senha em memória
  localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUserData))
  currentUser = currentUserData

  // Resetar contador de redirecionamentos
  resetRedirectCount()

  showNotification("Cadastro realizado com sucesso!", "success")

  // Redirecionar para o painel
  setTimeout(() => {
    window.location.href = "painel.html"
  }, 1500)

  return true
}

// Fazer login (usuário ou admin)
function fazerLogin(email, senha) {
  initializeLocalDB()

  // Buscar usuário pelo e-mail
  const users = JSON.parse(localStorage.getItem(DB_USERS_KEY))
  const user = users.find((user) => user.email === email)

  // Buscar admin pelo e-mail
  const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY))
  const admin = admins.find((admin) => admin.email === email)

  // Verificar se é usuário
  if (user) {
    // Verificar senha
    if (!verifyPassword(senha, user.senha)) {
      return {
        success: false,
        message: "E-mail ou senha incorretos."
      }
    }

    // Atualizar último acesso
    user.ultimo_acesso = new Date().toISOString()
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users))

    // Gerar token de autenticação
    const authToken = generateAuthToken(user.id, false)
    localStorage.setItem(AUTH_TOKEN_KEY, authToken)

    // Salvar usuário atual
    const currentUserData = { ...user }
    delete currentUserData.senha // Não armazenar senha em memória
    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUserData))
    currentUser = currentUserData

    // Resetar contador de redirecionamentos
    resetRedirectCount()

    showNotification("Login realizado com sucesso!", "success")

    return {
      success: true,
      message: "Login realizado com sucesso!"
    }
  }

  // Verificar se é admin
  if (admin) {
    // Verificar senha
    if (!verifyPassword(senha, admin.senha)) {
      return {
        success: false,
        message: "E-mail ou senha incorretos."
      }
    }

    // Atualizar último acesso
    admin.ultimo_acesso = new Date().toISOString()
    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins))

    // Gerar token de autenticação
    const authToken = generateAuthToken(admin.id, true)
    localStorage.setItem(AUTH_TOKEN_KEY, authToken)

    // Salvar usuário atual
    const currentUserData = { ...admin }
    delete currentUserData.senha // Não armazenar senha em memória
    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUserData))
    currentUser = currentUserData

    // Resetar contador de redirecionamentos
    resetRedirectCount()

    showNotification("Login realizado com sucesso!", "success")

    return {
      success: true,
      message: "Login realizado com sucesso!"
    }
  }

  // Se não encontrou usuário nem admin
  return {
    success: false,
    message: "E-mail ou senha incorretos."
  }
}

// Login com provedor social - FUNÇÃO CORRIGIDA
function loginSocial(provider) {
  console.log(`Iniciando login com ${provider}...`)
  showNotification(`Conectando com ${provider}...`, "info")

  // Resetar contador de redirecionamentos
  resetRedirectCount()

  setTimeout(() => {
    // Gerar um ID único para o novo usuário
    const newId = generateUUID()

    // Criar dados completos do usuário
    const userData = {
      id: newId,
      nome: `Usuário ${provider}`,
      email: `usuario.${provider.toLowerCase()}@exemplo.com`,
      telefone: "(00) 00000-0000",
      data_cadastro: new Date().toISOString(),
      ultimo_acesso: new Date().toISOString(),
      role: "user",
      provider: provider,
    }

    // CORREÇÃO: Primeiro salvar o usuário no banco de dados de usuários
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY)) || []
    
    // Verificar se o usuário já existe (pelo provider e email)
    const existingUserIndex = users.findIndex(user => 
      user.provider === provider && user.email === userData.email
    )
    
    if (existingUserIndex >= 0) {
      // Atualizar usuário existente
      users[existingUserIndex].ultimo_acesso = new Date().toISOString()
      userData.id = users[existingUserIndex].id // Manter o ID original
    } else {
      // Adicionar novo usuário
      users.push(userData)
    }
    
    // Salvar no banco de dados
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users))

    // Gerar token de autenticação
    const authToken = generateAuthToken(userData.id, false)
    localStorage.setItem(AUTH_TOKEN_KEY, authToken)

    // Salvar como usuário atual
    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(userData))
    currentUser = userData

    showNotification(`Login com ${provider} realizado com sucesso!`, "success")

    // Redirecionar para o painel com caminho relativo simples
    setTimeout(() => {
      window.location.href = "painel.html"
    }, 1500)
  }, 2000)
}

// Fazer logout
function fazerLogout() {
  localStorage.removeItem(AUTH_TOKEN_KEY)
  localStorage.removeItem(DB_CURRENT_USER_KEY)
  localStorage.removeItem(REDIRECT_COUNT_KEY)
  currentUser = null

  showNotification("Logout realizado com sucesso!", "success")

  // Redirecionar para a página inicial
  setTimeout(() => {
    window.location.href = "index.html"
  }, 1500)
}

// Controle de redirecionamentos para evitar loops infinitos
function getRedirectCount() {
  const count = localStorage.getItem(REDIRECT_COUNT_KEY)
  return count ? parseInt(count) : 0
}

function incrementRedirectCount() {
  const count = getRedirectCount()
  localStorage.setItem(REDIRECT_COUNT_KEY, (count + 1).toString())
  return count + 1
}

// Expor a função resetRedirectCount globalmente para que possa ser acessada de qualquer lugar
function resetRedirectCount() {
  localStorage.setItem(REDIRECT_COUNT_KEY, "0")
}

// Garantir que resetRedirectCount esteja disponível globalmente
window.resetRedirectCount = resetRedirectCount;

// Verificar autenticação - FUNÇÃO CORRIGIDA
function verificarAutenticacao() {
  // Verificar se já estamos em um loop de redirecionamento
  const redirectCount = getRedirectCount()
  if (redirectCount > 3) {
    console.error("Detectado possível loop de redirecionamento. Limpando dados de autenticação.")
    localStorage.removeItem(AUTH_TOKEN_KEY)
    localStorage.removeItem(DB_CURRENT_USER_KEY)
    resetRedirectCount()
    return false
  }

  const authToken = localStorage.getItem(AUTH_TOKEN_KEY)
  if (!authToken) {
    return false
  }

  const tokenData = verifyAuthToken(authToken)
  if (!tokenData) {
    // Token inválido ou expirado
    localStorage.removeItem(AUTH_TOKEN_KEY)
    localStorage.removeItem(DB_CURRENT_USER_KEY)
    currentUser = null
    return false
  }

  // Carregar usuário atual do localStorage
  const userData = localStorage.getItem(DB_CURRENT_USER_KEY)
  
  // CORREÇÃO: Se o token é válido mas não há dados do usuário, tentar recuperar do banco
  if (!userData) {
    console.log("Token válido, mas dados do usuário não encontrados. Tentando recuperar...")
    
    // Buscar usuário pelo ID no token
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY)) || []
    const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY)) || []
    
    let foundUser = users.find(user => user.id === tokenData.userId)
    
    // Se não encontrou nos usuários comuns, buscar nos admins
    if (!foundUser && tokenData.isAdmin) {
      foundUser = admins.find(admin => admin.id === tokenData.userId)
    }
    
    // Se encontrou o usuário, restaurar os dados
    if (foundUser) {
      const restoredUser = { ...foundUser }
      delete restoredUser.senha // Não armazenar senha em memória
      
      localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(restoredUser))
      currentUser = restoredUser
      console.log("Dados do usuário recuperados com sucesso!")
      return true
    }
    
    // Se não encontrou o usuário, invalidar o token
    console.error("Usuário não encontrado no banco de dados. Invalidando token.")
    localStorage.removeItem(AUTH_TOKEN_KEY)
    return false
  }

  // Atualizar variável global currentUser
  try {
    currentUser = JSON.parse(userData)
    return true
  } catch (error) {
    console.error("Erro ao processar dados do usuário:", error)
    localStorage.removeItem(DB_CURRENT_USER_KEY)
    return false
  }
}

// Verificar se é administrador
function verificarAdmin() {
  if (!verificarAutenticacao()) {
    return false
  }

  // Verificar se currentUser existe e tem a propriedade role
  return currentUser && currentUser.role === "admin"
}

// Proteger página (redirecionar se não estiver autenticado)
function protegerPagina() {
  if (!verificarAutenticacao()) {
    // Incrementar contador de redirecionamentos
    const redirectCount = incrementRedirectCount()
    
    // Se estiver em um possível loop, mostrar mensagem mais detalhada
    if (redirectCount > 2) {
      showNotification("Problema de autenticação detectado. Tente fazer login novamente.", "error")
    } else {
      showNotification("Você precisa fazer login para acessar esta página.", "warning")
    }

    setTimeout(() => {
      window.location.href = "login.html"
    }, 1500)

    return false
  }

  // Resetar contador de redirecionamentos quando a página é carregada com sucesso
  resetRedirectCount()
  return true
}

// Proteger página administrativa (redirecionar se não for admin)
function protegerPaginaAdmin() {
  if (!verificarAutenticacao()) {
    // Incrementar contador de redirecionamentos
    const redirectCount = incrementRedirectCount()
    
    // Se estiver em um possível loop, mostrar mensagem mais detalhada
    if (redirectCount > 2) {
      showNotification("Problema de autenticação detectado. Tente fazer login novamente.", "error")
    } else {
      showNotification("Você precisa fazer login para acessar esta página.", "warning")
    }

    setTimeout(() => {
      window.location.href = "../login.html"
    }, 1500)

    return false
  }

  if (!verificarAdmin()) {
    showNotification("Você não tem permissão para acessar esta página.", "error")

    setTimeout(() => {
      window.location.href = "../painel.html"
    }, 1500)

    return false
  }

  // Resetar contador de redirecionamentos quando a página é carregada com sucesso
  resetRedirectCount()
  return true
}

// Verificar se a URL atual é uma rota administrativa e redirecionar se não for admin
function verificarRotaAdmin() {
  // Verificar se a URL contém /admin/
  if (window.location.pathname.includes("/admin/")) {
    if (!verificarAdmin()) {
      // Redirecionar para a página de login
      window.location.href = "../login.html"
      return false
    }
  }
  return true
}

// Obter usuário atual
function getUsuarioAtual() {
  if (!currentUser) {
    verificarAutenticacao()
  }

  return currentUser
}

// Atualizar dados do usuário
function atualizarUsuario(nome, email, telefone, dadosAdicionais = {}) {
  if (!verificarAutenticacao()) {
    return false
  }

  const isAdmin = currentUser.role === "admin"

  if (isAdmin) {
    // Atualizar admin
    const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY))
    const adminIndex = admins.findIndex((admin) => admin.id === currentUser.id)

    if (adminIndex === -1) {
      showNotification("Erro ao atualizar dados.", "error")
      return false
    }

    // Atualizar dados
    admins[adminIndex].nome = nome
    admins[adminIndex].email = email
    admins[adminIndex].telefone = telefone

    // Salvar no banco de dados local
    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins))

    // Atualizar usuário atual
    currentUser.nome = nome
    currentUser.email = email
    currentUser.telefone = telefone
    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUser))
  } else {
    // Atualizar usuário
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY))
    const userIndex = users.findIndex((user) => user.id === currentUser.id)

    if (userIndex === -1) {
      showNotification("Erro ao atualizar dados.", "error")
      return false
    }

    // Atualizar dados
    users[userIndex].nome = nome
    users[userIndex].email = email
    users[userIndex].telefone = telefone

    // Atualizar dados adicionais
    for (const key in dadosAdicionais) {
      users[userIndex][key] = dadosAdicionais[key]
    }

    // Salvar no banco de dados local
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users))

    // Atualizar usuário atual
    currentUser.nome = nome
    currentUser.email = email
    currentUser.telefone = telefone

    // Atualizar dados adicionais no usuário atual
    for (const key in dadosAdicionais) {
      currentUser[key] = dadosAdicionais[key]
    }

    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUser))
  }

  showNotification("Dados atualizados com sucesso!", "success")
  return true
}

// Alterar senha
function alterarSenha(senhaAtual, novaSenha) {
  if (!verificarAutenticacao()) {
    return false
  }

  const isAdmin = currentUser.role === "admin"

  if (isAdmin) {
    // Alterar senha de admin
    const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY))
    const adminIndex = admins.findIndex((admin) => admin.id === currentUser.id)

    if (adminIndex === -1) {
      showNotification("Erro ao alterar senha.", "error")
      return false
    }

    // Verificar senha atual
    if (!verifyPassword(senhaAtual, admins[adminIndex].senha)) {
      showNotification("Senha atual incorreta.", "error")
      return false
    }

    // Atualizar senha
    admins[adminIndex].senha = hashPassword(novaSenha)

    // Salvar no banco de dados local
    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins))
  } else {
    // Alterar senha de usuário
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY))
    const userIndex = users.findIndex((user) => user.id === currentUser.id)

    if (userIndex === -1) {
      showNotification("Erro ao alterar senha.", "error")
      return false
    }

    // Verificar senha atual
    if (!verifyPassword(senhaAtual, users[userIndex].senha)) {
      showNotification("Senha atual incorreta.", "error")
      return false
    }

    // Atualizar senha
    users[userIndex].senha = hashPassword(novaSenha)

    // Salvar no banco de dados local
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users))
  }

  showNotification("Senha alterada com sucesso!", "success")
  return true
}

// Função auxiliar para mostrar notificações
function showNotification(message, type) {
  // Verificar se a função já existe no escopo global
  if (typeof window.showToast === 'function') {
    window.showToast(message, type);
    return;
  }
  
  // Implementação básica de fallback
  console.log(`[${type.toUpperCase()}] ${message}`);
  
  // Criar elemento de notificação se não existir
  let notification = document.getElementById('notification');
  if (!notification) {
    notification = document.createElement('div');
    notification.id = 'notification';
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = '5px';
    notification.style.color = 'white';
    notification.style.zIndex = '9999';
    notification.style.transition = 'opacity 0.5s';
    document.body.appendChild(notification);
  }
  
  // Definir cor com base no tipo
  let bgColor = '#333';
  switch (type) {
    case 'success':
      bgColor = '#4CAF50';
      break;
    case 'error':
      bgColor = '#F44336';
      break;
    case 'warning':
      bgColor = '#FF9800';
      break;
    case 'info':
      bgColor = '#2196F3';
      break;
  }
  
  notification.style.backgroundColor = bgColor;
  notification.textContent = message;
  notification.style.opacity = '1';
  
  // Esconder após 3 segundos
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 500);
  }, 3000);
}
