// Gerenciamento de configurações do sistema
// Implementação de configurações gerais, administradores e SMTP

// Chaves para armazenamento no localStorage
const DB_CONFIG_KEY = "clareoia_config";
const DB_ADMINS_KEY = "clareoia_admins";

// Inicializar banco de dados de configurações
function initializeConfigDB() {
  // Inicializar configurações se não existir
  if (!localStorage.getItem(DB_CONFIG_KEY)) {
    localStorage.setItem(DB_CONFIG_KEY, JSON.stringify({
      siteName: "ClareoIA",
      siteDescription: "Clareza Comportamental para Trajetórias de Sucesso",
      contactEmail: "contato@clareoia.com.br",
      supportPhone: "(51) 99149-0515",
      logoUrl: "../img/clareo.png",
      primaryColor: "#0056b3",
      secondaryColor: "#6c757d",
      sessionTimeout: 30, // minutos
      smtp: {
        host: "",
        port: 587,
        secure: false,
        auth: {
          user: "",
          pass: ""
        },
        sender: "noreply@clareoia.com.br",
        senderName: "ClareoIA"
      }
    }));
  }

  // Inicializar administradores se não existir
  if (!localStorage.getItem(DB_ADMINS_KEY)) {
    // Criar admin padrão se não existir nenhum
    const currentUser = getUsuarioAtual();
    if (currentUser && currentUser.admin) {
      localStorage.setItem(DB_ADMINS_KEY, JSON.stringify([
        {
          id: currentUser.id || 'admin_' + Math.random().toString(36).substring(2, 9),
          nome: currentUser.nome || 'Administrador',
          email: currentUser.email || 'admin@clareoia.com.br',
          role: 'superadmin',
          permissions: ['all'],
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString()
        }
      ]));
    } else {
      localStorage.setItem(DB_ADMINS_KEY, JSON.stringify([]));
    }
  }
}

// API de Configurações
const ConfigAPI = {
  // Obter todas as configurações
  getAll: function() {
    initializeConfigDB();
    return JSON.parse(localStorage.getItem(DB_CONFIG_KEY));
  },

  // Atualizar configurações
  update: function(configData) {
    const currentConfig = this.getAll();
    const updatedConfig = { ...currentConfig, ...configData };
    localStorage.setItem(DB_CONFIG_KEY, JSON.stringify(updatedConfig));
    return updatedConfig;
  },

  // Obter configurações SMTP
  getSMTP: function() {
    const config = this.getAll();
    return config.smtp || {};
  },

  // Atualizar configurações SMTP
  updateSMTP: function(smtpData) {
    const config = this.getAll();
    config.smtp = { ...config.smtp, ...smtpData };
    localStorage.setItem(DB_CONFIG_KEY, JSON.stringify(config));
    return config.smtp;
  },

  // Testar configurações SMTP
  testSMTP: async function(smtpData = null) {
    const smtp = smtpData || this.getSMTP();
    
    // Validar configurações básicas
    if (!smtp.host || !smtp.port || !smtp.auth.user || !smtp.auth.pass) {
      return {
        success: false,
        error: 'Configurações SMTP incompletas'
      };
    }
    
    try {
      // Simulação de teste SMTP
      // Em produção, isso seria feito pelo backend
      const success = Math.random() > 0.2; // 80% de chance de sucesso
      
      if (success) {
        return {
          success: true,
          message: 'Conexão SMTP estabelecida com sucesso'
        };
      } else {
        return {
          success: false,
          error: 'Erro ao conectar ao servidor SMTP'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Enviar e-mail de teste
  sendTestEmail: async function(email) {
    const smtp = this.getSMTP();
    
    // Validar configurações básicas
    if (!smtp.host || !smtp.port || !smtp.auth.user || !smtp.auth.pass) {
      return {
        success: false,
        error: 'Configurações SMTP incompletas'
      };
    }
    
    try {
      // Simulação de envio de e-mail
      // Em produção, isso seria feito pelo backend
      const success = Math.random() > 0.2; // 80% de chance de sucesso
      
      if (success) {
        return {
          success: true,
          message: `E-mail de teste enviado com sucesso para ${email}`
        };
      } else {
        return {
          success: false,
          error: 'Erro ao enviar e-mail de teste'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
};

// API de Administradores
const AdminsAPI = {
  // Obter todos os administradores
  getAll: function() {
    initializeConfigDB();
    return JSON.parse(localStorage.getItem(DB_ADMINS_KEY));
  },

  // Obter administrador por ID
  getById: function(id) {
    const admins = this.getAll();
    return admins.find(admin => admin.id === id);
  },

  // Obter administrador por e-mail
  getByEmail: function(email) {
    const admins = this.getAll();
    return admins.find(admin => admin.email === email);
  },

  // Criar novo administrador
  create: function(adminData) {
    const admins = this.getAll();
    
    // Verificar se e-mail já existe
    if (admins.some(admin => admin.email === adminData.email)) {
      return {
        success: false,
        error: 'E-mail já cadastrado'
      };
    }
    
    const id = 'admin_' + Math.random().toString(36).substring(2, 9);
    
    const newAdmin = {
      id: id,
      nome: adminData.nome,
      email: adminData.email,
      role: adminData.role || 'admin',
      permissions: adminData.permissions || ['view'],
      createdAt: new Date().toISOString(),
      lastLogin: null
    };
    
    admins.push(newAdmin);
    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins));
    
    return {
      success: true,
      admin: newAdmin
    };
  },

  // Atualizar administrador existente
  update: function(id, adminData) {
    const admins = this.getAll();
    const index = admins.findIndex(admin => admin.id === id);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Administrador não encontrado'
      };
    }
    
    // Verificar se e-mail já existe em outro administrador
    if (adminData.email && adminData.email !== admins[index].email) {
      if (admins.some(admin => admin.email === adminData.email && admin.id !== id)) {
        return {
          success: false,
          error: 'E-mail já cadastrado'
        };
      }
    }
    
    // Não permitir alterar o último superadmin
    if (admins[index].role === 'superadmin' && adminData.role && adminData.role !== 'superadmin') {
      const superadmins = admins.filter(admin => admin.role === 'superadmin');
      if (superadmins.length === 1) {
        return {
          success: false,
          error: 'Não é possível rebaixar o último superadmin'
        };
      }
    }
    
    admins[index] = {
      ...admins[index],
      ...adminData,
      updatedAt: new Date().toISOString()
    };
    
    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins));
    
    return {
      success: true,
      admin: admins[index]
    };
  },

  // Excluir administrador
  delete: function(id) {
    const admins = this.getAll();
    const admin = admins.find(admin => admin.id === id);
    
    if (!admin) {
      return {
        success: false,
        error: 'Administrador não encontrado'
      };
    }
    
    // Não permitir excluir o último superadmin
    if (admin.role === 'superadmin') {
      const superadmins = admins.filter(admin => admin.role === 'superadmin');
      if (superadmins.length === 1) {
        return {
          success: false,
          error: 'Não é possível excluir o último superadmin'
        };
      }
    }
    
    const filteredAdmins = admins.filter(admin => admin.id !== id);
    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(filteredAdmins));
    
    return {
      success: true
    };
  },

  // Registrar login de administrador
  registerLogin: function(id) {
    const admins = this.getAll();
    const index = admins.findIndex(admin => admin.id === id);
    
    if (index === -1) {
      return false;
    }
    
    admins[index].lastLogin = new Date().toISOString();
    localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins));
    
    return true;
  },

  // Redefinir senha de administrador
  resetPassword: async function(email) {
    const admin = this.getByEmail(email);
    
    if (!admin) {
      return {
        success: false,
        error: 'E-mail não encontrado'
      };
    }
    
    try {
      // Simulação de envio de e-mail de redefinição de senha
      // Em produção, isso seria feito pelo backend
      const success = Math.random() > 0.2; // 80% de chance de sucesso
      
      if (success) {
        return {
          success: true,
          message: `E-mail de redefinição de senha enviado para ${email}`
        };
      } else {
        return {
          success: false,
          error: 'Erro ao enviar e-mail de redefinição de senha'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
};

// Exportar APIs
window.ConfigAPI = ConfigAPI;
window.AdminsAPI = AdminsAPI;
