// Gerenciamento de planos e cobrança
// Implementação de definição de preços, permissões e integração com plataformas de pagamento

// Chaves para armazenamento no localStorage
const DB_PLANS_KEY = "clareoia_plans";
const DB_USER_PLANS_KEY = "clareoia_user_plans";
const DB_PAYMENTS_KEY = "clareoia_payments";

// Inicializar banco de dados de planos
function initializePlansDB() {
  // Inicializar planos se não existir
  if (!localStorage.getItem(DB_PLANS_KEY)) {
    localStorage.setItem(DB_PLANS_KEY, JSON.stringify({
      free: {
        id: "free",
        nome: "Gratuito",
        descricao: "Acesso básico para experimentar a plataforma",
        preco: 0,
        recorrencia: "mensal",
        permissoes: {
          testes: 2,
          perguntasPorTeste: 10,
          analise360: false,
          baseConhecimento: {
            visualizar: true,
            adicionar: false
          }
        },
        ativo: true
      },
      intermediario: {
        id: "intermediario",
        nome: "Intermediário",
        descricao: "Acesso a todos os testes com mais perguntas",
        preco: 49.90,
        recorrencia: "mensal",
        permissoes: {
          testes: -1, // ilimitado
          perguntasPorTeste: 20,
          analise360: false,
          baseConhecimento: {
            visualizar: true,
            adicionar: false
          }
        },
        ativo: true
      },
      premium: {
        id: "premium",
        nome: "Verdade",
        descricao: "Acesso completo com análise 360 e mais recursos",
        preco: 99.90,
        recorrencia: "mensal",
        permissoes: {
          testes: -1, // ilimitado
          perguntasPorTeste: 30,
          analise360: true,
          baseConhecimento: {
            visualizar: true,
            adicionar: true
          }
        },
        ativo: true
      },
      parceiro: {
        id: "parceiro",
        nome: "Parceiro",
        descricao: "Plano especial para parceiros com recursos personalizados",
        preco: 199.90,
        recorrencia: "mensal",
        permissoes: {
          testes: -1, // ilimitado
          perguntasPorTeste: 30,
          analise360: true,
          baseConhecimento: {
            visualizar: true,
            adicionar: true,
            limiteAdicoes: 50
          }
        },
        ativo: true
      }
    }));
  }

  // Inicializar planos de usuários se não existir
  if (!localStorage.getItem(DB_USER_PLANS_KEY)) {
    localStorage.setItem(DB_USER_PLANS_KEY, JSON.stringify([]));
  }

  // Inicializar pagamentos se não existir
  if (!localStorage.getItem(DB_PAYMENTS_KEY)) {
    localStorage.setItem(DB_PAYMENTS_KEY, JSON.stringify([]));
  }
}

// API de Planos
const PlansAPI = {
  // Obter todos os planos
  getAll: function() {
    initializePlansDB();
    return JSON.parse(localStorage.getItem(DB_PLANS_KEY));
  },

  // Obter plano por ID
  getById: function(planId) {
    const plans = this.getAll();
    return plans[planId];
  },

  // Criar ou atualizar plano
  saveOrUpdate: function(planData) {
    const plans = this.getAll();
    
    // Validar dados do plano
    if (!planData.id || !planData.nome) {
      return {
        success: false,
        error: 'ID e nome do plano são obrigatórios'
      };
    }
    
    // Atualizar ou adicionar plano
    plans[planData.id] = planData;
    localStorage.setItem(DB_PLANS_KEY, JSON.stringify(plans));
    
    return {
      success: true,
      plan: planData
    };
  },

  // Excluir plano
  delete: function(planId) {
    const plans = this.getAll();
    
    if (!plans[planId]) {
      return {
        success: false,
        error: 'Plano não encontrado'
      };
    }
    
    // Verificar se há usuários com este plano
    const userPlans = JSON.parse(localStorage.getItem(DB_USER_PLANS_KEY));
    const hasUsers = userPlans.some(up => up.planId === planId);
    
    if (hasUsers) {
      return {
        success: false,
        error: 'Não é possível excluir um plano que possui usuários'
      };
    }
    
    // Excluir plano
    delete plans[planId];
    localStorage.setItem(DB_PLANS_KEY, JSON.stringify(plans));
    
    return {
      success: true
    };
  },

  // Ativar/desativar plano
  toggleActive: function(planId) {
    const plans = this.getAll();
    
    if (!plans[planId]) {
      return {
        success: false,
        error: 'Plano não encontrado'
      };
    }
    
    plans[planId].ativo = !plans[planId].ativo;
    localStorage.setItem(DB_PLANS_KEY, JSON.stringify(plans));
    
    return {
      success: true,
      active: plans[planId].ativo
    };
  },

  // Obter plano do usuário atual
  getUserPlan: function() {
    const currentUser = getUsuarioAtual();
    
    if (!currentUser) {
      return null;
    }
    
    initializePlansDB();
    const userPlans = JSON.parse(localStorage.getItem(DB_USER_PLANS_KEY));
    const userPlan = userPlans.find(up => up.userId === currentUser.id);
    
    if (!userPlan) {
      // Se o usuário não tem plano, atribuir o plano gratuito
      const freePlan = this.getById('free');
      
      if (freePlan) {
        this.assignPlanToUser(currentUser.id, 'free');
        return {
          ...freePlan,
          status: 'active',
          startDate: new Date().toISOString(),
          endDate: null
        };
      }
      
      return null;
    }
    
    const plan = this.getById(userPlan.planId);
    
    if (!plan) {
      return null;
    }
    
    return {
      ...plan,
      status: userPlan.status,
      startDate: userPlan.startDate,
      endDate: userPlan.endDate
    };
  },

  // Atribuir plano a um usuário
  assignPlanToUser: function(userId, planId, status = 'active', startDate = null, endDate = null) {
    const plans = this.getAll();
    
    if (!plans[planId]) {
      return {
        success: false,
        error: 'Plano não encontrado'
      };
    }
    
    initializePlansDB();
    const userPlans = JSON.parse(localStorage.getItem(DB_USER_PLANS_KEY));
    
    // Verificar se o usuário já tem um plano
    const existingIndex = userPlans.findIndex(up => up.userId === userId);
    
    const userPlanData = {
      userId,
      planId,
      status: status || 'active',
      startDate: startDate || new Date().toISOString(),
      endDate: endDate || null
    };
    
    if (existingIndex >= 0) {
      // Atualizar plano existente
      userPlans[existingIndex] = userPlanData;
    } else {
      // Adicionar novo plano
      userPlans.push(userPlanData);
    }
    
    localStorage.setItem(DB_USER_PLANS_KEY, JSON.stringify(userPlans));
    
    return {
      success: true,
      userPlan: userPlanData
    };
  },

  // Verificar permissão do usuário
  checkPermission: function(permissionKey, subKey = null) {
    const userPlan = this.getUserPlan();
    
    if (!userPlan || userPlan.status !== 'active') {
      return false;
    }
    
    if (!userPlan.permissoes) {
      return false;
    }
    
    if (subKey) {
      return userPlan.permissoes[permissionKey] && 
             userPlan.permissoes[permissionKey][subKey] !== undefined ? 
             userPlan.permissoes[permissionKey][subKey] : false;
    }
    
    return userPlan.permissoes[permissionKey] !== undefined ? 
           userPlan.permissoes[permissionKey] : false;
  },

  // Verificar limite de uso
  checkLimit: function(limitKey) {
    const userPlan = this.getUserPlan();
    
    if (!userPlan || userPlan.status !== 'active') {
      return 0;
    }
    
    if (!userPlan.permissoes) {
      return 0;
    }
    
    const limit = userPlan.permissoes[limitKey];
    
    // -1 significa ilimitado
    return limit === -1 ? Infinity : (limit || 0);
  },

  // Obter progresso para análise 360
  getAnalysis360Progress: function() {
    const userPlan = this.getUserPlan();
    
    if (!userPlan || userPlan.status !== 'active') {
      return {
        available: false,
        progress: 0,
        requiredTests: 0,
        completedTests: 0
      };
    }
    
    // Verificar se o plano permite análise 360
    const hasAnalysis360 = this.checkPermission('analise360');
    
    if (!hasAnalysis360) {
      return {
        available: false,
        progress: 0,
        requiredTests: 0,
        completedTests: 0
      };
    }
    
    // Simulação de testes concluídos
    // Em produção, isso seria obtido do banco de dados
    const completedTests = 3; // Exemplo: 3 testes concluídos
    const requiredTests = 4;  // Exemplo: 4 testes necessários
    
    return {
      available: completedTests >= requiredTests,
      progress: Math.min(100, Math.round((completedTests / requiredTests) * 100)),
      requiredTests,
      completedTests
    };
  }
};

// API de Pagamentos
const PaymentsAPI = {
  // Obter todos os pagamentos
  getAll: function() {
    initializePlansDB();
    return JSON.parse(localStorage.getItem(DB_PAYMENTS_KEY));
  },

  // Obter pagamentos de um usuário
  getUserPayments: function(userId) {
    const payments = this.getAll();
    return payments.filter(payment => payment.userId === userId);
  },

  // Registrar novo pagamento
  registerPayment: function(paymentData) {
    if (!paymentData.userId || !paymentData.planId || !paymentData.amount) {
      return {
        success: false,
        error: 'Dados de pagamento incompletos'
      };
    }
    
    const payments = this.getAll();
    
    const newPayment = {
      id: 'payment_' + Math.random().toString(36).substring(2, 9),
      ...paymentData,
      status: paymentData.status || 'pending',
      date: paymentData.date || new Date().toISOString(),
      gateway: paymentData.gateway || 'manual'
    };
    
    payments.push(newPayment);
    localStorage.setItem(DB_PAYMENTS_KEY, JSON.stringify(payments));
    
    // Se o pagamento for aprovado, atualizar o plano do usuário
    if (newPayment.status === 'approved') {
      PlansAPI.assignPlanToUser(
        newPayment.userId, 
        newPayment.planId, 
        'active', 
        new Date().toISOString()
      );
      
      // Disparar webhook de pagamento aprovado
      if (window.WebhooksAPI) {
        WebhooksAPI.triggerEvent('payment_approved', newPayment);
      }
    }
    
    return {
      success: true,
      payment: newPayment
    };
  },

  // Atualizar status de pagamento
  updatePaymentStatus: function(paymentId, status) {
    const payments = this.getAll();
    const index = payments.findIndex(payment => payment.id === paymentId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Pagamento não encontrado'
      };
    }
    
    const oldStatus = payments[index].status;
    payments[index].status = status;
    payments[index].updatedAt = new Date().toISOString();
    
    localStorage.setItem(DB_PAYMENTS_KEY, JSON.stringify(payments));
    
    // Se o status mudou para aprovado, atualizar o plano do usuário
    if (oldStatus !== 'approved' && status === 'approved') {
      PlansAPI.assignPlanToUser(
        payments[index].userId, 
        payments[index].planId, 
        'active', 
        new Date().toISOString()
      );
      
      // Disparar webhook de pagamento aprovado
      if (window.WebhooksAPI) {
        WebhooksAPI.triggerEvent('payment_approved', payments[index]);
      }
    }
    
    // Se o status mudou para cancelado ou rejeitado, atualizar o plano do usuário para gratuito
    if ((status === 'canceled' || status === 'rejected') && oldStatus !== status) {
      PlansAPI.assignPlanToUser(
        payments[index].userId, 
        'free', 
        'active', 
        new Date().toISOString()
      );
      
      // Disparar webhook de pagamento cancelado/rejeitado
      if (window.WebhooksAPI) {
        WebhooksAPI.triggerEvent('payment_' + status, payments[index]);
      }
    }
    
    return {
      success: true,
      payment: payments[index]
    };
  },

  // Simular integração com gateway de pagamento
  processPayment: async function(paymentData, gateway = 'pagarme') {
    // Validar dados de pagamento
    if (!paymentData.userId || !paymentData.planId || !paymentData.amount) {
      return {
        success: false,
        error: 'Dados de pagamento incompletos'
      };
    }
    
    // Simular processamento de pagamento
    return new Promise((resolve) => {
      setTimeout(() => {
        // Simular 80% de chance de sucesso
        const success = Math.random() < 0.8;
        
        if (success) {
          const payment = this.registerPayment({
            ...paymentData,
            status: 'approved',
            gateway
          });
          
          resolve({
            success: true,
            payment: payment.payment,
            message: 'Pagamento processado com sucesso'
          });
        } else {
          resolve({
            success: false,
            error: 'Erro ao processar pagamento',
            details: 'Simulação de falha no gateway de pagamento'
          });
        }
      }, 1500); // Simular delay de processamento
    });
  },

  // Verificar status de assinatura
  checkSubscriptionStatus: function(userId) {
    const userPlans = JSON.parse(localStorage.getItem(DB_USER_PLANS_KEY));
    const userPlan = userPlans.find(up => up.userId === userId);
    
    if (!userPlan) {
      return {
        active: false,
        planId: 'free',
        status: 'inactive'
      };
    }
    
    return {
      active: userPlan.status === 'active',
      planId: userPlan.planId,
      status: userPlan.status,
      startDate: userPlan.startDate,
      endDate: userPlan.endDate
    };
  },

  // Cancelar assinatura
  cancelSubscription: function(userId) {
    const userPlans = JSON.parse(localStorage.getItem(DB_USER_PLANS_KEY));
    const index = userPlans.findIndex(up => up.userId === userId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Assinatura não encontrada'
      };
    }
    
    // Atualizar status da assinatura
    userPlans[index].status = 'canceled';
    userPlans[index].endDate = new Date().toISOString();
    
    localStorage.setItem(DB_USER_PLANS_KEY, JSON.stringify(userPlans));
    
    // Atribuir plano gratuito
    PlansAPI.assignPlanToUser(userId, 'free', 'active', new Date().toISOString());
    
    // Disparar webhook de assinatura cancelada
    if (window.WebhooksAPI) {
      WebhooksAPI.triggerEvent('subscription_canceled', {
        userId,
        planId: userPlans[index].planId,
        cancelDate: new Date().toISOString()
      });
    }
    
    return {
      success: true,
      message: 'Assinatura cancelada com sucesso'
    };
  }
};

// Exportar APIs
window.PlansAPI = PlansAPI;
window.PaymentsAPI = PaymentsAPI;
