# Arquitetura da Plataforma de Testes Comportamentais

## Visão Geral

A plataforma de testes comportamentais é um sistema web responsivo que permite aos usuários realizar diversos tipos de testes (DISC, Temperamento, Personalidade, Perfil Animal, Emoções), visualizar seus resultados e histórico. O sistema possui uma área administrativa separada para gerenciamento de prompts, base de conhecimento e integrações.

## Estrutura de Dados

### Usuários
\`\`\`json
{
  "id": "uuid",
  "nome": "Nome do usuário",
  "email": "email@email.com",
  "telefone": "11999999999",
  "senha": "hash_da_senha",
  "data_cadastro": "AAAA-MM-DD HH:MM",
  "ultimo_acesso": "AAAA-MM-DD HH:MM"
}
\`\`\`

### Administradores
\`\`\`json
{
  "id": "uuid",
  "email": "admin@email.com",
  "senha": "hash_da_senha",
  "data_cadastro": "AAAA-MM-DD HH:MM",
  "ultimo_acesso": "AAAA-MM-DD HH:MM"
}
\`\`\`

### Testes
\`\`\`json
{
  "id": "uuid",
  "nome": "Nome do teste",
  "tipo": "DISC" | "Temperamento" | "Personalidade" | "Animal" | "Emocoes",
  "descricao": "Descrição do teste",
  "instrucoes": "Instruções para o usuário",
  "prompt_id": "uuid",
  "webhook_entrada": "URL do webhook de entrada",
  "webhook_saida": "URL do webhook de saída",
  "enviar_whatsapp": true | false
}
\`\`\`

### Perguntas
\`\`\`json
{
  "id": "uuid",
  "teste_id": "uuid",
  "numero": 1,
  "texto": "Texto da pergunta",
  "opcoes": [
    {"letra": "A", "texto": "Texto da opção A"},
    {"letra": "B", "texto": "Texto da opção B"},
    {"letra": "C", "texto": "Texto da opção C"},
    {"letra": "D", "texto": "Texto da opção D"}
  ]
}
\`\`\`

### Prompts
\`\`\`json
{
  "id": "uuid",
  "teste_id": "uuid",
  "texto": "Texto do prompt para o GPT",
  "temperatura": 0.7,
  "modelo": "gpt-4"
}
\`\`\`

### Resultados
\`\`\`json
{
  "id": "uuid",
  "usuario_id": "uuid",
  "teste_id": "uuid",
  "data": "AAAA-MM-DD HH:MM",
  "respostas": {"1": "A", "2": "C", "3": "B", ...},
  "pontuacao": {"D": 4, "I": 3, "S": 2, "C": 1},
  "resultado_texto": "Texto completo gerado pelo GPT",
  "enviado_whatsapp": true | false,
  "webhook_disparado": true | false
}
\`\`\`

### Base de Conhecimento
\`\`\`json
{
  "id": "uuid",
  "teste_id": "uuid",
  "nome": "Nome do arquivo",
  "tipo": "pdf" | "txt" | "docx" | "md",
  "conteudo": "Conteúdo do arquivo",
  "data_upload": "AAAA-MM-DD HH:MM"
}
\`\`\`

### Integrações
\`\`\`json
{
  "id": "uuid",
  "tipo": "openai" | "evolution" | "make" | "webhook",
  "nome": "Nome da integração",
  "chave": "Chave da API ou token",
  "url": "URL da integração",
  "configuracoes": {"param1": "valor1", "param2": "valor2", ...}
}
\`\`\`

## Fluxo de Usuário

1. **Cadastro e Login**
   - Usuário acessa a página inicial
   - Opção de cadastro (nome, e-mail, telefone, senha)
   - Opção de login (e-mail, senha)
   - Autenticação e redirecionamento para o painel

2. **Painel de Usuário**
   - Exibição dos testes disponíveis (DISC, Temperamento, Personalidade, Perfil Animal, Emoções)
   - Indicação visual de testes já realizados
   - Acesso ao histórico de resultados

3. **Realização de Teste**
   - Verificação se o teste já foi realizado
   - Se sim, exibição do resultado com opção de refazer
   - Se não, início do teste com instruções
   - Apresentação de uma pergunta por vez
   - Navegação entre perguntas
   - Finalização e envio para análise

4. **Visualização de Resultados**
   - Exibição do resultado gerado pelo GPT
   - Opção de download em PDF
   - Opção de envio por e-mail
   - Opção de compartilhamento via WhatsApp (se configurado)

5. **Histórico de Resultados**
   - Listagem de todos os testes realizados
   - Filtro por tipo de teste
   - Ordenação por data
   - Acesso aos resultados anteriores

## Fluxo Administrativo

1. **Login Administrativo**
   - Acesso à página de login administrativo
   - Autenticação e redirecionamento para o painel administrativo

2. **Gerenciamento de Prompts**
   - Listagem de prompts por tipo de teste
   - Criação e edição de prompts
   - Associação de prompts a testes

3. **Base de Conhecimento**
   - Upload de arquivos (.pdf, .txt, .docx, .md)
   - Associação de arquivos a tipos de teste
   - Gerenciamento de arquivos existentes

4. **Visualização de Resultados**
   - Listagem de todos os resultados de todos os usuários
   - Filtros por usuário, tipo de teste, data
   - Exportação de dados em Excel/PDF

5. **Configuração de Integrações**
   - Configuração da API OpenAI
   - Configuração da Evolution API (WhatsApp)
   - Configuração de webhooks
   - Configuração do Make.com

## Integrações Externas

1. **OpenAI (GPT-4)**
   - Envio de prompts personalizados
   - Recebimento e processamento de respostas

2. **Evolution API (WhatsApp)**
   - Envio automático de resultados via WhatsApp
   - Configuração de mensagens personalizadas

3. **Webhooks**
   - Recebimento de dados externos
   - Envio de resultados para sistemas externos

4. **Make.com**
   - Integração com cenários do Make
   - Automação de fluxos de dados

## Segurança

1. **Autenticação**
   - Senhas armazenadas com hash seguro
   - Tokens de autenticação com expiração
   - Proteção contra ataques de força bruta

2. **Autorização**
   - Separação clara entre usuários e administradores
   - Controle de acesso baseado em funções
   - Proteção de rotas administrativas

3. **Proteção de Dados**
   - Criptografia de dados sensíveis
   - Validação de entradas
   - Proteção contra injeção de SQL e XSS

## Tecnologias

1. **Frontend**
   - HTML5, CSS3, JavaScript
   - Framework responsivo (Bootstrap)
   - Biblioteca de componentes (React ou Vue.js)

2. **Backend**
   - Node.js com Express
   - Banco de dados (MongoDB ou Firebase)
   - Autenticação JWT

3. **Integrações**
   - APIs RESTful
   - Webhooks
   - WebSockets para atualizações em tempo real

4. **Armazenamento**
   - Banco de dados NoSQL para flexibilidade
   - Armazenamento de arquivos em cloud storage
   - Cache para otimização de desempenho

## Escalabilidade

1. **Modularização**
   - Separação clara de responsabilidades
   - Componentes reutilizáveis
   - APIs bem definidas

2. **Expansão**
   - Facilidade para adicionar novos tipos de teste
   - Suporte a múltiplos idiomas
   - Adaptação para diferentes dispositivos

3. **Performance**
   - Otimização de consultas ao banco de dados
   - Carregamento assíncrono de recursos
   - Compressão e minificação de assets
