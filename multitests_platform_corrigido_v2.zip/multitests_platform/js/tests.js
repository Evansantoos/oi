// Funções para gerenciamento de testes
let testData = {};

// Inicializar banco de dados local
function initializeDatabase() {
    // Verificar se já existem dados salvos
    if (!localStorage.getItem('users')) {
        localStorage.setItem('users', JSON.stringify([]));
    }
    
    if (!localStorage.getItem('testResults')) {
        localStorage.setItem('testResults', JSON.stringify([]));
    }
    
    if (!localStorage.getItem('testQuestions')) {
        // Inicializar perguntas dos testes
        const questions = {
            disc: loadDISCQuestions(),
            temperamento: loadTemperamentoQuestions(),
            personalidade: loadPersonalidadeQuestions(),
            animal: loadAnimalQuestions(),
            emocoes: loadEmocoesQuestions()
        };
        
        localStorage.setItem('testQuestions', JSON.stringify(questions));
    }
    
    // Carregar dados de teste
    testData = JSON.parse(localStorage.getItem('testQuestions') || '{}');
}

// Função para carregar perguntas do teste DISC
function loadDISCQuestions() {
    return [
        {
            pergunta: "Quando precisa tomar uma decisão com poucas informações, o que você faz?",
            opcoes: [
                { texto: "Decide rápido e ajusta depois", valor: "D" },
                { texto: "Busca dados antes de agir", valor: "C" },
                { texto: "Consulta outras pessoas", valor: "I" },
                { texto: "Evita decidir sem orientação", valor: "S" }
            ]
        },
        {
            pergunta: "Como prefere contribuir em uma equipe?",
            opcoes: [
                { texto: "Liderando e tomando decisões", valor: "D" },
                { texto: "Animando e motivando o grupo", valor: "I" },
                { texto: "Organizando e mantendo a ordem", valor: "S" },
                { texto: "Analisando tarefas e dados", valor: "C" }
            ]
        },
        {
            pergunta: "Como lida com mudanças inesperadas?",
            opcoes: [
                { texto: "Reage rápido e resolve", valor: "D" },
                { texto: "Enxerga como oportunidade", valor: "I" },
                { texto: "Se adapta com tempo", valor: "S" },
                { texto: "Prefere evitar e manter a rotina", valor: "C" }
            ]
        },
        {
            pergunta: "Em situações de pressão, você tende a:",
            opcoes: [
                { texto: "Assumir o controle", valor: "D" },
                { texto: "Usar carisma para engajar", valor: "I" },
                { texto: "Ajudar a manter a calma do grupo", valor: "S" },
                { texto: "Se isolar para pensar e analisar", valor: "C" }
            ]
        },
        {
            pergunta: "Como reage a regras definidas por outros?",
            opcoes: [
                { texto: "Questiona e busca flexibilidade", valor: "D" },
                { texto: "Adapta conforme a situação", valor: "I" },
                { texto: "Segue para manter harmonia", valor: "S" },
                { texto: "Segue rigorosamente, sem mudar", valor: "C" }
            ]
        },
        {
            pergunta: "Como costuma reagir em conflitos diretos?",
            opcoes: [
                { texto: "Enfrenta com firmeza", valor: "D" },
                { texto: "Tenta convencer com empatia", valor: "I" },
                { texto: "Busca conciliação", valor: "S" },
                { texto: "Evita e se cala", valor: "C" }
            ]
        },
        {
            pergunta: "Que tipo de ambiente prefere para trabalhar?",
            opcoes: [
                { texto: "Desafiador e com mudanças frequentes", valor: "D" },
                { texto: "Estimulante e cheio de pessoas", valor: "I" },
                { texto: "Calmo e com previsibilidade", valor: "S" },
                { texto: "Organizado e com processos definidos", valor: "C" }
            ]
        },
        {
            pergunta: "Como age ao tentar convencer alguém?",
            opcoes: [
                { texto: "Usa argumentos objetivos", valor: "D" },
                { texto: "Usa entusiasmo e carisma", valor: "I" },
                { texto: "Apela para o senso de grupo", valor: "S" },
                { texto: "Usa lógica e dados", valor: "C" }
            ]
        },
        {
            pergunta: "O que mais valoriza nas relações de trabalho?",
            opcoes: [
                { texto: "Alta performance e entrega", valor: "D" },
                { texto: "Reconhecimento e interação", valor: "I" },
                { texto: "Segurança e confiança", valor: "S" },
                { texto: "Organização e padrões claros", valor: "C" }
            ]
        },
        {
            pergunta: "Como costuma executar tarefas importantes?",
            opcoes: [
                { texto: "Age rápido e entrega logo", valor: "D" },
                { texto: "Compartilha e envolve todos", valor: "I" },
                { texto: "Planeja com tranquilidade", valor: "S" },
                { texto: "Segue um plano detalhado e preciso", valor: "C" }
            ]
        },
        // Mais 20 perguntas para completar 30
        {
            pergunta: "Qual frase mais combina com você em dias agitados?",
            opcoes: [
                { texto: "Vamos direto ao ponto e resolver logo", valor: "D" },
                { texto: "Vamos animar o time para passar por isso", valor: "I" },
                { texto: "Vamos manter a calma e seguir o plano", valor: "S" },
                { texto: "Vamos entender o que está acontecendo com precisão", valor: "C" }
            ]
        },
        {
            pergunta: "Em decisões importantes, você tende a:",
            opcoes: [
                { texto: "Tomar a frente e decidir sozinho", valor: "D" },
                { texto: "Consultar todos e buscar consenso", valor: "I" },
                { texto: "Esperar para sentir segurança", valor: "S" },
                { texto: "Avaliar riscos e seguir regras", valor: "C" }
            ]
        },
        {
            pergunta: "Quando recebe uma tarefa nova, sua primeira reação é:",
            opcoes: [
                { texto: "Pensar em como concluir rápido", valor: "D" },
                { texto: "Pensar em quem pode ajudar", valor: "I" },
                { texto: "Pensar em como manter tudo tranquilo", valor: "S" },
                { texto: "Pensar em como fazer certo, com qualidade", valor: "C" }
            ]
        },
        {
            pergunta: "Qual dessas frases reflete melhor seu jeito de trabalhar?",
            opcoes: [
                { texto: "Foco no resultado acima de tudo", valor: "D" },
                { texto: "É importante manter o ambiente leve", valor: "I" },
                { texto: "Prefiro manter a estabilidade", valor: "S" },
                { texto: "Detalhes e processos importam muito", valor: "C" }
            ]
        },
        {
            pergunta: "Como lida com prazos apertados?",
            opcoes: [
                { texto: "Enfrenta e acelera", valor: "D" },
                { texto: "Tenta motivar o grupo", valor: "I" },
                { texto: "Fica mais cauteloso", valor: "S" },
                { texto: "Planeja cada etapa com cuidado", valor: "C" }
            ]
        },
        {
            pergunta: "Como age ao ser interrompido no meio de uma tarefa importante?",
            opcoes: [
                { texto: "Reage com irritação e retoma rápido", valor: "D" },
                { texto: "Lida com leveza e continua depois", valor: "I" },
                { texto: "Aceita e tenta manter a harmonia", valor: "S" },
                { texto: "Se incomoda, mas volta após replanejar", valor: "C" }
            ]
        },
        {
            pergunta: "Em uma reunião tensa, você costuma:",
            opcoes: [
                { texto: "Se impor e liderar o rumo da conversa", valor: "D" },
                { texto: "Usar humor e empatia para aliviar", valor: "I" },
                { texto: "Manter a paz e ouvir todos", valor: "S" },
                { texto: "Ficar mais observador e técnico", valor: "C" }
            ]
        },
        {
            pergunta: "Como lida com imprevistos no trabalho?",
            opcoes: [
                { texto: "Resolve com agilidade", valor: "D" },
                { texto: "Mobiliza os outros para ajudar", valor: "I" },
                { texto: "Evita conflitos e se adapta devagar", valor: "S" },
                { texto: "Analisa antes de agir para não errar", valor: "C" }
            ]
        },
        {
            pergunta: "O que te frustra mais em uma equipe?",
            opcoes: [
                { texto: "Lentidão e falta de entrega", valor: "D" },
                { texto: "Falta de comunicação e energia", valor: "I" },
                { texto: "Falta de união e sensibilidade", valor: "S" },
                { texto: "Desorganização e erros repetidos", valor: "C" }
            ]
        },
        {
            pergunta: "Como prefere receber orientações?",
            opcoes: [
                { texto: "De forma direta e objetiva", valor: "D" },
                { texto: "Com liberdade para adaptar", valor: "I" },
                { texto: "Com calma e apoio", valor: "S" },
                { texto: "Com regras claras e por escrito", valor: "C" }
            ]
        },
        {
            pergunta: "Quando te dão autonomia total em um projeto, você:",
            opcoes: [
                { texto: "Assume o controle rapidamente", valor: "D" },
                { texto: "Compartilha ideias com todos", valor: "I" },
                { texto: "Busca apoio antes de começar", valor: "S" },
                { texto: "Cria um plano detalhado antes de agir", valor: "C" }
            ]
        },
        {
            pergunta: "Quando precisa aprender algo novo, você prefere:",
            opcoes: [
                { texto: "Aprender fazendo", valor: "D" },
                { texto: "Aprender conversando com pessoas", valor: "I" },
                { texto: "Ter alguém guiando passo a passo", valor: "S" },
                { texto: "Estudar sozinho e seguir um método", valor: "C" }
            ]
        },
        {
            pergunta: "Como você se descreve em poucas palavras?",
            opcoes: [
                { texto: "Determinado e direto", valor: "D" },
                { texto: "Comunicativo e carismático", valor: "I" },
                { texto: "Paciente e confiável", valor: "S" },
                { texto: "Analítico e organizado", valor: "C" }
            ]
        },
        {
            pergunta: "Quando alguém te critica, como você reage?",
            opcoes: [
                { texto: "Se defende rapidamente", valor: "D" },
                { texto: "Tenta entender o lado da pessoa", valor: "I" },
                { texto: "Fica incomodado, mas evita confronto", valor: "S" },
                { texto: "Avalia se a crítica faz sentido tecnicamente", valor: "C" }
            ]
        },
        {
            pergunta: "Em uma nova equipe, você tende a:",
            opcoes: [
                { texto: "Querer mostrar resultado logo", valor: "D" },
                { texto: "Fazer amizade com todos", valor: "I" },
                { texto: "Observar e se adaptar ao grupo", valor: "S" },
                { texto: "Entender regras e processos antes de agir", valor: "C" }
            ]
        },
        {
            pergunta: "Quando precisa dar um feedback difícil, você:",
            opcoes: [
                { texto: "Fala direto, sem rodeios", valor: "D" },
                { texto: "Tenta ser leve e cuidadoso", valor: "I" },
                { texto: "Evita ao máximo causar desconforto", valor: "S" },
                { texto: "Prefere escrever ou seguir um modelo", valor: "C" }
            ]
        },
        {
            pergunta: "Como reage quando alguém não segue o combinado?",
            opcoes: [
                { texto: "Confronta na hora", valor: "D" },
                { texto: "Tenta convencer com empatia", valor: "I" },
                { texto: "Tolera e evita conflitos", valor: "S" },
                { texto: "Aponta o erro com base nas regras", valor: "C" }
            ]
        },
        {
            pergunta: "Qual dessas situações te deixa mais desconfortável?",
            opcoes: [
                { texto: "Falta de decisão e ação", valor: "D" },
                { texto: "Rejeição ou isolamento social", valor: "I" },
                { texto: "Mudanças repentinas", valor: "S" },
                { texto: "Falta de organização ou controle", valor: "C" }
            ]
        },
        {
            pergunta: "Em ambientes novos, você:",
            opcoes: [
                { texto: "Se impõe naturalmente", valor: "D" },
                { texto: "Faz conexões rápido", valor: "I" },
                { texto: "Observa com cautela", valor: "S" },
                { texto: "Espera entender bem as regras", valor: "C" }
            ]
        },
        {
            pergunta: "Quando tudo está sob controle, você:",
            opcoes: [
                { texto: "Procura um novo desafio", valor: "D" },
                { texto: "Se envolve com as pessoas", valor: "I" },
                { texto: "Mantém o que já está funcionando", valor: "S" },
                { texto: "Aperfeiçoa o que pode ser melhorado", valor: "C" }
            ]
        }
    ];
}

// Função para carregar perguntas do teste de Temperamento
function loadTemperamentoQuestions() {
    return [
        {
            pergunta: "Como você reage ao conhecer pessoas novas?",
            opcoes: [
                { texto: "Me empolgo e quero conversar com todo mundo", valor: "Sanguíneo" },
                { texto: "Avalio rapidamente se são úteis ou interessantes", valor: "Colérico" },
                { texto: "Observo em silêncio e evito interações desnecessárias", valor: "Melancólico" },
                { texto: "Cumprimento com educação, mas fico na minha", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Quando algo dá errado no seu dia, você tende a:",
            opcoes: [
                { texto: "Reclamar alto ou rir da situação", valor: "Sanguíneo" },
                { texto: "Procurar o responsável e resolver na hora", valor: "Colérico" },
                { texto: "Se sentir frustrado e remoer o problema", valor: "Melancólico" },
                { texto: "Aceitar e seguir em frente sem muito drama", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Em um trabalho em grupo, você:",
            opcoes: [
                { texto: "Motiva e diverte a equipe", valor: "Sanguíneo" },
                { texto: "Assume a liderança naturalmente", valor: "Colérico" },
                { texto: "Se concentra nos detalhes e na qualidade", valor: "Melancólico" },
                { texto: "Busca ajudar e manter a harmonia", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Como você reage a mudanças de planos de última hora?",
            opcoes: [
                { texto: "Improvisa e tenta aproveitar", valor: "Sanguíneo" },
                { texto: "Se irrita e tenta manter o controle", valor: "Colérico" },
                { texto: "Fica incomodado e perde o foco", valor: "Melancólico" },
                { texto: "Se adapta com tranquilidade", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Quando precisa resolver um problema urgente, você:",
            opcoes: [
                { texto: "Chama alguém para conversar e desabafar", valor: "Sanguíneo" },
                { texto: "Age rápido e sem consultar ninguém", valor: "Colérico" },
                { texto: "Analisa tudo antes de decidir", valor: "Melancólico" },
                { texto: "Espera o melhor momento e age com calma", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "O que mais te incomoda nas outras pessoas?",
            opcoes: [
                { texto: "Falta de animação ou energia", valor: "Sanguíneo" },
                { texto: "Lentidão ou indecisão", valor: "Colérico" },
                { texto: "Falta de atenção aos detalhes", valor: "Melancólico" },
                { texto: "Agressividade ou impaciência", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Qual tipo de elogio você mais gostaria de ouvir?",
            opcoes: [
                { texto: "Você anima qualquer ambiente", valor: "Sanguíneo" },
                { texto: "Você resolve tudo com eficiência", valor: "Colérico" },
                { texto: "Você pensa em tudo com tanto cuidado", valor: "Melancólico" },
                { texto: "Você transmite paz e equilíbrio", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Qual sua maior dificuldade ao trabalhar em equipe?",
            opcoes: [
                { texto: "Ficar calado ou se concentrar por muito tempo", valor: "Sanguíneo" },
                { texto: "Ter que esperar os outros decidirem", valor: "Colérico" },
                { texto: "Conviver com bagunça ou falta de organização", valor: "Melancólico" },
                { texto: "Ter que lidar com pessoas autoritárias", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Quando o assunto é planejamento, você costuma:",
            opcoes: [
                { texto: "Improvisar no caminho", valor: "Sanguíneo" },
                { texto: "Traçar metas claras e agressivas", valor: "Colérico" },
                { texto: "Planejar minuciosamente", valor: "Melancólico" },
                { texto: "Preferir algo flexível e adaptável", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Diante de uma falha cometida por alguém, você:",
            opcoes: [
                { texto: "Faz piada ou releva", valor: "Sanguíneo" },
                { texto: "Cobra ou corrige na hora", valor: "Colérico" },
                { texto: "Fica magoado e guarda para si", valor: "Melancólico" },
                { texto: "Perdoa com facilidade", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Seu ritmo ideal de trabalho seria:",
            opcoes: [
                { texto: "Intenso, variado e estimulante", valor: "Sanguíneo" },
                { texto: "Acelerado e com entregas constantes", valor: "Colérico" },
                { texto: "Profundo, técnico e bem planejado", valor: "Melancólico" },
                { texto: "Calmo, constante e sem pressão", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Qual desses ambientes te deixa mais desconfortável?",
            opcoes: [
                { texto: "Ambientes silenciosos e frios", valor: "Sanguíneo" },
                { texto: "Locais sem liderança ou foco", valor: "Colérico" },
                { texto: "Lugares confusos e desorganizados", valor: "Melancólico" },
                { texto: "Locais com tensão ou conflito direto", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Em momentos de estresse, você tende a:",
            opcoes: [
                { texto: "Falar mais ou tentar distrair os outros", valor: "Sanguíneo" },
                { texto: "Ficar mais agressivo e impaciente", valor: "Colérico" },
                { texto: "Se fechar e remoer tudo mentalmente", valor: "Melancólico" },
                { texto: "Se calar e tentar manter a paz", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Quando se fala em metas e objetivos, você:",
            opcoes: [
                { texto: "Se motiva, mas às vezes perde o foco", valor: "Sanguíneo" },
                { texto: "Vai com tudo até cumprir", valor: "Colérico" },
                { texto: "Reflete muito antes de agir", valor: "Melancólico" },
                { texto: "Só se compromete com o que é realista", valor: "Fleumático" }
            ]
        },
        {
            pergunta: "Quando precisa convencer alguém, você tende a usar:",
            opcoes: [
                { texto: "Charme e bom humor", valor: "Sanguíneo" },
                { texto: "Argumentos firmes e liderança", valor: "Colérico" },
                { texto: "Lógica, dados e detalhes", valor: "Melancólico" },
                { texto: "Empatia e diplomacia", valor: "Fleumático" }
            ]
        }
    ];
}

// Função para carregar perguntas do teste de Personalidade
function loadPersonalidadeQuestions() {
    // Implementar perguntas para o teste de Personalidade
    return [
        {
            pergunta: "Como você reage quando está sob pressão?",
            opcoes: [
                { texto: "Fico ansioso e preocupado", valor: "A" },
                { texto: "Mantenho a calma e foco na solução", valor: "B" },
                { texto: "Busco ajuda de outras pessoas", valor: "C" },
                { texto: "Prefiro me isolar para pensar", valor: "D" }
            ]
        },
        // Adicionar mais perguntas aqui
    ];
}

// Função para carregar perguntas do teste de Perfil Animal
function loadAnimalQuestions() {
    // Implementar perguntas para o teste de Perfil Animal
    return [
        {
            pergunta: "Em uma situação de liderança, você prefere:",
            opcoes: [
                { texto: "Comandar com autoridade e visão", valor: "Águia" },
                { texto: "Liderar pelo exemplo e trabalho em equipe", valor: "Lobo" },
                { texto: "Usar estratégia e análise para direcionar", valor: "Tubarão" },
                { texto: "Influenciar com carisma e adaptabilidade", valor: "Gato" }
            ]
        },
        // Adicionar mais perguntas aqui
    ];
}

// Função para carregar perguntas do teste de Emoções
function loadEmocoesQuestions() {
    // Implementar perguntas para o teste de Emoções
    return [
        {
            pergunta: "Quando você se sente triste, geralmente:",
            opcoes: [
                { texto: "Busco atividades que me animem", valor: "A" },
                { texto: "Prefiro ficar sozinho para processar", valor: "B" },
                { texto: "Converso com amigos sobre o que sinto", valor: "C" },
                { texto: "Tento ignorar e seguir em frente", valor: "D" }
            ]
        },
        // Adicionar mais perguntas aqui
    ];
}

// Função para iniciar um teste
function startTest(testId, level) {
    // Verificar se o usuário está autenticado
    if (!verificarAutenticacao()) {
        window.location.href = 'login.html';
        return;
    }
    
    // Obter perguntas do teste
    const allQuestions = testData[testId] || [];
    
    // Definir número de perguntas com base no nível
    let numQuestions = 10; // Nível Essência
    if (level === 'clareza') numQuestions = 20;
    if (level === 'verdade') numQuestions = 30;
    
    // Selecionar perguntas para o teste
    const testQuestions = allQuestions.slice(0, numQuestions);
    
    // Salvar informações do teste atual na sessão
    sessionStorage.setItem('currentTest', JSON.stringify({
        id: testId,
        level: level,
        questions: testQuestions,
        currentQuestion: 0,
        answers: {}
    }));
    
    // Redirecionar para a página do teste
    window.location.href = 'escolha-nivel.html';
}

// Função para obter a próxima pergunta do teste
function getNextQuestion() {
    // Obter informações do teste atual
    const currentTest = JSON.parse(sessionStorage.getItem('currentTest') || '{}');
    
    // Verificar se há um teste em andamento
    if (!currentTest.id || !currentTest.questions) {
        return null;
    }
    
    // Verificar se já respondeu todas as perguntas
    if (currentTest.currentQuestion >= currentTest.questions.length) {
        return null;
    }
    
    // Obter a próxima pergunta
    const question = currentTest.questions[currentTest.currentQuestion];
    
    return {
        index: currentTest.currentQuestion,
        total: currentTest.questions.length,
        question: question
    };
}

// Função para responder uma pergunta
function answerQuestion(answer) {
    // Obter informações do teste atual
    const currentTest = JSON.parse(sessionStorage.getItem('currentTest') || '{}');
    
    // Verificar se há um teste em andamento
    if (!currentTest.id || !currentTest.questions) {
        return false;
    }
    
    // Salvar resposta
    currentTest.answers[currentTest.currentQuestion] = answer;
    
    // Avançar para a próxima pergunta
    currentTest.currentQuestion++;
    
    // Verificar se é a última pergunta
    const isLastQuestion = currentTest.currentQuestion >= currentTest.questions.length;
    
    // Atualizar informações do teste
    sessionStorage.setItem('currentTest', JSON.stringify(currentTest));
    
    // Retornar se é a última pergunta
    return isLastQuestion;
}

// Função para finalizar o teste e calcular resultado
function finishTest() {
    // Obter informações do teste atual
    const currentTest = JSON.parse(sessionStorage.getItem('currentTest') || '{}');
    
    // Verificar se há um teste em andamento
    if (!currentTest.id || !currentTest.questions || !currentTest.answers) {
        return null;
    }
    
    // Calcular resultado com base no tipo de teste
    let result = {};
    
    switch (currentTest.id) {
        case 'disc':
            result = calculateDISCResult(currentTest);
            break;
        case 'temperamento':
            result = calculateTemperamentoResult(currentTest);
            break;
        case 'personalidade':
            result = calculatePersonalidadeResult(currentTest);
            break;
        case 'animal':
            result = calculateAnimalResult(currentTest);
            break;
        case 'emocoes':
            result = calculateEmocoesResult(currentTest);
            break;
    }
    
    // Adicionar informações do teste ao resultado
    result.teste = currentTest.id;
    result.nivel = currentTest.level;
    result.data = new Date().toISOString();
    
    // Adicionar informações do usuário
    const usuario = getUsuarioAtual();
    if (usuario) {
        result.usuario_id = usuario.id || usuario.email;
        result.nome = usuario.nome;
        result.email = usuario.email;
        result.telefone = usuario.telefone;
    }
    
    // Salvar resultado no histórico
    saveTestResult(result);
    
    // Limpar teste atual
    sessionStorage.removeItem('currentTest');
    
    // Retornar resultado
    return result;
}

// Função para calcular resultado do teste DISC
function calculateDISCResult(test) {
    // Inicializar contadores
    const counts = {
        D: 0,
        I: 0,
        S: 0,
        C: 0
    };
    
    // Contar respostas
    Object.values(test.answers).forEach(answer => {
        if (counts[answer] !== undefined) {
            counts[answer]++;
        }
    });
    
    // Determinar perfil dominante e secundário
    let profiles = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    
    const perfilDominante = getDiscProfileName(profiles[0][0]);
    const perfilSecundario = getDiscProfileName(profiles[1][0]);
    
    // Criar resultado
    return {
        pontuacao: counts,
        perfil_dominante: perfilDominante,
        perfil_secundario: perfilSecundario,
        combinado: `${perfilDominante}-${perfilSecundario}`,
        respostas: test.answers
    };
}

// Função para obter nome do perfil DISC
function getDiscProfileName(letter) {
    switch (letter) {
        case 'D': return 'Dominância';
        case 'I': return 'Influência';
        case 'S': return 'Estabilidade';
        case 'C': return 'Conformidade';
        default: return '';
    }
}

// Função para calcular resultado do teste de Temperamento
function calculateTemperamentoResult(test) {
    // Inicializar contadores
    const counts = {
        'Sanguíneo': 0,
        'Colérico': 0,
        'Melancólico': 0,
        'Fleumático': 0
    };
    
    // Contar respostas
    Object.values(test.answers).forEach(answer => {
        if (counts[answer] !== undefined) {
            counts[answer]++;
        }
    });
    
    // Determinar perfil dominante e secundário
    let profiles = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    
    const perfilDominante = profiles[0][0];
    const perfilSecundario = profiles[1][0];
    
    // Criar resultado
    return {
        pontuacao: counts,
        perfil_dominante: perfilDominante,
        perfil_secundario: perfilSecundario,
        combinado: `${perfilDominante}-${perfilSecundario}`,
        respostas: test.answers
    };
}

// Função para calcular resultado do teste de Personalidade
function calculatePersonalidadeResult(test) {
    // Implementar cálculo para o teste de Personalidade
    return {
        pontuacao: {},
        perfil_dominante: 'Analítico',
        perfil_secundario: 'Expressivo',
        respostas: test.answers
    };
}

// Função para calcular resultado do teste de Perfil Animal
function calculateAnimalResult(test) {
    // Implementar cálculo para o teste de Perfil Animal
    return {
        pontuacao: {},
        perfil_dominante: 'Águia',
        perfil_secundario: 'Lobo',
        respostas: test.answers
    };
}

// Função para calcular resultado do teste de Emoções
function calculateEmocoesResult(test) {
    // Implementar cálculo para o teste de Emoções
    return {
        pontuacao: {},
        perfil_dominante: 'Equilibrado',
        perfil_secundario: 'Empático',
        respostas: test.answers
    };
}

// Função para salvar resultado do teste
function saveTestResult(result) {
    // Obter resultados anteriores
    const testResults = JSON.parse(localStorage.getItem('testResults') || '[]');
    
    // Adicionar novo resultado
    testResults.push(result);
    
    // Salvar resultados
    localStorage.setItem('testResults', JSON.stringify(testResults));
    
    // Enviar resultado para API (se configurado)
    sendResultToAPI(result);
}

// Função para enviar resultado para API
function sendResultToAPI(result) {
    // Verificar se há configuração de API
    const apiConfig = JSON.parse(localStorage.getItem('apiConfig') || '{}');
    
    if (!apiConfig.apiKey) {
        console.log('API não configurada');
        return;
    }
    
    // Enviar resultado para API (implementação futura)
    console.log('Enviando resultado para API:', result);
}

// Função para carregar progresso dos testes
function loadTestProgress() {
    const usuario = getUsuarioAtual();
    if (!usuario) return;
    
    const userId = usuario.id || usuario.email;
    const testResults = JSON.parse(localStorage.getItem('testResults') || '[]');
    const userResults = testResults.filter(result => result.usuario_id === userId);
    
    // Resetar todos os indicadores
    document.querySelectorAll('.test-level').forEach(el => {
        el.innerHTML = `<i class="far fa-circle"></i> ${el.textContent.trim()}`;
        el.classList.remove('completed');
    });
    
    // Atualizar indicadores com base nos resultados
    userResults.forEach(result => {
        const testId = result.teste;
        const level = result.nivel || 'essencia';
        
        let levelIndex = 1;
        if (level === 'clareza') levelIndex = 2;
        if (level === 'verdade') levelIndex = 3;
        
        for (let i = 1; i <= levelIndex; i++) {
            const levelElement = document.getElementById(`${testId}-level-${i}`);
            if (levelElement) {
                levelElement.innerHTML = `<i class="fas fa-check-circle"></i> ${levelElement.textContent.trim()}`;
                levelElement.classList.add('completed');
            }
        }
        
        // Atualizar status do teste
        const testCard = document.querySelector(`.test-card button[data-test-id="${testId}"]`);
        if (testCard) {
            const card = testCard.closest('.test-card');
            const statusBadge = card.querySelector('.status-badge');
            
            statusBadge.textContent = 'Realizado';
            statusBadge.classList.remove('test-available');
            statusBadge.classList.add('test-completed');
        }
    });
    
    // Verificar se Análise 360° deve ser habilitada
    checkAnalysis360Eligibility();
}

// Função para verificar elegibilidade para Análise 360°
function checkAnalysis360Eligibility() {
    const usuario = getUsuarioAtual();
    if (!usuario) return;
    
    const userId = usuario.id || usuario.email;
    const testResults = JSON.parse(localStorage.getItem('testResults') || '[]');
    const userResults = testResults.filter(result => result.usuario_id === userId);
    
    // Verificar se todos os testes foram realizados no nível Verdade
    const testsCompleted = {
        disc: false,
        temperamento: false,
        personalidade: false,
        animal: false,
        emocoes: false
    };
    
    userResults.forEach(result => {
        if (result.nivel === 'verdade' && testsCompleted[result.teste] !== undefined) {
            testsCompleted[result.teste] = true;
        }
    });
    
    // Verificar se todos os testes foram completados
    const allTestsCompleted = Object.values(testsCompleted).every(completed => completed);
    
    // Atualizar botão de Análise 360°
    const analysisButton = document.getElementById('analysis-360-btn');
    if (analysisButton) {
        if (allTestsCompleted) {
            analysisButton.classList.remove('disabled');
        } else {
            analysisButton.classList.add('disabled');
        }
    }
}

// Função para carregar resultados recentes
function loadRecentResults() {
    const usuario = getUsuarioAtual();
    if (!usuario) return;
    
    const userId = usuario.id || usuario.email;
    const testResults = JSON.parse(localStorage.getItem('testResults') || '[]');
    const userResults = testResults.filter(result => result.usuario_id === userId)
        .sort((a, b) => new Date(b.data) - new Date(a.data))
        .slice(0, 3); // Mostrar apenas os 3 mais recentes
    
    const resultsContainer = document.getElementById('recent-results-container');
    const noResultsMessage = document.getElementById('no-results-message');
    
    if (userResults.length === 0) {
        if (noResultsMessage) {
            noResultsMessage.style.display = 'block';
        }
        return;
    }
    
    if (noResultsMessage) {
        noResultsMessage.style.display = 'none';
    }
    
    // Limpar container
    if (resultsContainer) {
        resultsContainer.innerHTML = '';
        
        // Adicionar resultados recentes
        userResults.forEach(result => {
            const resultCard = createResultCard(result);
            resultsContainer.appendChild(resultCard);
        });
    }
}

// Função para criar card de resultado
function createResultCard(result) {
    const card = document.createElement('div');
    card.className = 'result-card fade-in';
    
    const testName = getTestName(result.teste);
    const testDate = new Date(result.data).toLocaleDateString('pt-BR');
    const testLevel = getLevelName(result.nivel);
    
    card.innerHTML = `
        <div class="result-header">
            <h3>${testName}</h3>
            <span class="result-date">${testDate}</span>
        </div>
        <div class="result-profile">
            <div class="profile-item">
                <span class="profile-label">Nível:</span>
                <span class="profile-value">${testLevel}</span>
            </div>
            <div class="profile-item">
                <span class="profile-label">Perfil Dominante:</span>
                <span class="profile-value">${result.perfil_dominante}</span>
            </div>
            <div class="profile-item">
                <span class="profile-label">Perfil Secundário:</span>
                <span class="profile-value">${result.perfil_secundario}</span>
            </div>
        </div>
        <div class="result-actions">
            <button class="btn btn-outline view-result-btn" data-test-id="${result.teste}" data-result-id="${result.data}">Ver Detalhes</button>
            <button class="btn btn-primary retake-test-btn" data-test-id="${result.teste}">Refazer Teste</button>
        </div>
    `;
    
    // Adicionar eventos aos botões
    const viewButton = card.querySelector('.view-result-btn');
    const retakeButton = card.querySelector('.retake-test-btn');
    
    if (viewButton) {
        viewButton.addEventListener('click', function() {
            const testId = this.getAttribute('data-test-id');
            const resultId = this.getAttribute('data-result-id');
            viewTestResult(testId, resultId);
        });
    }
    
    if (retakeButton) {
        retakeButton.addEventListener('click', function() {
            const testId = this.getAttribute('data-test-id');
            retakeTest(testId);
        });
    }
    
    return card;
}

// Função para obter nome do teste
function getTestName(testId) {
    switch (testId) {
        case 'disc': return 'DISC';
        case 'temperamento': return 'Temperamento';
        case 'personalidade': return 'Personalidade';
        case 'animal': return 'Perfil Animal';
        case 'emocoes': return 'Emoções';
        default: return testId;
    }
}

// Função para obter nome do nível
function getLevelName(level) {
    switch (level) {
        case 'essencia': return 'Essência';
        case 'clareza': return 'Clareza';
        case 'verdade': return 'Verdade';
        default: return level;
    }
}

// Função para abrir modal de teste
function openTestModal(testId) {
    const modal = document.getElementById('start-test-modal');
    const modalTitle = document.getElementById('modal-test-title');
    const modalDescription = document.getElementById('modal-test-description');
    const modalTestInfo = document.getElementById('modal-test-info');
    const modalTestStatus = document.getElementById('modal-test-status');
    
    if (!modal) return;
    
    // Definir ID do teste no modal
    modal.querySelector('.modal-content').setAttribute('data-test-id', testId);
    
    // Definir título do modal
    modalTitle.textContent = `Teste de ${getTestName(testId)}`;
    
    // Verificar se o usuário já realizou o teste
    const usuario = getUsuarioAtual();
    if (!usuario) return;
    
    const userId = usuario.id || usuario.email;
    const testResults = JSON.parse(localStorage.getItem('testResults') || '[]');
    const userTestResults = testResults.filter(result => result.usuario_id === userId && result.teste === testId);
    
    if (userTestResults.length > 0) {
        // Usuário já realizou o teste
        modalTestInfo.style.display = 'none';
        modalTestStatus.style.display = 'block';
        
        // Configurar botões
        document.getElementById('view-result-btn').setAttribute('data-test-id', testId);
        document.getElementById('retake-test-btn').setAttribute('data-test-id', testId);
    } else {
        // Usuário ainda não realizou o teste
        modalTestInfo.style.display = 'block';
        modalTestStatus.style.display = 'none';
        
        // Descrição do teste
        switch (testId) {
            case 'disc':
                modalDescription.textContent = 'Avalie seu estilo comportamental em quatro dimensões: Dominância, Influência, Estabilidade e Conformidade.';
                break;
            case 'temperamento':
                modalDescription.textContent = 'Descubra seu temperamento predominante entre Sanguíneo, Colérico, Melancólico e Fleumático.';
                break;
            case 'personalidade':
                modalDescription.textContent = 'Analise os traços de sua personalidade e descubra como eles influenciam seu comportamento.';
                break;
            case 'animal':
                modalDescription.textContent = 'Identifique seu perfil animal predominante: Águia, Lobo, Tubarão ou Gato.';
                break;
            case 'emocoes':
                modalDescription.textContent = 'Mapeie seus padrões emocionais e descubra como eles afetam suas decisões e relacionamentos.';
                break;
        }
    }
    
    // Exibir modal
    modal.style.display = 'block';
}

// Função para visualizar resultado de teste
function viewTestResult(testId, resultId) {
    // Salvar ID do teste e resultado na sessão
    sessionStorage.setItem('viewTestId', testId);
    sessionStorage.setItem('viewResultId', resultId || '');
    
    // Redirecionar para página de resultado
    window.location.href = 'resultado.html';
}

// Função para refazer teste
function retakeTest(testId) {
    // Abrir modal de seleção de nível
    const modal = document.getElementById('start-test-modal');
    const modalTitle = document.getElementById('modal-test-title');
    const modalDescription = document.getElementById('modal-test-description');
    const modalTestInfo = document.getElementById('modal-test-info');
    const modalTestStatus = document.getElementById('modal-test-status');
    
    if (!modal) return;
    
    // Definir ID do teste no modal
    modal.querySelector('.modal-content').setAttribute('data-test-id', testId);
    
    // Definir título do modal
    modalTitle.textContent = `Refazer Teste de ${getTestName(testId)}`;
    
    // Exibir opções de nível
    modalTestInfo.style.display = 'block';
    modalTestStatus.style.display = 'none';
    
    // Descrição do teste
    switch (testId) {
        case 'disc':
            modalDescription.textContent = 'Avalie seu estilo comportamental em quatro dimensões: Dominância, Influência, Estabilidade e Conformidade.';
            break;
        case 'temperamento':
            modalDescription.textContent = 'Descubra seu temperamento predominante entre Sanguíneo, Colérico, Melancólico e Fleumático.';
            break;
        case 'personalidade':
            modalDescription.textContent = 'Analise os traços de sua personalidade e descubra como eles influenciam seu comportamento.';
            break;
        case 'animal':
            modalDescription.textContent = 'Identifique seu perfil animal predominante: Águia, Lobo, Tubarão ou Gato.';
            break;
        case 'emocoes':
            modalDescription.textContent = 'Mapeie seus padrões emocionais e descubra como eles afetam suas decisões e relacionamentos.';
            break;
    }
    
    // Exibir modal
    modal.style.display = 'block';
}

// Inicializar banco de dados ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    initializeDatabase();
});
