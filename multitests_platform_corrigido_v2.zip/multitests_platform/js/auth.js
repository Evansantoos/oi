// Funções de autenticação e gerenciamento de usuários

// Variáveis globais
let currentUser = null;
const DB_USERS_KEY = 'multitests_users';
const DB_ADMINS_KEY = 'multitests_admins';
const DB_CURRENT_USER_KEY = 'multitests_current_user';
const AUTH_TOKEN_KEY = 'multitests_auth_token';
const RESET_TOKENS_KEY = 'multitests_reset_tokens';

// Inicializar banco de dados local (simulação)
function initializeLocalDB() {
    // Inicializar usuários se não existir
    if (!localStorage.getItem(DB_USERS_KEY)) {
        localStorage.setItem(DB_USERS_KEY, JSON.stringify([]));
    }
    
    // Inicializar administradores se não existir
    if (!localStorage.getItem(DB_ADMINS_KEY)) {
        // Criar administrador padrão
        const defaultAdmin = {
            id: generateUUID(),
            nome: 'Administrador',
            email: 'admin@startinc.com.br',
            telefone: '(51) 99149-0515',
            senha: hashPassword('admin2025'),
            data_cadastro: new Date().toISOString(),
            ultimo_acesso: new Date().toISOString(),
            role: 'admin'
        };
        
        localStorage.setItem(DB_ADMINS_KEY, JSON.stringify([defaultAdmin]));
        console.log('Administrador padrão criado com sucesso!');
        console.log('Email: admin@startinc.com.br');
        console.log('Senha: admin2025');
    }
    
    // Inicializar tokens de redefinição se não existir
    if (!localStorage.getItem(RESET_TOKENS_KEY)) {
        localStorage.setItem(RESET_TOKENS_KEY, JSON.stringify([]));
    }
}

// Gerar UUID
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Gerar hash de senha (simulação - em produção usar bcrypt ou similar)
function hashPassword(password) {
    // Em produção, usar bcrypt ou similar
    // Esta é apenas uma simulação básica de hash
    return btoa(password + "salt_random_for_security");
}

// Verificar senha (simulação - em produção usar bcrypt.compare ou similar)
function verifyPassword(password, hashedPassword) {
    // Em produção, usar bcrypt.compare ou similar
    // Esta é apenas uma simulação básica de verificação
    return hashedPassword === btoa(password + "salt_random_for_security");
}

// Gerar token de autenticação
function generateAuthToken(userId, isAdmin = false) {
    // Em produção, usar JWT ou similar
    // Esta é apenas uma simulação básica de token
    const tokenData = {
        userId: userId,
        isAdmin: isAdmin,
        timestamp: new Date().getTime(),
        expiry: new Date().getTime() + (7 * 24 * 60 * 60 * 1000) // 7 dias
    };
    
    return btoa(JSON.stringify(tokenData));
}

// Verificar token de autenticação
function verifyAuthToken(token) {
    try {
        const tokenData = JSON.parse(atob(token));
        const now = new Date().getTime();
        
        // Verificar se o token expirou
        if (tokenData.expiry < now) {
            return null;
        }
        
        return {
            userId: tokenData.userId,
            isAdmin: tokenData.isAdmin
        };
    } catch (error) {
        console.error('Erro ao verificar token:', error);
        return null;
    }
}

// Cadastrar novo usuário
function cadastrarUsuario(nome, email, telefone, senha, dadosAdicionais = {}) {
    initializeLocalDB();
    
    // Verificar se o e-mail já está cadastrado (usuários)
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY));
    const userExists = users.some(user => user.email === email);
    
    if (userExists) {
        showNotification('Este e-mail já está cadastrado.', 'error');
        return false;
    }
    
    // Verificar se o e-mail já está cadastrado (administradores)
    const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY));
    const adminExists = admins.some(admin => admin.email === email);
    
    if (adminExists) {
        showNotification('Este e-mail já está cadastrado.', 'error');
        return false;
    }
    
    // Criar novo usuário
    const newUser = {
        id: generateUUID(),
        nome: nome,
        email: email,
        telefone: telefone,
        senha: hashPassword(senha),
        data_cadastro: new Date().toISOString(),
        ultimo_acesso: new Date().toISOString(),
        role: 'user',
        ...dadosAdicionais
    };
    
    // Adicionar ao banco de dados local
    users.push(newUser);
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    
    // Gerar token de autenticação
    const authToken = generateAuthToken(newUser.id, false);
    localStorage.setItem(AUTH_TOKEN_KEY, authToken);
    
    // Salvar usuário atual
    const currentUserData = { ...newUser };
    delete currentUserData.senha; // Não armazenar senha em memória
    localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUserData));
    currentUser = currentUserData;
    
    showNotification('Cadastro realizado com sucesso!', 'success');
    
    // Redirecionar para o painel
    setTimeout(() => {
        window.location.href = 'painel.html';
    }, 1500);
    
    return true;
}

// Fazer login (usuário ou admin)
function fazerLogin(email, senha) {
    initializeLocalDB();
    
    // Buscar usuário pelo e-mail
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY));
    const user = users.find(user => user.email === email);
    
    // Buscar admin pelo e-mail
    const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY));
    const admin = admins.find(admin => admin.email === email);
    
    // Verificar se é usuário
    if (user) {
        // Verificar senha
        if (!verifyPassword(senha, user.senha)) {
            showNotification('E-mail ou senha incorretos.', 'error');
            return false;
        }
        
        // Atualizar último acesso
        user.ultimo_acesso = new Date().toISOString();
        localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
        
        // Gerar token de autenticação
        const authToken = generateAuthToken(user.id, false);
        localStorage.setItem(AUTH_TOKEN_KEY, authToken);
        
        // Salvar usuário atual
        const currentUserData = { ...user };
        delete currentUserData.senha; // Não armazenar senha em memória
        localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUserData));
        currentUser = currentUserData;
        
        showNotification('Login realizado com sucesso!', 'success');
        
        // Redirecionar para o painel
        setTimeout(() => {
            window.location.href = 'painel.html';
        }, 1500);
        
        return true;
    }
    
    // Verificar se é admin
    if (admin) {
        // Verificar senha
        if (!verifyPassword(senha, admin.senha)) {
            showNotification('E-mail ou senha incorretos.', 'error');
            return false;
        }
        
        // Atualizar último acesso
        admin.ultimo_acesso = new Date().toISOString();
        localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins));
        
        // Gerar token de autenticação
        const authToken = generateAuthToken(admin.id, true);
        localStorage.setItem(AUTH_TOKEN_KEY, authToken);
        
        // Salvar usuário atual
        const currentUserData = { ...admin };
        delete currentUserData.senha; // Não armazenar senha em memória
        localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUserData));
        currentUser = currentUserData;
        
        showNotification('Login realizado com sucesso!', 'success');
        
        // Redirecionar para o painel administrativo
        setTimeout(() => {
            window.location.href = 'admin/painel.html';
        }, 1500);
        
        return true;
    }
    
    // Se não encontrou usuário nem admin
    showNotification('E-mail ou senha incorretos.', 'error');
    return false;
}

// Fazer logout
function fazerLogout() {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(DB_CURRENT_USER_KEY);
    currentUser = null;
    
    showNotification('Logout realizado com sucesso!', 'success');
    
    // Redirecionar para a página inicial
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1500);
}

// Verificar autenticação
function verificarAutenticacao() {
    const authToken = localStorage.getItem(AUTH_TOKEN_KEY);
    
    if (!authToken) {
        return false;
    }
    
    const tokenData = verifyAuthToken(authToken);
    
    if (!tokenData) {
        // Token inválido ou expirado
        localStorage.removeItem(AUTH_TOKEN_KEY);
        localStorage.removeItem(DB_CURRENT_USER_KEY);
        return false;
    }
    
    // Carregar usuário atual
    const userData = localStorage.getItem(DB_CURRENT_USER_KEY);
    
    if (!userData) {
        return false;
    }
    
    currentUser = JSON.parse(userData);
    return true;
}

// Verificar se é administrador
function verificarAdmin() {
    if (!verificarAutenticacao()) {
        return false;
    }
    
    return currentUser.role === 'admin';
}

// Proteger página (redirecionar se não estiver autenticado)
function protegerPagina() {
    if (!verificarAutenticacao()) {
        showNotification('Você precisa fazer login para acessar esta página.', 'warning');
        
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1500);
        
        return false;
    }
    
    return true;
}

// Proteger página administrativa (redirecionar se não for admin)
function protegerPaginaAdmin() {
    if (!verificarAutenticacao()) {
        showNotification('Você precisa fazer login para acessar esta página.', 'warning');
        
        setTimeout(() => {
            window.location.href = '../login.html';
        }, 1500);
        
        return false;
    }
    
    if (!verificarAdmin()) {
        showNotification('Você não tem permissão para acessar esta página.', 'error');
        
        setTimeout(() => {
            window.location.href = '../painel.html';
        }, 1500);
        
        return false;
    }
    
    return true;
}

// Obter usuário atual
function getUsuarioAtual() {
    if (!currentUser) {
        verificarAutenticacao();
    }
    
    return currentUser;
}

// Atualizar dados do usuário
function atualizarUsuario(nome, email, telefone, dadosAdicionais = {}) {
    if (!verificarAutenticacao()) {
        return false;
    }
    
    const isAdmin = currentUser.role === 'admin';
    
    if (isAdmin) {
        // Atualizar admin
        const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY));
        const adminIndex = admins.findIndex(admin => admin.id === currentUser.id);
        
        if (adminIndex === -1) {
            showNotification('Erro ao atualizar dados.', 'error');
            return false;
        }
        
        // Atualizar dados
        admins[adminIndex].nome = nome;
        admins[adminIndex].email = email;
        admins[adminIndex].telefone = telefone;
        
        // Salvar no banco de dados local
        localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins));
        
        // Atualizar usuário atual
        currentUser.nome = nome;
        currentUser.email = email;
        currentUser.telefone = telefone;
        localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUser));
    } else {
        // Atualizar usuário
        const users = JSON.parse(localStorage.getItem(DB_USERS_KEY));
        const userIndex = users.findIndex(user => user.id === currentUser.id);
        
        if (userIndex === -1) {
            showNotification('Erro ao atualizar dados.', 'error');
            return false;
        }
        
        // Atualizar dados
        users[userIndex].nome = nome;
        users[userIndex].email = email;
        users[userIndex].telefone = telefone;
        
        // Atualizar dados adicionais
        for (const key in dadosAdicionais) {
            users[userIndex][key] = dadosAdicionais[key];
        }
        
        // Salvar no banco de dados local
        localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
        
        // Atualizar usuário atual
        currentUser.nome = nome;
        currentUser.email = email;
        currentUser.telefone = telefone;
        
        // Atualizar dados adicionais no usuário atual
        for (const key in dadosAdicionais) {
            currentUser[key] = dadosAdicionais[key];
        }
        
        localStorage.setItem(DB_CURRENT_USER_KEY, JSON.stringify(currentUser));
    }
    
    showNotification('Dados atualizados com sucesso!', 'success');
    return true;
}

// Alterar senha
function alterarSenha(senhaAtual, novaSenha) {
    if (!verificarAutenticacao()) {
        return false;
    }
    
    const isAdmin = currentUser.role === 'admin';
    
    if (isAdmin) {
        // Alterar senha de admin
        const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY));
        const adminIndex = admins.findIndex(admin => admin.id === currentUser.id);
        
        if (adminIndex === -1) {
            showNotification('Erro ao alterar senha.', 'error');
            return false;
        }
        
        // Verificar senha atual
        if (!verifyPassword(senhaAtual, admins[adminIndex].senha)) {
            showNotification('Senha atual incorreta.', 'error');
            return false;
        }
        
        // Atualizar senha
        admins[adminIndex].senha = hashPassword(novaSenha);
        
        // Salvar no banco de dados local
        localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins));
    } else {
        // Alterar senha de usuário
        const users = JSON.parse(localStorage.getItem(DB_USERS_KEY));
        const userIndex = users.findIndex(user => user.id === currentUser.id);
        
        if (userIndex === -1) {
            showNotification('Erro ao alterar senha.', 'error');
            return false;
        }
        
        // Verificar senha atual
        if (!verifyPassword(senhaAtual, users[userIndex].senha)) {
            showNotification('Senha atual incorreta.', 'error');
            return false;
        }
        
        // Atualizar senha
        users[userIndex].senha = hashPassword(novaSenha);
        
        // Salvar no banco de dados local
        localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    }
    
    showNotification('Senha alterada com sucesso!', 'success');
    return true;
}

// Solicitar redefinição de senha
function solicitarRedefinicaoSenha(email) {
    initializeLocalDB();
    
    // Buscar usuário pelo e-mail
    const users = JSON.parse(localStorage.getItem(DB_USERS_KEY));
    const user = users.find(user => user.email === email);
    
    // Buscar admin pelo e-mail
    const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY));
    const admin = admins.find(admin => admin.email === email);
    
    if (!user && !admin) {
        // Não informar que o e-mail não existe por segurança
        showNotification('Se o e-mail estiver cadastrado, você receberá instruções para redefinir sua senha.', 'info');
        return true;
    }
    
    // Gerar token de redefinição
    const token = generateUUID();
    const expiry = new Date().getTime() + (24 * 60 * 60 * 1000); // 24 horas
    
    // Salvar token
    const resetTokens = JSON.parse(localStorage.getItem(RESET_TOKENS_KEY));
    resetTokens.push({
        token,
        email,
        expiry,
        isAdmin: !!admin
    });
    
    localStorage.setItem(RESET_TOKENS_KEY, JSON.stringify(resetTokens));
    
    // Em produção, enviar e-mail com link para redefinição
    // Aqui, apenas simulamos o envio e mostramos o link
    const resetLink = `${window.location.origin}/redefinir-senha.html?token=${token}`;
    console.log('Link de redefinição:', resetLink);
    
    showNotification('Se o e-mail estiver cadastrado, você receberá instruções para redefinir sua senha.', 'info');
    
    // Apenas para demonstração, mostrar o link na página
    const resetLinkElement = document.createElement('div');
    resetLinkElement.className = 'alert alert-info mt-3';
    resetLinkElement.innerHTML = `
        <p><strong>Simulação de e-mail:</strong></p>
        <p>Clique no link abaixo para redefinir sua senha:</p>
        <a href="${resetLink}" target="_blank">${resetLink}</a>
    `;
    
    document.querySelector('.container').appendChild(resetLinkElement);
    
    return true;
}

// Verificar token de redefinição
function verificarTokenRedefinicao(token) {
    initializeLocalDB();
    
    const resetTokens = JSON.parse(localStorage.getItem(RESET_TOKENS_KEY));
    const tokenData = resetTokens.find(t => t.token === token);
    
    if (!tokenData) {
        return null;
    }
    
    // Verificar se o token expirou
    if (tokenData.expiry < new Date().getTime()) {
        return null;
    }
    
    return tokenData;
}

// Redefinir senha
function redefinirSenha(token, novaSenha) {
    const tokenData = verificarTokenRedefinicao(token);
    
    if (!tokenData) {
        showNotification('Token inválido ou expirado.', 'error');
        return false;
    }
    
    if (tokenData.isAdmin) {
        // Redefinir senha de admin
        const admins = JSON.parse(localStorage.getItem(DB_ADMINS_KEY));
        const adminIndex = admins.findIndex(admin => admin.email === tokenData.email);
        
        if (adminIndex === -1) {
            showNotification('Erro ao redefinir senha.', 'error');
            return false;
        }
        
        // Atualizar senha
        admins[adminIndex].senha = hashPassword(novaSenha);
        
        // Salvar no banco de dados local
        localStorage.setItem(DB_ADMINS_KEY, JSON.stringify(admins));
    } else {
        // Redefinir senha de usuário
        const users = JSON.parse(localStorage.getItem(DB_USERS_KEY));
        const userIndex = users.findIndex(user => user.email === tokenData.email);
        
        if (userIndex === -1) {
            showNotification('Erro ao redefinir senha.', 'error');
            return false;
        }
        
        // Atualizar senha
        users[userIndex].senha = hashPassword(novaSenha);
        
        // Salvar no banco de dados local
        localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
    }
    
    // Remover token usado
    const resetTokens = JSON.parse(localStorage.getItem(RESET_TOKENS_KEY));
    const updatedTokens = resetTokens.filter(t => t.token !== token);
    localStorage.setItem(RESET_TOKENS_KEY, JSON.stringify(updatedTokens));
    
    showNotification('Senha redefinida com sucesso!', 'success');
    
    // Redirecionar para login
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 1500);
    
    return true;
}

// Exibir notificação
function showNotification(message, type = 'info') {
    // Remover notificações existentes
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => {
        notification.remove();
    });
    
    // Criar nova notificação
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Adicionar ao corpo do documento
    document.body.appendChild(notification);
    
    // Remover após 3 segundos
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Inicializar autenticação quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    initializeLocalDB();
    
    // Verificar se está na página de cadastro
    if (window.location.pathname.includes('cadastro.html')) {
        // Se já estiver autenticado, redirecionar para o painel
        if (verificarAutenticacao()) {
            window.location.href = 'painel.html';
        }
    }
    
    // Verificar se está na página de login
    if (window.location.pathname.includes('login.html')) {
        // Se já estiver autenticado, redirecionar para o painel
        if (verificarAutenticacao()) {
            const isAdmin = getUsuarioAtual().role === 'admin';
            if (isAdmin) {
                window.location.href = 'admin/painel.html';
            } else {
                window.location.href = 'painel.html';
            }
        }
    }
    
    // Verificar se está na página de recuperação de senha
    if (window.location.pathname.includes('recuperar-senha.html')) {
        // Se já estiver autenticado, redirecionar para o painel
        if (verificarAutenticacao()) {
            const isAdmin = getUsuarioAtual().role === 'admin';
            if (isAdmin) {
                window.location.href = 'admin/painel.html';
            } else {
                window.location.href = 'painel.html';
            }
        }
    }
    
    // Verificar se está na página de redefinição de senha
    if (window.location.pathname.includes('redefinir-senha.html')) {
        // Verificar token na URL
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('token');
        
        if (!token) {
            showNotification('Token inválido ou ausente.', 'error');
            setTimeout(() => {
                window.location.href = 'recuperar-senha.html';
            }, 1500);
        } else {
            // Verificar validade do token
            const tokenData = verificarTokenRedefinicao(token);
            if (!tokenData) {
                showNotification('Token inválido ou expirado.', 'error');
                setTimeout(() => {
                    window.location.href = 'recuperar-senha.html';
                }, 1500);
            }
        }
    }
    
    // Verificar se está no painel ou em páginas protegidas
    if (window.location.pathname.includes('painel.html') || 
        window.location.pathname.includes('teste.html') || 
        window.location.pathname.includes('resultado.html') || 
        window.location.pathname.includes('historico.html') || 
        window.location.pathname.includes('perfil.html')) {
        
        protegerPagina();
    }
    
    // Verificar se está em páginas administrativas
    if (window.location.pathname.includes('/admin/')) {
        protegerPaginaAdmin();
    }
});
