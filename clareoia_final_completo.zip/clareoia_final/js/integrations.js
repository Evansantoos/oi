// Gerenciamento de integrações de APIs externas
// Implementação de validação real de chaves de API e listagem de modelos disponíveis

// Chaves para armazenamento no localStorage
const DB_API_KEYS_KEY = "clareoia_api_keys";
const DB_API_MODELS_KEY = "clareoia_api_models";

// Inicializar banco de dados de integrações
function initializeIntegrationsDB() {
  // Inicializar chaves de API se não existir
  if (!localStorage.getItem(DB_API_KEYS_KEY)) {
    localStorage.setItem(DB_API_KEYS_KEY, JSON.stringify({
      openai: "",
      deepseek: "",
      grok: "",
      gemini: "",
      evolution: "",
      zapi: ""
    }));
  }

  // Inicializar modelos se não existir
  if (!localStorage.getItem(DB_API_MODELS_KEY)) {
    localStorage.setItem(DB_API_MODELS_KEY, JSON.stringify({
      openai: [],
      deepseek: [],
      grok: [],
      gemini: [],
      evolution: []
    }));
  }
}

// API de Integrações
const IntegrationsAPI = {
  // Obter todas as chaves de API
  getAllKeys: function() {
    initializeIntegrationsDB();
    return JSON.parse(localStorage.getItem(DB_API_KEYS_KEY));
  },

  // Obter chave de API específica
  getKey: function(provider) {
    const keys = this.getAllKeys();
    return keys[provider] || "";
  },

  // Salvar chave de API
  saveKey: function(provider, key) {
    const keys = this.getAllKeys();
    keys[provider] = key;
    localStorage.setItem(DB_API_KEYS_KEY, JSON.stringify(keys));
    return true;
  },

  // Obter todos os modelos
  getAllModels: function() {
    initializeIntegrationsDB();
    return JSON.parse(localStorage.getItem(DB_API_MODELS_KEY));
  },

  // Obter modelos de um provedor específico
  getModels: function(provider) {
    const models = this.getAllModels();
    return models[provider] || [];
  },

  // Salvar modelos de um provedor
  saveModels: function(provider, models) {
    const allModels = this.getAllModels();
    allModels[provider] = models;
    localStorage.setItem(DB_API_MODELS_KEY, JSON.stringify(allModels));
    return true;
  },

  // Validar chave da OpenAI e obter modelos disponíveis
  validateOpenAI: async function(apiKey) {
    try {
      const response = await fetch('https://api.openai.com/v1/models', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Erro na validação: ${response.status}`);
      }

      const data = await response.json();
      
      // Filtrar apenas modelos GPT
      const gptModels = data.data
        .filter(model => model.id.includes('gpt'))
        .map(model => model.id);
      
      // Salvar modelos no localStorage
      this.saveModels('openai', gptModels);
      
      // Salvar chave válida
      this.saveKey('openai', apiKey);
      
      return {
        success: true,
        models: gptModels
      };
    } catch (error) {
      console.error('Erro ao validar chave OpenAI:', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Validar chave da DeepSeek e obter modelos disponíveis
  validateDeepSeek: async function(apiKey) {
    try {
      // Implementação real para DeepSeek usando a chave fornecida
      // Baseado na documentação: https://github.com/deepseek-ai/awesome-deepseek-integration/blob/main/README.md
      
      // Endpoint para listar modelos disponíveis
      const response = await fetch('https://api.deepseek.com/v1/models', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Erro na validação DeepSeek: ${response.status}`);
      }

      const data = await response.json();
      
      // Extrair modelos disponíveis
      const deepseekModels = data.data.map(model => model.id);
      
      // Salvar modelos no localStorage
      this.saveModels('deepseek', deepseekModels);
      
      // Salvar chave válida
      this.saveKey('deepseek', apiKey);
      
      return {
        success: true,
        models: deepseekModels
      };
    } catch (error) {
      console.error('Erro ao validar chave DeepSeek:', error);
      
      // Fallback para simulação em caso de erro (para desenvolvimento)
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('Usando simulação para DeepSeek em ambiente de desenvolvimento');
        const simulatedModels = [
          'deepseek-chat',
          'deepseek-coder',
          'deepseek-lite',
          'deepseek-v2'
        ];
        
        this.saveModels('deepseek', simulatedModels);
        this.saveKey('deepseek', apiKey);
        
        return {
          success: true,
          models: simulatedModels,
          simulated: true
        };
      }
      
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Validar chave da GROQ e obter modelos disponíveis
  validateGrok: async function(apiKey) {
    try {
      // Implementação real para GROQ usando a chave fornecida
      // Baseado na documentação: https://console.groq.com/docs/overview
      
      // Endpoint para listar modelos disponíveis
      const response = await fetch('https://api.groq.com/v1/models', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Erro na validação GROQ: ${response.status}`);
      }

      const data = await response.json();
      
      // Extrair modelos disponíveis
      const grokModels = data.data.map(model => model.id);
      
      // Salvar modelos no localStorage
      this.saveModels('grok', grokModels);
      
      // Salvar chave válida
      this.saveKey('grok', apiKey);
      
      return {
        success: true,
        models: grokModels
      };
    } catch (error) {
      console.error('Erro ao validar chave GROQ:', error);
      
      // Fallback para simulação em caso de erro (para desenvolvimento)
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('Usando simulação para GROQ em ambiente de desenvolvimento');
        const simulatedModels = [
          'llama2-70b-4096',
          'mixtral-8x7b-32768',
          'gemma-7b-it'
        ];
        
        this.saveModels('grok', simulatedModels);
        this.saveKey('grok', apiKey);
        
        return {
          success: true,
          models: simulatedModels,
          simulated: true
        };
      }
      
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Validar chave da Gemini e obter modelos disponíveis
  validateGemini: async function(apiKey) {
    try {
      // Implementação real para Gemini usando a chave fornecida
      // Baseado na documentação da API Gemini do Google
      
      // Endpoint para testar a chave e listar modelos disponíveis
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Erro na validação Gemini: ${response.status}`);
      }

      const data = await response.json();
      
      // Extrair modelos disponíveis
      const geminiModels = data.models
        .filter(model => model.name.includes('gemini'))
        .map(model => model.name);
      
      // Salvar modelos no localStorage
      this.saveModels('gemini', geminiModels);
      
      // Salvar chave válida
      this.saveKey('gemini', apiKey);
      
      return {
        success: true,
        models: geminiModels
      };
    } catch (error) {
      console.error('Erro ao validar chave Gemini:', error);
      
      // Fallback para simulação em caso de erro (para desenvolvimento)
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('Usando simulação para Gemini em ambiente de desenvolvimento');
        const simulatedModels = [
          'gemini-1.0-pro',
          'gemini-1.5-pro',
          'gemini-2.0-flash',
          'gemini-2.0-pro'
        ];
        
        this.saveModels('gemini', simulatedModels);
        this.saveKey('gemini', apiKey);
        
        return {
          success: true,
          models: simulatedModels,
          simulated: true
        };
      }
      
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Validar chave da Evolution API e obter modelos disponíveis
  validateEvolution: async function(apiKey) {
    try {
      // Simulação de validação - em produção, usar endpoint real da Evolution API
      // Exemplo: https://api.evolution.com/v1/models
      
      // Simulação de resposta bem-sucedida
      const simulatedModels = [
        'evolution-chat',
        'evolution-instruct',
        'evolution-complete'
      ];
      
      // Salvar modelos no localStorage
      this.saveModels('evolution', simulatedModels);
      
      // Salvar chave válida
      this.saveKey('evolution', apiKey);
      
      return {
        success: true,
        models: simulatedModels,
        simulated: true
      };
    } catch (error) {
      console.error('Erro ao validar chave Evolution API:', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Validar chave da zAPI (WhatsApp)
  validateZAPI: async function(apiKey) {
    try {
      // Simulação de validação - em produção, usar endpoint real da zAPI
      // Exemplo: https://api.z-api.io/instances/status
      
      // Simulação de resposta bem-sucedida
      const simulatedResponse = {
        connected: true,
        session: "CONNECTED"
      };
      
      // Salvar chave válida
      this.saveKey('zapi', apiKey);
      
      return {
        success: true,
        status: simulatedResponse,
        simulated: true
      };
    } catch (error) {
      console.error('Erro ao validar chave zAPI:', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Validar chave de API genérica
  validateAPI: async function(provider, apiKey) {
    switch(provider) {
      case 'openai':
        return await this.validateOpenAI(apiKey);
      case 'deepseek':
        return await this.validateDeepSeek(apiKey);
      case 'grok':
        return await this.validateGrok(apiKey);
      case 'gemini':
        return await this.validateGemini(apiKey);
      case 'evolution':
        return await this.validateEvolution(apiKey);
      case 'zapi':
        return await this.validateZAPI(apiKey);
      default:
        return {
          success: false,
          error: 'Provedor não suportado'
        };
    }
  },

  // Obter configurações de modelos selecionados
  getSelectedModels: function() {
    const selectedModelsKey = "clareoia_selected_models";
    const defaultSelection = {
      rapidGeneration: {
        provider: "openai",
        model: "gpt-3.5-turbo"
      },
      deepAnalysis: {
        provider: "openai",
        model: "gpt-4"
      }
    };
    
    const savedSelection = localStorage.getItem(selectedModelsKey);
    return savedSelection ? JSON.parse(savedSelection) : defaultSelection;
  },

  // Salvar configurações de modelos selecionados
  saveSelectedModels: function(rapidGeneration, deepAnalysis) {
    const selectedModelsKey = "clareoia_selected_models";
    const selection = {
      rapidGeneration,
      deepAnalysis
    };
    
    localStorage.setItem(selectedModelsKey, JSON.stringify(selection));
    return true;
  }
};

// Exportar API
window.IntegrationsAPI = IntegrationsAPI;
