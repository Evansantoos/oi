// Gerenciamento de webhooks para integração com sistemas externos
// Implementação de múltiplos webhooks com gatilhos distintos

// Chaves para armazenamento no localStorage
const DB_WEBHOOKS_KEY = "clareoia_webhooks";

// Inicializar banco de dados de webhooks
function initializeWebhooksDB() {
  // Inicializar webhooks se não existir
  if (!localStorage.getItem(DB_WEBHOOKS_KEY)) {
    localStorage.setItem(DB_WEBHOOKS_KEY, JSON.stringify([]));
  }
}

// API de Webhooks
const WebhooksAPI = {
  // Obter todos os webhooks
  getAll: function() {
    initializeWebhooksDB();
    return JSON.parse(localStorage.getItem(DB_WEBHOOKS_KEY));
  },

  // Obter webhook por ID
  getById: function(id) {
    const webhooks = this.getAll();
    return webhooks.find(webhook => webhook.id === id);
  },

  // Obter webhooks por evento
  getByEvent: function(eventType) {
    const webhooks = this.getAll();
    return webhooks.filter(webhook => webhook.eventType === eventType && webhook.active);
  },

  // Criar novo webhook
  create: function(webhookData) {
    const webhooks = this.getAll();
    const id = 'wh_' + Math.random().toString(36).substring(2, 9);
    
    const newWebhook = {
      id: id,
      name: webhookData.name,
      url: webhookData.url,
      eventType: webhookData.eventType,
      headers: webhookData.headers || {},
      method: webhookData.method || 'POST',
      active: webhookData.active !== undefined ? webhookData.active : true,
      createdAt: new Date().toISOString(),
      lastTriggered: null,
      successCount: 0,
      failureCount: 0
    };
    
    webhooks.push(newWebhook);
    localStorage.setItem(DB_WEBHOOKS_KEY, JSON.stringify(webhooks));
    
    return newWebhook;
  },

  // Atualizar webhook existente
  update: function(id, webhookData) {
    const webhooks = this.getAll();
    const index = webhooks.findIndex(webhook => webhook.id === id);
    
    if (index === -1) {
      return null;
    }
    
    webhooks[index] = {
      ...webhooks[index],
      ...webhookData,
      updatedAt: new Date().toISOString()
    };
    
    localStorage.setItem(DB_WEBHOOKS_KEY, JSON.stringify(webhooks));
    return webhooks[index];
  },

  // Excluir webhook
  delete: function(id) {
    const webhooks = this.getAll();
    const filteredWebhooks = webhooks.filter(webhook => webhook.id !== id);
    
    if (filteredWebhooks.length === webhooks.length) {
      return false;
    }
    
    localStorage.setItem(DB_WEBHOOKS_KEY, JSON.stringify(filteredWebhooks));
    return true;
  },

  // Ativar/desativar webhook
  toggleActive: function(id) {
    const webhooks = this.getAll();
    const index = webhooks.findIndex(webhook => webhook.id === id);
    
    if (index === -1) {
      return null;
    }
    
    webhooks[index].active = !webhooks[index].active;
    localStorage.setItem(DB_WEBHOOKS_KEY, JSON.stringify(webhooks));
    
    return webhooks[index];
  },

  // Disparar webhook para um evento específico
  trigger: async function(eventType, payload) {
    const webhooks = this.getByEvent(eventType);
    const results = [];
    
    for (const webhook of webhooks) {
      try {
        // Em produção, isso seria feito pelo backend para proteger chaves de API
        // Esta é uma simulação para fins de demonstração
        const response = await fetch(webhook.url, {
          method: webhook.method,
          headers: {
            'Content-Type': 'application/json',
            ...webhook.headers
          },
          body: JSON.stringify({
            event: eventType,
            timestamp: new Date().toISOString(),
            data: payload
          })
        });
        
        const success = response.ok;
        const responseData = await response.json();
        
        // Atualizar estatísticas do webhook
        this.update(webhook.id, {
          lastTriggered: new Date().toISOString(),
          successCount: success ? webhook.successCount + 1 : webhook.successCount,
          failureCount: !success ? webhook.failureCount + 1 : webhook.failureCount
        });
        
        results.push({
          webhookId: webhook.id,
          success,
          response: responseData
        });
      } catch (error) {
        // Atualizar estatísticas do webhook
        this.update(webhook.id, {
          lastTriggered: new Date().toISOString(),
          failureCount: webhook.failureCount + 1
        });
        
        results.push({
          webhookId: webhook.id,
          success: false,
          error: error.message
        });
      }
    }
    
    return results;
  },

  // Testar webhook
  test: async function(id) {
    const webhook = this.getById(id);
    
    if (!webhook) {
      return {
        success: false,
        error: 'Webhook não encontrado'
      };
    }
    
    try {
      // Em produção, isso seria feito pelo backend para proteger chaves de API
      // Esta é uma simulação para fins de demonstração
      const response = await fetch(webhook.url, {
        method: webhook.method,
        headers: {
          'Content-Type': 'application/json',
          ...webhook.headers
        },
        body: JSON.stringify({
          event: 'test',
          timestamp: new Date().toISOString(),
          data: {
            message: 'Este é um teste de webhook da ClareoIA'
          }
        })
      });
      
      const success = response.ok;
      let responseData;
      
      try {
        responseData = await response.json();
      } catch (e) {
        responseData = await response.text();
      }
      
      return {
        success,
        response: responseData
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Simular teste de webhook (para ambiente de desenvolvimento)
  simulateTest: function(id) {
    const webhook = this.getById(id);
    
    if (!webhook) {
      return {
        success: false,
        error: 'Webhook não encontrado'
      };
    }
    
    // Simulação de resposta bem-sucedida
    const success = Math.random() > 0.2; // 80% de chance de sucesso
    
    // Atualizar estatísticas do webhook
    this.update(webhook.id, {
      lastTriggered: new Date().toISOString(),
      successCount: success ? webhook.successCount + 1 : webhook.successCount,
      failureCount: !success ? webhook.failureCount + 1 : webhook.failureCount
    });
    
    return {
      success,
      response: success ? { status: 'ok', message: 'Webhook recebido com sucesso' } : { status: 'error', message: 'Erro ao processar webhook' }
    };
  }
};

// Exportar API
window.WebhooksAPI = WebhooksAPI;
