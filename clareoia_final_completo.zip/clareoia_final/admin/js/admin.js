// Funções para o painel administrativo
document.addEventListener("DOMContentLoaded", () => {
  // Variáveis globais
  let sidebarCollapsed = false

  // Inicialização
  initSidebar()
  initNavigation()
  initModals()
  initPasswordToggles()
  loadDashboardData()

  // Inicializar sidebar
  function initSidebar() {
    const toggleBtn = document.getElementById("toggle-sidebar")
    const sidebar = document.querySelector(".sidebar")
    const content = document.querySelector(".content")

    toggleBtn.addEventListener("click", () => {
      sidebarCollapsed = !sidebarCollapsed

      if (sidebarCollapsed) {
        sidebar.classList.add("collapsed")
        content.classList.add("expanded")
      } else {
        sidebar.classList.remove("collapsed")
        content.classList.remove("expanded")
      }
    })
  }

  // Inicializar navegação
  function initNavigation() {
    const navItems = document.querySelectorAll(".nav-item")
    const sectionTitle = document.getElementById("section-title")

    navItems.forEach((item) => {
      item.addEventListener("click", function () {
        // Remover classe active de todos os itens
        navItems.forEach((i) => i.classList.remove("active"))

        // Adicionar classe active ao item clicado
        this.classList.add("active")

        // Obter a seção correspondente
        const sectionId = this.getAttribute("data-section")
        const sectionElement = document.getElementById(`${sectionId}-section`)

        // Esconder todas as seções
        document.querySelectorAll(".content-section").forEach((section) => {
          section.classList.remove("active")
        })

        // Mostrar a seção correspondente
        if (sectionElement) {
          sectionElement.classList.add("active")
          sectionTitle.textContent = this.querySelector("span").textContent
        }
      })
    })

    // Inicializar links "Ver Todos"
    document.querySelectorAll(".view-all").forEach((link) => {
      link.addEventListener("click", function (e) {
        e.preventDefault()

        const sectionId = this.getAttribute("data-section")
        if (sectionId) {
          // Encontrar o item de navegação correspondente e clicar nele
          const navItem = document.querySelector(`.nav-item[data-section="${sectionId}"]`)
          if (navItem) {
            navItem.click()
          }
        }
      })
    })
  }

  // Inicializar modais
  function initModals() {
    // Abrir modal de detalhes do usuário
    document.querySelectorAll(".view-user-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const userId = this.getAttribute("data-user-id")
        openUserDetailsModal(userId)
      })
    })

    // Abrir modal de upload de conhecimento
    document.getElementById("upload-knowledge-btn").addEventListener("click", () => {
      document.getElementById("upload-knowledge-modal").style.display = "block"
    })

    // Abrir modal de adicionar plano
    document.getElementById("add-plan-btn").addEventListener("click", () => {
      document.getElementById("add-plan-modal").style.display = "block"
    })

    // Fechar modais
    document.querySelectorAll(".close-modal").forEach((closeBtn) => {
      closeBtn.addEventListener("click", function () {
        this.closest(".modal").style.display = "none"
      })
    })

    // Fechar modal ao clicar fora
    window.addEventListener("click", (event) => {
      document.querySelectorAll(".modal").forEach((modal) => {
        if (event.target === modal) {
          modal.style.display = "none"
        }
      })
    })

    // Botões de cancelar
    document.getElementById("cancel-upload-btn").addEventListener("click", () => {
      document.getElementById("upload-knowledge-modal").style.display = "none"
    })

    document.getElementById("cancel-plan-btn").addEventListener("click", () => {
      document.getElementById("add-plan-modal").style.display = "none"
    })
  }

  // Inicializar toggles de senha
  function initPasswordToggles() {
    document.querySelectorAll(".toggle-password-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const targetId = this.getAttribute("data-target")
        const inputElement = document.getElementById(targetId)

        if (inputElement.type === "password") {
          inputElement.type = "text"
          this.innerHTML = '<i class="fas fa-eye-slash"></i>'
        } else {
          inputElement.type = "password"
          this.innerHTML = '<i class="fas fa-eye"></i>'
        }
      })
    })
  }

  // Carregar dados do dashboard
  function loadDashboardData() {
    // Simulação de dados para demonstração
    document.getElementById("total-users").textContent = "127"
    document.getElementById("total-tests").textContent = "438"
    document.getElementById("premium-users").textContent = "42"
    document.getElementById("total-360").textContent = "18"

    // Carregar usuários recentes
    const recentUsersTable = document.getElementById("recent-users-table")
    recentUsersTable.innerHTML = `
            <tr>
                <td>João Silva</td>
                <td>joao.silva@exemplo.com</td>
                <td>17/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Maria Oliveira</td>
                <td>maria.oliveira@exemplo.com</td>
                <td>16/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Carlos Santos</td>
                <td>carlos.santos@exemplo.com</td>
                <td>15/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Ana Pereira</td>
                <td>ana.pereira@exemplo.com</td>
                <td>15/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
            <tr>
                <td>Roberto Almeida</td>
                <td>roberto.almeida@exemplo.com</td>
                <td>14/05/2025</td>
                <td><span class="badge badge-success">Ativo</span></td>
            </tr>
        `

    // Carregar testes recentes
    const recentTestsTable = document.getElementById("recent-tests-table")
    recentTestsTable.innerHTML = `
            <tr>
                <td>João Silva</td>
                <td>DISC</td>
                <td>Verdade</td>
                <td>17/05/2025</td>
            </tr>
            <tr>
                <td>Maria Oliveira</td>
                <td>Temperamento</td>
                <td>Clareza</td>
                <td>16/05/2025</td>
            </tr>
            <tr>
                <td>Carlos Santos</td>
                <td>Perfil Animal</td>
                <td>Verdade</td>
                <td>15/05/2025</td>
            </tr>
            <tr>
                <td>Ana Pereira</td>
                <td>DISC</td>
                <td>Essência</td>
                <td>15/05/2025</td>
            </tr>
            <tr>
                <td>Roberto Almeida</td>
                <td>Emoções</td>
                <td>Clareza</td>
                <td>14/05/2025</td>
            </tr>
        `

    // Inicializar lista de usuários
    initUsersList()

    // Inicializar lista de prompts
    initPromptsList()

    // Inicializar lista de arquivos de conhecimento
    initKnowledgeList()

    // Atualizar lista de prompts
    updatePromptsList()
  }

  // Inicializar lista de usuários
  function initUsersList() {
    const usersTable = document.getElementById("users-table")
    usersTable.innerHTML = `
            <tr>
                <td>João Silva</td>
                <td>joao.silva@exemplo.com</td>
                <td>(11) 98765-4321</td>
                <td>DISC, Temperamento, Perfil Animal</td>
                <td>17/05/2025 14:30</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="1">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Maria Oliveira</td>
                <td>maria.oliveira@exemplo.com</td>
                <td>(21) 98765-4321</td>
                <td>DISC, Temperamento</td>
                <td>16/05/2025 10:15</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="2">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Carlos Santos</td>
                <td>carlos.santos@exemplo.com</td>
                <td>(31) 98765-4321</td>
                <td>DISC, Perfil Animal</td>
                <td>15/05/2025 16:45</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="3">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Ana Pereira</td>
                <td>ana.pereira@exemplo.com</td>
                <td>(41) 98765-4321</td>
                <td>DISC</td>
                <td>15/05/2025 09:20</td>
                <td><span class="badge badge-secondary">Gratuito</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="4">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
            <tr>
                <td>Roberto Almeida</td>
                <td>roberto.almeida@exemplo.com</td>
                <td>(51) 98765-4321</td>
                <td>DISC, Emoções</td>
                <td>14/05/2025 11:30</td>
                <td><span class="badge badge-success">Premium</span></td>
                <td>
                    <button class="btn btn-sm btn-outline view-user-btn" data-user-id="5">
                        <i class="fas fa-eye"></i> Ver
                    </button>
                </td>
            </tr>
        `

    // Adicionar evento aos botões de visualização
    document.querySelectorAll(".view-user-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const userId = this.getAttribute("data-user-id")
        openUserDetailsModal(userId)
      })
    })
  }

  // Inicializar lista de prompts
  function initPromptsList() {
    const promptsList = document.getElementById("prompts-list")
    const promptItems = promptsList.querySelectorAll(".prompt-item")

    promptItems.forEach((item) => {
      item.addEventListener("click", function () {
        // Remover classe active de todos os itens
        promptItems.forEach((i) => i.classList.remove("active"))

        // Adicionar classe active ao item clicado
        this.classList.add("active")

        // Obter o tipo de teste
        const testType = this.getAttribute("data-test")

        // Atualizar título do prompt
        document.getElementById("current-prompt-title").textContent =
          `Prompt para ${this.querySelector("h4").textContent}`

        // Carregar conteúdo do prompt (simulado)
        loadPromptContent(testType)
      })
    })

    // Inicializar controle de temperatura
    const temperatureSlider = document.getElementById("prompt-temperature")
    const temperatureValue = document.getElementById("temperature-value")

    temperatureSlider.addEventListener("input", function () {
      temperatureValue.textContent = this.value
    })

    // Botões de salvar e testar prompt
    document.getElementById("save-prompt-btn").addEventListener("click", () => {
      alert("Prompt salvo com sucesso!")
    })

    document.getElementById("test-prompt-btn").addEventListener("click", () => {
      alert("Teste de prompt iniciado. Isso pode levar alguns segundos...")
    })
  }

  // Inicializar modais de adicionar prompt e treinamento
  function initAddPromptModal() {
    const addPromptBtn = document.getElementById("add-prompt-btn")
    const addPromptModal = document.getElementById("add-prompt-modal")
    const cancelNewPromptBtn = document.getElementById("cancel-new-prompt-btn")
    const saveNewPromptBtn = document.getElementById("save-new-prompt-btn")
    const newPromptTemperature = document.getElementById("new-prompt-temperature")
    const newTemperatureValue = document.getElementById("new-temperature-value")

    if (addPromptBtn && addPromptModal) {
      // Abrir modal
      addPromptBtn.addEventListener("click", () => {
        addPromptModal.style.display = "block"
      })

      // Fechar modal
      if (cancelNewPromptBtn) {
        cancelNewPromptBtn.addEventListener("click", () => {
          addPromptModal.style.display = "none"
        })
      }

      // Atualizar valor da temperatura
      if (newPromptTemperature && newTemperatureValue) {
        newPromptTemperature.addEventListener("input", function () {
          newTemperatureValue.textContent = this.value
        })
      }

      // Salvar novo prompt
      if (saveNewPromptBtn) {
        saveNewPromptBtn.addEventListener("click", () => {
          const name = document.getElementById("new-prompt-name").value
          const type = document.getElementById("new-prompt-type").value
          const text = document.getElementById("new-prompt-text").value
          const model = document.getElementById("new-prompt-model").value
          const temperature = document.getElementById("new-prompt-temperature").value

          if (!name || !text) {
            alert("Por favor, preencha todos os campos obrigatórios.")
            return
          }

          // Salvar prompt (simulação)
          savePrompt({
            id: generateUUID(),
            name: name,
            type: type,
            text: text,
            model: model,
            temperature: temperature,
            created_at: new Date().toISOString(),
          })

          // Fechar modal
          addPromptModal.style.display = "none"

          // Atualizar lista de prompts
          updatePromptsList()

          // Mostrar notificação
          alert("Prompt adicionado com sucesso!")
        })
      }
    }
  }

  // Inicializar modal de adicionar treinamento
  function initAddTrainingModal() {
    const addTrainingBtn = document.getElementById("add-training-btn")
    const addTrainingModal = document.getElementById("add-training-modal")
    const cancelTrainingBtn = document.getElementById("cancel-training-btn")
    const saveTrainingBtn = document.getElementById("save-training-btn")

    if (addTrainingBtn && addTrainingModal) {
      // Abrir modal
      addTrainingBtn.addEventListener("click", () => {
        addTrainingModal.style.display = "block"
      })

      // Fechar modal
      if (cancelTrainingBtn) {
        cancelTrainingBtn.addEventListener("click", () => {
          addTrainingModal.style.display = "none"
        })
      }

      // Salvar novo treinamento
      if (saveTrainingBtn) {
        saveTrainingBtn.addEventListener("click", () => {
          const name = document.getElementById("training-name").value
          const description = document.getElementById("training-description").value
          const category = document.getElementById("training-category").value
          const level = document.getElementById("training-level").value
          const content = document.getElementById("training-content").value

          if (!name || !description || !content) {
            alert("Por favor, preencha todos os campos obrigatórios.")
            return
          }

          // Salvar treinamento (simulação)
          saveTraining({
            id: generateUUID(),
            name: name,
            description: description,
            category: category,
            level: level,
            content: content,
            created_at: new Date().toISOString(),
          })

          // Fechar modal
          addTrainingModal.style.display = "none"

          // Mostrar notificação
          alert("Treinamento adicionado com sucesso!")
        })
      }
    }
  }

  // Função para salvar prompt
  function savePrompt(prompt) {
    // Em produção, enviar para API
    // Aqui, salvamos no localStorage para simulação
    const prompts = JSON.parse(localStorage.getItem("prompts") || "[]")
    prompts.push(prompt)
    localStorage.setItem("prompts", JSON.stringify(prompts))

    // Sincronizar com painel do usuário
    syncDataWithUserPanel()
  }

  // Função para salvar treinamento
  function saveTraining(training) {
    // Em produção, enviar para API
    // Aqui, salvamos no localStorage para simulação
    const trainings = JSON.parse(localStorage.getItem("trainings") || "[]")
    trainings.push(training)
    localStorage.setItem("trainings", JSON.stringify(trainings))

    // Sincronizar com painel do usuário
    syncDataWithUserPanel()
  }

  // Função para atualizar lista de prompts
  function updatePromptsList() {
    const promptsList = document.getElementById("prompts-list")
    if (!promptsList) return

    // Obter prompts
    const prompts = JSON.parse(localStorage.getItem("prompts") || "[]")

    // Limpar lista
    promptsList.innerHTML = ""

    // Adicionar prompts à lista
    prompts.forEach((prompt, index) => {
      const promptItem = document.createElement("div")
      promptItem.className = "prompt-item" + (index === 0 ? " active" : "")
      promptItem.setAttribute("data-test", prompt.type)
      promptItem.innerHTML = `
      <div class="prompt-icon">
        <i class="fas ${getPromptIcon(prompt.type)}"></i>
      </div>
      <div class="prompt-info">
        <h4>${prompt.name}</h4>
        <p>Prompt para ${getPromptTypeName(prompt.type)}</p>
      </div>
    `

      // Adicionar evento de clique
      promptItem.addEventListener("click", function () {
        // Remover classe active de todos os itens
        document.querySelectorAll(".prompt-item").forEach((item) => {
          item.classList.remove("active")
        })

        // Adicionar classe active ao item clicado
        this.classList.add("active")

        // Carregar conteúdo do prompt
        loadPromptContent(prompt.type, prompt)
      })

      promptsList.appendChild(promptItem)
    })
  }

  // Função para obter ícone do prompt
  function getPromptIcon(type) {
    switch (type) {
      case "disc":
        return "fa-chart-pie"
      case "temperamento":
        return "fa-brain"
      case "personalidade":
        return "fa-user"
      case "animal":
        return "fa-paw"
      case "emocoes":
        return "fa-heart"
      case "analise360":
        return "fa-sync-alt"
      default:
        return "fa-file-alt"
    }
  }

  // Função para obter nome do tipo de prompt
  function getPromptTypeName(type) {
    switch (type) {
      case "disc":
        return "DISC"
      case "temperamento":
        return "Temperamento"
      case "personalidade":
        return "Personalidade"
      case "animal":
        return "Perfil Animal"
      case "emocoes":
        return "Emoções"
      case "analise360":
        return "Análise 360°"
      default:
        return type
    }
  }

  // Função para sincronizar dados com o painel do usuário
  function syncDataWithUserPanel() {
    // Em produção, isso seria feito via API
    // Aqui, como estamos usando localStorage, já está sincronizado
    console.log("Dados sincronizados com o painel do usuário")
  }

  // Inicializar gerenciamento de webhooks
  const initWebhooksManagement = () => {
    const addWebhookBtn = document.getElementById("add-webhook-btn")
    const webhookModal = document.getElementById("webhook-modal")
    const closeModal = webhookModal.querySelector(".close-modal")
    const saveWebhookBtn = document.getElementById("save-webhook-btn")
    const testWebhookBtn = document.getElementById("test-webhook-modal-btn")
    const deleteWebhookBtn = document.getElementById("delete-webhook-btn")

    // Carregar webhooks existentes
    loadWebhooks()

    // Evento para abrir modal de adicionar webhook
    if (addWebhookBtn) {
      addWebhookBtn.addEventListener("click", () => {
        openWebhookModal()
      })
    }

    // Evento para fechar modal
    if (closeModal) {
      closeModal.addEventListener("click", () => {
        webhookModal.style.display = "none"
      })
    }

    // Evento para salvar webhook
    if (saveWebhookBtn) {
      saveWebhookBtn.addEventListener("click", () => {
        saveWebhook()
      })
    }

    // Evento para testar webhook
    if (testWebhookBtn) {
      testWebhookBtn.addEventListener("click", () => {
        testWebhook()
      })
    }

    // Evento para excluir webhook
    if (deleteWebhookBtn) {
      deleteWebhookBtn.addEventListener("click", () => {
        deleteWebhook()
      })
    }
  }

  // Função para carregar webhooks
  const loadWebhooks = () => {
    const webhooksList = document.getElementById("webhooks-list")
    const noWebhooksMessage = document.getElementById("no-webhooks-message")

    if (!webhooksList) return

    // Obter webhooks salvos
    const webhooks = JSON.parse(localStorage.getItem("webhooks") || "[]")

    // Limpar lista
    webhooksList.innerHTML = ""

    // Verificar se há webhooks
    if (webhooks.length === 0) {
      if (noWebhooksMessage) {
        webhooksList.appendChild(noWebhooksMessage)
      } else {
        const message = document.createElement("p")
        message.id = "no-webhooks-message"
        message.textContent = "Nenhum webhook configurado. Adicione um novo webhook."
        webhooksList.appendChild(message)
      }
      return
    }

    // Adicionar webhooks à lista
    webhooks.forEach((webhook) => {
      const webhookItem = document.createElement("div")
      webhookItem.className = `webhook-item ${webhook.status}`
      webhookItem.setAttribute("data-id", webhook.id)

      webhookItem.innerHTML = `
      <div class="webhook-info">
        <h4>${webhook.name}</h4>
        <p class="webhook-url">${webhook.url}</p>
        <div class="webhook-events">
          ${webhook.events.map((event) => `<span class="webhook-event">${getEventName(event)}</span>`).join("")}
        </div>
      </div>
      <div class="webhook-actions">
        <button class="btn btn-sm btn-outline edit-webhook-btn">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn btn-sm btn-outline test-webhook-btn">
          <i class="fas fa-play"></i>
        </button>
      </div>
    `

      // Adicionar evento de edição
      const editBtn = webhookItem.querySelector(".edit-webhook-btn")
      if (editBtn) {
        editBtn.addEventListener("click", () => {
          openWebhookModal(webhook.id)
        })
      }

      // Adicionar evento de teste
      const testBtn = webhookItem.querySelector(".test-webhook-btn")
      if (testBtn) {
        testBtn.addEventListener("click", () => {
          testWebhookById(webhook.id)
        })
      }

      webhooksList.appendChild(webhookItem)
    })

    // Atualizar status geral
    updateWebhooksStatus(webhooks)
  }

  // Função para obter nome do evento
  const getEventName = (eventCode) => {
    switch (eventCode) {
      case "user_register":
        return "Cadastro de Usuário"
      case "test_complete":
        return "Teste Concluído"
      case "analysis_360":
        return "Análise 360°"
      case "plan_purchase":
        return "Compra de Plano"
      default:
        return eventCode
    }
  }

  // Função para atualizar status geral dos webhooks
  function updateWebhooksStatus(webhooks) {
    const statusElement = document.getElementById("webhook-status")
    if (!statusElement) return

    if (webhooks.length === 0) {
      statusElement.className = "integration-status inactive"
      statusElement.querySelector("span").textContent = "Não configurado"
      return
    }

    const activeWebhooks = webhooks.filter((webhook) => webhook.status === "active")

    if (activeWebhooks.length === 0) {
      statusElement.className = "integration-status inactive"
      statusElement.querySelector("span").textContent = "Inativo"
    } else {
      statusElement.className = "integration-status active"
      statusElement.querySelector("span").textContent =
        `${activeWebhooks.length} Ativo${activeWebhooks.length > 1 ? "s" : ""}`
    }
  }

  // Função para abrir modal de webhook
  function openWebhookModal(webhookId = null) {
    const modal = document.getElementById("webhook-modal")
    const modalTitle = document.getElementById("webhook-modal-title")
    const nameInput = document.getElementById("webhook-name")
    const urlInput = document.getElementById("webhook-url")
    const secretInput = document.getElementById("webhook-secret")
    const statusSelect = document.getElementById("webhook-status-select")
    const eventsCheckboxes = document.querySelectorAll(".webhook-events input[type='checkbox']")
    const saveButton = document.getElementById("save-webhook-btn")
    const deleteButton = document.getElementById("delete-webhook-btn")

    // Limpar campos
    nameInput.value = ""
    urlInput.value = ""
    secretInput.value = ""
    statusSelect.value = "active"
    eventsCheckboxes.forEach((checkbox) => (checkbox.checked = false))

    // Esconder botão de excluir
    deleteButton.style.display = "none"

    // Se for edição, carregar dados
    if (webhookId) {
      modalTitle.textContent = "Editar Webhook"
      deleteButton.style.display = "inline-block"

      const webhooks = JSON.parse(localStorage.getItem("webhooks") || "[]")
      const webhook = webhooks.find((w) => w.id === webhookId)

      if (webhook) {
        nameInput.value = webhook.name
        urlInput.value = webhook.url
        secretInput.value = webhook.secret || ""
        statusSelect.value = webhook.status
        webhook.events.forEach((event) => {
          const checkbox = document.querySelector(`.webhook-events input[type='checkbox'][value='${event}']`)
          if (checkbox) checkbox.checked = true
        })

        // Definir atributo de data para exclusão
        deleteButton.setAttribute("data-id", webhookId)
      }
    } else {
      modalTitle.textContent = "Adicionar Webhook"
      deleteButton.removeAttribute("data-id")
    }

    // Mostrar modal
    modal.style.display = "block"
  }

  // Função para salvar webhook
  function saveWebhook() {
    const modal = document.getElementById("webhook-modal")
    const name = document.getElementById("webhook-name").value.trim()
    const url = document.getElementById("webhook-url").value.trim()
    const secret = document.getElementById("webhook-secret").value.trim()
    const status = document.getElementById("webhook-status-select").value
    const events = Array.from(document.querySelectorAll(".webhook-events input[type='checkbox']:checked")).map(
      (checkbox) => checkbox.value,
    )
    const webhookId = document.getElementById("delete-webhook-btn").getAttribute("data-id")

    if (!name || !url || events.length === 0) {
      alert("Por favor, preencha todos os campos obrigatórios.")
      return
    }

    // Obter webhooks existentes
    const webhooks = JSON.parse(localStorage.getItem("webhooks") || "[]")

    // Se for edição, atualizar
    if (webhookId) {
      const index = webhooks.findIndex((w) => w.id === webhookId)
      if (index !== -1) {
        webhooks[index] = {
          id: webhookId,
          name: name,
          url: url,
          secret: secret,
          status: status,
          events: events,
        }
      }
    } else {
      // Criar novo webhook
      const newWebhook = {
        id: generateUUID(),
        name: name,
        url: url,
        secret: secret,
        status: status,
        events: events,
      }
      webhooks.push(newWebhook)
    }

    // Salvar webhooks
    localStorage.setItem("webhooks", JSON.stringify(webhooks))

    // Fechar modal
    modal.style.display = "none"

    // Atualizar lista
    loadWebhooks()

    // Mostrar notificação
    alert("Webhook salvo com sucesso!")
  }

  // Função para testar webhook
  function testWebhook() {
    const webhookUrl = document.getElementById("webhook-url").value.trim()

    if (!webhookUrl) {
      alert("Por favor, insira a URL do webhook.")
      return
    }

    // Simular envio de requisição
    simulateWebhookRequest(webhookUrl)
      .then((response) => {
        alert(`Teste enviado para ${webhookUrl}. Resposta: ${response}`)
      })
      .catch((error) => {
        alert(`Erro ao enviar teste para ${webhookUrl}: ${error.message}`)
      })
  }

  // Função para testar webhook por ID
  function testWebhookById(webhookId) {
    const webhooks = JSON.parse(localStorage.getItem("webhooks") || "[]")
    const webhook = webhooks.find((w) => w.id === webhookId)

    if (!webhook) {
      alert("Webhook não encontrado.")
      return
    }

    // Simular envio de requisição
    simulateWebhookRequest(webhook.url)
      .then((response) => {
        alert(`Teste enviado para ${webhook.url}. Resposta: ${response}`)
      })
      .catch((error) => {
        alert(`Erro ao enviar teste para ${webhook.url}: ${error.message}`)
      })
  }

  // Função para simular requisição para webhook
  async function simulateWebhookRequest(url) {
    // Em produção, usar fetch ou XMLHttpRequest para enviar a requisição
    // Aqui, simulamos a resposta
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve("Sucesso")
      }, 1000)
    })
  }

  // Função para excluir webhook
  function deleteWebhook() {
    const webhookId = document.getElementById("delete-webhook-btn").getAttribute("data-id")
    const modal = document.getElementById("webhook-modal")

    if (!webhookId) {
      alert("Webhook não encontrado.")
      return
    }

    if (!confirm("Tem certeza que deseja excluir este webhook?")) {
      return
    }

    // Obter webhooks existentes
    const webhooks = JSON.parse(localStorage.getItem("webhooks") || "[]")

    // Filtrar webhooks
    const updatedWebhooks = webhooks.filter((w) => w.id !== webhookId)

    // Salvar webhooks
    localStorage.setItem("webhooks", JSON.stringify(updatedWebhooks))

    // Fechar modal
    modal.style.display = "none"

    // Atualizar lista
    loadWebhooks()

    // Mostrar notificação
    alert("Webhook excluído com sucesso!")
  }

  // Inicializar integrações
  function initIntegrations() {
    // OpenAI
    initOpenAIIntegration()

    // DeepSeek
    initDeepSeekIntegration()

    // GROK
    initGrokIntegration()

    // Evolution API
    initEvolutionAPIIntegration()

    // zAPI
    initZAPIIntegration()
  }

  // Inicializar integração com OpenAI
  function initOpenAIIntegration() {
    const apiKeyInput = document.getElementById("openai-api-key")
    const testButton = document.getElementById("test-openai-btn")
    const saveButton = document.getElementById("save-openai-btn")
    const statusElement = document.getElementById("openai-status")
    const defaultModelSelect = document.getElementById("openai-model-default")
    const advancedModelSelect = document.getElementById("openai-model-advanced")

    // Carregar configuração salva
    const savedConfig = JSON.parse(localStorage.getItem("openai_config") || "{}")
    if (savedConfig.apiKey) {
      apiKeyInput.value = savedConfig.apiKey
      updateOpenAIStatus("active", "Ativo")

      // Carregar modelos
      loadOpenAIModels(savedConfig.apiKey, defaultModelSelect, advancedModelSelect)

      // Definir modelos selecionados
      if (savedConfig.defaultModel) {
        defaultModelSelect.value = savedConfig.defaultModel
      }

      if (savedConfig.advancedModel) {
        advancedModelSelect.value = savedConfig.advancedModel
      }
    }

    // Evento de teste de conexão
    if (testButton) {
      testButton.addEventListener("click", () => {
        const apiKey = apiKeyInput.value.trim()

        if (!apiKey) {
          alert("Por favor, insira uma API Key.")
          return
        }

        // Atualizar status para "Testando..."
        updateOpenAIStatus("testing", "Testando...")

        // Testar conexão (simulação)
        testOpenAIConnection(apiKey)
          .then((success) => {
            if (success) {
              updateOpenAIStatus("active", "Ativo")

              // Carregar modelos disponíveis
              loadOpenAIModels(apiKey, defaultModelSelect, advancedModelSelect)

              alert("Conexão com OpenAI estabelecida com sucesso!")
            } else {
              updateOpenAIStatus("inactive", "Inativo")
              alert("Falha ao conectar com OpenAI. Verifique sua API Key.")
            }
          })
          .catch((error) => {
            updateOpenAIStatus("inactive", "Inativo")
            alert("Erro ao testar conexão: " + error.message)
          })
      })
    }

    // Evento de salvar configuração
    if (saveButton) {
      saveButton.addEventListener("click", () => {
        const apiKey = apiKeyInput.value.trim()
        const defaultModel = defaultModelSelect.value
        const advancedModel = advancedModelSelect.value

        if (!apiKey) {
          alert("Por favor, insira uma API Key.")
          return
        }

        if (!defaultModel || !advancedModel) {
          alert("Por favor, selecione os modelos.")
          return
        }

        // Salvar configuração
        const config = {
          apiKey: apiKey,
          defaultModel: defaultModel,
          advancedModel: advancedModel,
        }

        localStorage.setItem("openai_config", JSON.stringify(config))

        alert("Configuração da OpenAI salva com sucesso!")
      })
    }
  }

  // Função para testar conexão com OpenAI
  async function testOpenAIConnection(apiKey) {
    // Em produção, fazer uma requisição real para a API da OpenAI
    // Aqui, simulamos o teste
    return new Promise((resolve) => {
      setTimeout(() => {
        // Simular sucesso se a chave começar com "sk-"
        const success = apiKey.startsWith("sk-")
        resolve(success)
      }, 1500)
    })
  }

  // Função para carregar modelos da OpenAI
  async function loadOpenAIModels(apiKey, defaultSelect, advancedSelect) {
    // Em produção, fazer uma requisição real para a API da OpenAI
    // Aqui, simulamos a lista de modelos

    // Habilitar selects
    defaultSelect.disabled = false
    advancedSelect.disabled = false

    // Limpar selects
    defaultSelect.innerHTML = ""
    advancedSelect.innerHTML = ""

    // Adicionar modelos
    const models = [
      { id: "gpt-3.5-turbo", name: "GPT-3.5 Turbo" },
      { id: "gpt-3.5-turbo-16k", name: "GPT-3.5 Turbo (16K)" },
      { id: "gpt-4", name: "GPT-4" },
      { id: "gpt-4-turbo", name: "GPT-4 Turbo" },
      { id: "gpt-4-vision", name: "GPT-4 Vision" },
      { id: "gpt-4o", name: "GPT-4o" },
    ]

    models.forEach((model) => {
      const defaultOption = document.createElement("option")
      defaultOption.value = model.id
      defaultOption.textContent = model.name
      defaultSelect.appendChild(defaultOption)

      const advancedOption = document.createElement("option")
      advancedOption.value = model.id
      advancedOption.textContent = model.name
      advancedSelect.appendChild(advancedOption)
    })

    // Selecionar modelos padrão
    defaultSelect.value = "gpt-3.5-turbo"
    advancedSelect.value = "gpt-4"
  }

  // Função para atualizar status da OpenAI
  function updateOpenAIStatus(status, text) {
    const statusElement = document.getElementById("openai-status")
    if (statusElement) {
      statusElement.className = `integration-status ${status}`
      statusElement.querySelector("span").textContent = text
    }
  }

  // Inicializar integração com DeepSeek
  function initDeepSeekIntegration() {
    const apiKeyInput = document.getElementById("deepseek-api-key")
    const testButton = document.getElementById("test-deepseek-btn")
    const saveButton = document.getElementById("save-deepseek-btn")
    const statusElement = document.getElementById("deepseek-status")
    const modelSelect = document.getElementById("deepseek-model")

    // Carregar configuração salva
    const savedConfig = JSON.parse(localStorage.getItem("deepseek_config") || "{}")
    if (savedConfig.apiKey) {
      apiKeyInput.value = savedConfig.apiKey
      updateDeepSeekStatus("active", "Ativo")

      // Carregar modelos
      loadDeepSeekModels(savedConfig.apiKey, modelSelect)

      // Definir modelo selecionado
      if (savedConfig.model) {
        modelSelect.value = savedConfig.model
      }
    }

    // Evento de teste de conexão
    if (testButton) {
      testButton.addEventListener("click", () => {
        const apiKey = apiKeyInput.value.trim()

        if (!apiKey) {
          alert("Por favor, insira uma API Key.")
          return
        }

        // Atualizar status para "Testando..."
        updateDeepSeekStatus("testing", "Testando...")

        // Testar conexão (simulação)
        testDeepSeekConnection(apiKey)
          .then((success) => {
            if (success) {
              updateDeepSeekStatus("active", "Ativo")

              // Carregar modelos disponíveis
              loadDeepSeekModels(apiKey, modelSelect)

              alert("Conexão com DeepSeek estabelecida com sucesso!")
            } else {
              updateDeepSeekStatus("inactive", "Inativo")
              alert("Falha ao conectar com DeepSeek. Verifique sua API Key.")
            }
          })
          .catch((error) => {
            updateDeepSeekStatus("inactive", "Inativo")
            alert("Erro ao testar conexão: " + error.message)
          })
      })
    }

    // Evento de salvar configuração
    if (saveButton) {
      saveButton.addEventListener("click", () => {
        const apiKey = apiKeyInput.value.trim()
        const model = modelSelect.value

        if (!apiKey) {
          alert("Por favor, insira uma API Key.")
          return
        }

        if (!model) {
          alert("Por favor, selecione um modelo.")
          return
        }

        // Salvar configuração
        const config = {
          apiKey: apiKey,
          model: model,
        }

        localStorage.setItem("deepseek_config", JSON.stringify(config))

        alert("Configuração da DeepSeek salva com sucesso!")
      })
    }
  }

  // Função para testar conexão com DeepSeek
  async function testDeepSeekConnection(apiKey) {
    // Simulação
    return new Promise((resolve) => {
      setTimeout(() => {
        const success = apiKey.length > 10
        resolve(success)
      }, 1500)
    })
  }

  // Função para carregar modelos da DeepSeek
  async function loadDeepSeekModels(apiKey, select) {
    // Habilitar select
    select.disabled = false

    // Limpar select
    select.innerHTML = ""

    // Adicionar modelos
    const models = [
      { id: "deepseek-chat", name: "DeepSeek Chat" },
      { id: "deepseek-coder", name: "DeepSeek Coder" },
      { id: "deepseek-lite", name: "DeepSeek Lite" },
    ]

    models.forEach((model) => {
      const option = document.createElement("option")
      option.value = model.id
      option.textContent = model.name
      select.appendChild(option)
    })

    // Selecionar modelo padrão
    select.value = "deepseek-chat"
  }

  // Função para atualizar status da DeepSeek
  function updateDeepSeekStatus(status, text) {
    const statusElement = document.getElementById("deepseek-status")
    if (statusElement) {
      statusElement.className = `integration-status ${status}`
      statusElement.querySelector("span").textContent = text
    }
  }

  // Inicializar integração com GROK
  function initGrokIntegration() {
    const apiKeyInput = document.getElementById("grok-api-key")
    const testButton = document.getElementById("test-grok-btn")
    const saveButton = document.getElementById("save-grok-btn")
    const statusElement = document.getElementById("grok-status")
    const modelSelect = document.getElementById("grok-model")

    // Carregar configuração salva
    const savedConfig = JSON.parse(localStorage.getItem("grok_config") || "{}")
    if (savedConfig.apiKey) {
      apiKeyInput.value = savedConfig.apiKey
      updateGrokStatus("active", "Ativo")

      // Carregar modelos
      loadGrokModels(savedConfig.apiKey, modelSelect)

      // Definir modelo selecionado
      if (savedConfig.model) {
        modelSelect.value = savedConfig.model
      }
    }

    // Evento de teste de conexão
    if (testButton) {
      testButton.addEventListener("click", () => {
        const apiKey = apiKeyInput.value.trim()

        if (!apiKey) {
          alert("Por favor, insira uma API Key.")
          return
        }

        // Atualizar status para "Testando..."
        updateGrokStatus("testing", "Testando...")

        // Testar conexão (simulação)
        testGrokConnection(apiKey)
          .then((success) => {
            if (success) {
              updateGrokStatus("active", "Ativo")

              // Carregar modelos disponíveis
              loadGrokModels(apiKey, modelSelect)

              alert("Conexão com GROK estabelecida com sucesso!")
            } else {
              updateGrokStatus("inactive", "Inativo")
              alert("Falha ao conectar com GROK. Verifique sua API Key.")
            }
          })
          .catch((error) => {
            updateGrokStatus("inactive", "Inativo")
            alert("Erro ao testar conexão: " + error.message)
          })
      })
    }

    // Evento de salvar configuração
    if (saveButton) {
      saveButton.addEventListener("click", () => {
        const apiKey = apiKeyInput.value.trim()
        const model = modelSelect.value

        if (!apiKey) {
          alert("Por favor, insira uma API Key.")
          return
        }

        if (!model) {
          alert("Por favor, selecione um modelo.")
          return
        }

        // Salvar configuração
        const config = {
          apiKey: apiKey,
          model: model,
        }

        localStorage.setItem("grok_config", JSON.stringify(config))

        alert("Configuração da GROK salva com sucesso!")
      })
    }
  }

  // Função para testar conexão com GROK
  async function testGrokConnection(apiKey) {
    // Simulação
    return new Promise((resolve) => {
      setTimeout(() => {
        const success = apiKey.length > 10
        resolve(success)
      }, 1500)
    })
  }

  // Função para carregar modelos da GROK
  async function loadGrokModels(apiKey, select) {
    // Habilitar select
    select.disabled = false

    // Limpar select
    select.innerHTML = ""

    // Adicionar modelos
    const models = [
      { id: "grok-1", name: "Grok-1" },
      { id: "grok-1-mini", name: "Grok-1 Mini" },
    ]

    models.forEach((model) => {
      const option = document.createElement("option")
      option.value = model.id
      option.textContent = model.name
      select.appendChild(option)
    })

    // Selecionar modelo padrão
    select.value = "grok-1"
  }

  // Função para atualizar status da GROK
  function updateGrokStatus(status, text) {
    const statusElement = document.getElementById("grok-status")
    if (statusElement) {
      statusElement.className = `integration-status ${status}`
      statusElement.querySelector("span").textContent = text
    }
  }

  // Inicializar integração com Evolution API
  function initEvolutionAPIIntegration() {
    const apiUrlInput = document.getElementById("evolution-api-url")
    const apiKeyInput = document.getElementById("evolution-api-key")
    const instanceInput = document.getElementById("evolution-instance")
    const testButton = document.getElementById("test-evolution-btn")
    const saveButton = document.getElementById("save-evolution-btn")
    const statusElement = document.getElementById("evolution-status")

    // Carregar configuração salva
    const savedConfig = JSON.parse(localStorage.getItem("evolution_config") || "{}")
    if (savedConfig.apiUrl && savedConfig.apiKey) {
      apiUrlInput.value = savedConfig.apiUrl
      apiKeyInput.value = savedConfig.apiKey
      instanceInput.value = savedConfig.instance || ""
      updateEvolutionStatus("active", "Ativo")
    }

    // Evento de teste de conexão
    if (testButton) {
      testButton.addEventListener("click", () => {
        const apiUrl = apiUrlInput.value.trim()
        const apiKey = apiKeyInput.value.trim()
        const instance = instanceInput.value.trim()

        if (!apiUrl || !apiKey) {
          alert("Por favor, preencha a URL da API e a API Key.")
          return
        }

        // Atualizar status para "Testando..."
        updateEvolutionStatus("testing", "Testando...")

        // Testar conexão (simulação)
        testEvolutionConnection(apiUrl, apiKey, instance)
          .then((success) => {
            if (success) {
              updateEvolutionStatus("active", "Ativo")
              alert("Conexão com Evolution API estabelecida com sucesso!")
            } else {
              updateEvolutionStatus("inactive", "Inativo")
              alert("Falha ao conectar com Evolution API. Verifique suas credenciais.")
            }
          })
          .catch((error) => {
            updateEvolutionStatus("inactive", "Inativo")
            alert("Erro ao testar conexão: " + error.message)
          })
      })
    }

    // Evento de salvar configuração
    if (saveButton) {
      saveButton.addEventListener("click", () => {
        const apiUrl = apiUrlInput.value.trim()
        const apiKey = apiKeyInput.value.trim()
        const instance = instanceInput.value.trim()

        if (!apiUrl || !apiKey) {
          alert("Por favor, preencha a URL da API e a API Key.")
          return
        }

        // Salvar configuração
        const config = {
          apiUrl: apiUrl,
          apiKey: apiKey,
          instance: instance,
        }

        localStorage.setItem("evolution_config", JSON.stringify(config))

        alert("Configuração da Evolution API salva com sucesso!")
      })
    }
  }

  // Função para testar conexão com Evolution API
  async function testEvolutionConnection(apiUrl, apiKey, instance) {
    // Simulação
    return new Promise((resolve) => {
      setTimeout(() => {
        const success = apiUrl.includes("evolution-api") && apiKey.length > 10
        resolve(success)
      }, 1500)
    })
  }

  // Função para atualizar status da Evolution API
  function updateEvolutionStatus(status, text) {
    const statusElement = document.getElementById("evolution-status")
    if (statusElement) {
      statusElement.className = `integration-status ${status}`
      statusElement.querySelector("span").textContent = text
    }
  }

  // Inicializar integração com zAPI
  function initZAPIIntegration() {
    const instanceInput = document.getElementById("zapi-instance")
    const tokenInput = document.getElementById("zapi-token")
    const testButton = document.getElementById("test-zapi-btn")
    const saveButton = document.getElementById("save-zapi-btn")
    const statusElement = document.getElementById("zapi-status")

    // Carregar configuração salva
    const savedConfig = JSON.parse(localStorage.getItem("zapi_config") || "{}")
    if (savedConfig.instance && savedConfig.token) {
      instanceInput.value = savedConfig.instance
      tokenInput.value = savedConfig.token
      updateZAPIStatus("active", "Ativo")
    }

    // Evento de teste de conexão
    if (testButton) {
      testButton.addEventListener("click", () => {
        const instance = instanceInput.value.trim()
        const token = tokenInput.value.trim()

        if (!instance || !token) {
          alert("Por favor, preencha o ID da instância e o token.")
          return
        }

        // Atualizar status para "Testando..."
        updateZAPIStatus("testing", "Testando...")

        // Testar conexão (simulação)
        testZAPIConnection(instance, token)
          .then((success) => {
            if (success) {
              updateZAPIStatus("active", "Ativo")
              alert("Conexão com zAPI estabelecida com sucesso!")
            } else {
              updateZAPIStatus("inactive", "Inativo")
              alert("Falha ao conectar com zAPI. Verifique suas credenciais.")
            }
          })
          .catch((error) => {
            updateZAPIStatus("inactive", "Inativo")
            alert("Erro ao testar conexão: " + error.message)
          })
      })
    }

    // Evento de salvar configuração
    if (saveButton) {
      saveButton.addEventListener("click", () => {
        const instance = instanceInput.value.trim()
        const token = tokenInput.value.trim()

        if (!instance || !token) {
          alert("Por favor, preencha o ID da instância e o token.")
          return
        }

        // Salvar configuração
        const config = {
          instance: instance,
          token: token,
        }

        localStorage.setItem("zapi_config", JSON.stringify(config))

        alert("Configuração da zAPI salva com sucesso!")
      })
    }
  }

  // Função para testar conexão com zAPI
  async function testZAPIConnection(instance, token) {
    // Simulação
    return new Promise((resolve) => {
      setTimeout(() => {
        const success = instance.length > 5 && token.length > 10
        resolve(success)
      }, 1500)
    })
  }

  // Função para atualizar status da zAPI
  function updateZAPIStatus(status, text) {
    const statusElement = document.getElementById("zapi-status")
    if (statusElement) {
      statusElement.className = `integration-status ${status}`
      statusElement.querySelector("span").textContent = text
    }
  }

  // Inicializar integrações ao carregar a página
  initIntegrations()

  // Inicializar gerenciamento de webhooks
  initWebhooksManagement()
  // Inicializar modais
  initAddPromptModal()
  initAddTrainingModal()

  // Declaração das funções
  function openUserDetailsModal(userId) {
    alert(`Abrindo modal de detalhes do usuário ${userId}`)
  }

  function initKnowledgeList() {
    console.log("Inicializando lista de arquivos de conhecimento")
  }

  function loadPromptContent(testType, prompt) {
    console.log(`Carregando conteúdo do prompt para ${testType}`, prompt)
  }

  function generateUUID() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      var r = (Math.random() * 16) | 0,
        v = c == "x" ? r : (r & 0x3) | 0x8
      return v.toString(16)
    })
  }
})
