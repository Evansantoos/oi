# Documentação da Plataforma de Testes Comportamentais StartInc

## Visão Geral

A Plataforma de Testes Comportamentais StartInc é uma solução completa para diagnóstico comportamental de colaboradores e candidatos. A plataforma oferece múltiplos testes (DISC, Temperamento, Personalidade, Perfil Animal e Emoções) em três níveis de profundidade (Essência, Clareza e Verdade), com análise automatizada via inteligência artificial.

## Estrutura da Plataforma

A plataforma é composta por:

1. **Landing Page Pública**
   - Apresentação da plataforma e seus benefícios
   - Botão para cadastro e login
   - Informações sobre os testes disponíveis

2. **Sistema de Cadastro e Login**
   - Cadastro com informações detalhadas (nome, e-mail, telefone, profissão, segmento, cargo, CNPJ)
   - Login seguro com e-mail e senha
   - Recuperação de senha

3. **Painel de Usuário**
   - Visualização de testes disponíveis
   - Progresso visual dos testes realizados
   - Histórico de resultados
   - Acesso à Análise 360° (quando disponível)

4. **Fluxo de Testes**
   - Escolha do tipo de teste
   - Seleção do nível de profundidade
   - Apresentação das perguntas (uma por tela)
   - Exibição dos resultados
   - Opção para refazer testes

5. **Área Administrativa**
   - Visão geral de usuários e testes
   - Gerenciamento de prompts para cada teste
   - Upload de base de conhecimento
   - Configuração de integrações
   - Liberação de acessos gratuitos
   - Exportação de dados

## Funcionalidades Principais

### Para Usuários

1. **Testes Comportamentais**
   - DISC: Análise de Dominância, Influência, Estabilidade e Conformidade
   - Temperamento: Identificação de perfil Sanguíneo, Colérico, Melancólico ou Fleumático
   - Personalidade: Análise de traços de personalidade
   - Perfil Animal: Identificação como Águia, Lobo, Tubarão ou Gato
   - Emoções: Mapeamento de padrões emocionais

2. **Níveis de Profundidade**
   - Essência (básico): 10 perguntas, gratuito, 60% de precisão
   - Clareza (intermediário): 20 perguntas, premium, 80% de precisão
   - Verdade (avançado): 30 perguntas, premium, 99% de precisão + análise integrada

3. **Resultados e Relatórios**
   - Perfil dominante e secundário
   - Pontuação detalhada
   - Pontos fortes e a desenvolver
   - Resumo comportamental
   - Exportação em PDF
   - Envio por e-mail

4. **Análise 360°**
   - Disponível após completar todos os testes no Nível Verdade
   - Análise cruzada de todos os testes
   - Recomendações personalizadas baseadas nos objetivos do usuário

### Para Administradores

1. **Gerenciamento de Usuários**
   - Visualização de todos os usuários cadastrados
   - Detalhes de testes realizados
   - Liberação de acessos gratuitos
   - Adição de créditos de Análise 360°

2. **Gerenciamento de Prompts**
   - Edição de prompts para cada tipo de teste
   - Configuração de parâmetros (modelo, temperatura)
   - Teste de prompts

3. **Base de Conhecimento**
   - Upload de arquivos (.pdf, .txt, .docx, .md)
   - Associação a tipos de teste
   - Inclusão automática no contexto dos prompts

4. **Integrações**
   - OpenAI (GPT-4)
   - Evolution API (WhatsApp)
   - Webhooks personalizados
   - Google Sheets

5. **Planos e Monetização**
   - Configuração de planos e preços
   - Controle de créditos mensais
   - Opções de pagamento único ou recorrente

## Planos e Preços

1. **Nível Essência**: Gratuito
   - Acesso a todos os testes no nível básico (10 perguntas)
   - Resultados com 60% de precisão

2. **Nível Clareza**: R$ 37/mês
   - 3 testes no primeiro mês, 2 nos meses seguintes
   - Resultados com 80% de precisão
   - Exportação em PDF

3. **Nível Verdade**: R$ 127/mês
   - 5 testes no primeiro mês
   - Resultados com 99% de precisão
   - Análise detalhada
   - Exportação em PDF
   - Envio por WhatsApp

4. **Plano Completo**:
   - Todos os testes no Nível Verdade
   - Acesso à Análise 360°
   - Relatórios em PDF
   - Acesso vitalício ao histórico

## Controle de Acesso

- **Nível Essência**: Disponível gratuitamente, sem necessidade de login
- **Níveis Clareza e Verdade**: Exigem cadastro e plano ativo
- **Análise 360°**: Disponível 1 vez por mês para usuários com plano ativo
- **Compra Avulsa**: Opção para análises adicionais

## Integrações

1. **OpenAI (GPT-4)**
   - Análise das respostas dos testes
   - Geração de relatórios personalizados

2. **Evolution API (WhatsApp)**
   - Envio de resultados via WhatsApp
   - Notificações e lembretes

3. **Webhooks**
   - Integração com sistemas externos
   - Disparo de eventos ao finalizar testes

4. **Google Sheets**
   - Exportação automática de resultados
   - Armazenamento de dados para análise

## Requisitos Técnicos

- Navegador web moderno (Chrome, Firefox, Safari, Edge)
- Conexão com internet
- Dispositivo desktop, tablet ou smartphone

## Configuração Inicial

### Para Usuários

1. Acesse a landing page da plataforma
2. Clique em "Criar Conta" e preencha o formulário de cadastro
3. Faça login com suas credenciais
4. No painel de usuário, escolha um teste para iniciar
5. Selecione o nível de profundidade desejado
6. Responda às perguntas e visualize seus resultados

### Para Administradores

1. Acesse a página de login administrativa
2. Use as credenciais padrão: admin/disc2025
3. No painel administrativo, configure:
   - Chave da API OpenAI
   - Configurações do Evolution API (para WhatsApp)
   - Webhooks para integrações externas
   - URL da planilha Google Sheets
4. Faça upload de arquivos para a base de conhecimento
5. Personalize os prompts para cada tipo de teste

## Segurança e Privacidade

- Todas as senhas são armazenadas de forma criptografada
- Chaves de API são armazenadas com segurança
- Dados dos usuários são protegidos e não compartilhados
- Backups regulares garantem a preservação dos dados

## Suporte e Contato

Para suporte técnico ou dúvidas sobre a plataforma:

- E-mail: evandro@startcompanydigital.com
- WhatsApp: (51) 99149-0515
- Endereço: R. Gomes Jardim, 723 – Santana, Porto Alegre – RS
