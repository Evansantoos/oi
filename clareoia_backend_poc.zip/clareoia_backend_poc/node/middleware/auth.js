const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Configurações de JWT
const JWT_SECRET = process.env.JWT_SECRET || 'clareoia-secret-key';
const TOKEN_EXPIRY = '30m'; // 30 minutos

// Middleware de autenticação
const authMiddleware = async (req, res, next) => {
  try {
    // Verifica se o header de autorização existe
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        success: false, 
        message: 'Acesso não autorizado. Token não fornecido.' 
      });
    }
    
    // Extrai o token
    const token = authHeader.split(' ')[1];
    
    // Verifica o token
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // Busca o usuário no banco de dados
    const user = await User.findById(decoded.userId).select('-senha');
    
    if (!user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Usuário não encontrado.' 
      });
    }
    
    // Adiciona o usuário à requisição
    req.user = user;
    
    // Atualiza o último acesso
    user.ultimoAcesso = new Date();
    await user.save();
    
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        success: false, 
        message: 'Token expirado. Faça login novamente.' 
      });
    }
    
    return res.status(401).json({ 
      success: false, 
      message: 'Token inválido.' 
    });
  }
};

// Middleware para verificar se o usuário é admin
const adminMiddleware = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ 
      success: false, 
      message: 'Acesso negado. Permissão de administrador necessária.' 
    });
  }
  
  next();
};

module.exports = { authMiddleware, adminMiddleware };
