const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// Configurações de JWT
const JWT_SECRET = process.env.JWT_SECRET || 'clareoia-secret-key';
const TOKEN_EXPIRY = '30m'; // 30 minutos

// Rota de login
router.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    
    // Busca o usuário no banco de dados
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Usuário não encontrado' 
      });
    }
    
    // Verifica a senha
    const isMatch = await user.comparePassword(senha);
    
    if (!isMatch) {
      return res.status(401).json({ 
        success: false, 
        message: 'Senha incorreta' 
      });
    }
    
    // Gera o token JWT
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: TOKEN_EXPIRY }
    );
    
    // Atualiza o último acesso
    user.ultimoAcesso = new Date();
    await user.save();
    
    // Remove a senha do objeto de resposta
    const userResponse = {
      id: user._id,
      nome: user.nome,
      email: user.email,
      role: user.role
    };
    
    res.json({
      success: true,
      message: 'Login realizado com sucesso',
      token,
      user: userResponse
    });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erro no servidor' 
    });
  }
});

// Rota de registro
router.post('/register', async (req, res) => {
  try {
    const { nome, email, senha, role } = req.body;
    
    // Verifica se o usuário já existe
    const existingUser = await User.findOne({ email });
    
    if (existingUser) {
      return res.status(400).json({ 
        success: false, 
        message: 'Este email já está em uso' 
      });
    }
    
    // Cria o novo usuário
    const newUser = new User({
      nome,
      email,
      senha,
      role: role || 'user'
    });
    
    // Salva o usuário no banco de dados
    await newUser.save();
    
    // Gera o token JWT
    const token = jwt.sign(
      { userId: newUser._id, role: newUser.role },
      JWT_SECRET,
      { expiresIn: TOKEN_EXPIRY }
    );
    
    // Remove a senha do objeto de resposta
    const userResponse = {
      id: newUser._id,
      nome: newUser.nome,
      email: newUser.email,
      role: newUser.role
    };
    
    res.status(201).json({
      success: true,
      message: 'Usuário registrado com sucesso',
      token,
      user: userResponse
    });
  } catch (error) {
    console.error('Erro no registro:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erro no servidor' 
    });
  }
});

// Rota para verificar token
router.get('/verify', authMiddleware, (req, res) => {
  res.json({
    success: true,
    user: req.user
  });
});

// Rota para logout (apenas para registro no servidor)
router.post('/logout', authMiddleware, (req, res) => {
  // No JWT, o logout é gerenciado pelo cliente removendo o token
  // Esta rota serve apenas para registrar o logout no servidor
  res.json({
    success: true,
    message: 'Logout realizado com sucesso'
  });
});

// Rota para obter o usuário atual
router.get('/me', authMiddleware, (req, res) => {
  res.json({
    success: true,
    user: req.user
  });
});

// Rota para verificar se o usuário é admin
router.get('/admin', authMiddleware, adminMiddleware, (req, res) => {
  res.json({
    success: true,
    message: 'Usuário é administrador',
    user: req.user
  });
});

module.exports = router;
