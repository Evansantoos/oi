// Cliente de API para comunicação com o backend
const API_URL = '/api';

// Funções de gerenciamento de token
const setToken = (token) => {
  localStorage.setItem('clareoia_auth_token', token);
};

const getToken = () => {
  return localStorage.getItem('clareoia_auth_token');
};

const removeToken = () => {
  localStorage.removeItem('clareoia_auth_token');
};

// Configuração de headers para requisições autenticadas
const authHeaders = () => {
  const token = getToken();
  return {
    'Content-Type': 'application/json',
    'Authorization': token ? `Bearer ${token}` : ''
  };
};

// Cliente de API
const api = {
  // Autenticação
  login: async (email, senha) => {
    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, senha })
      });
      
      const data = await response.json();
      
      if (data.success && data.token) {
        setToken(data.token);
        localStorage.setItem('clareoia_current_user', JSON.stringify(data.user));
      }
      
      return data;
    } catch (error) {
      console.error('Erro no login:', error);
      return { success: false, message: 'Erro de conexão' };
    }
  },
  
  register: async (userData) => {
    try {
      const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
      });
      
      const data = await response.json();
      
      if (data.success && data.token) {
        setToken(data.token);
        localStorage.setItem('clareoia_current_user', JSON.stringify(data.user));
      }
      
      return data;
    } catch (error) {
      console.error('Erro no registro:', error);
      return { success: false, message: 'Erro de conexão' };
    }
  },
  
  logout: async () => {
    try {
      await fetch(`${API_URL}/auth/logout`, {
        method: 'POST',
        headers: authHeaders()
      });
      
      removeToken();
      localStorage.removeItem('clareoia_current_user');
      
      return { success: true };
    } catch (error) {
      console.error('Erro no logout:', error);
      
      // Mesmo com erro, remove o token localmente
      removeToken();
      localStorage.removeItem('clareoia_current_user');
      
      return { success: true };
    }
  },
  
  verificarAutenticacao: async () => {
    try {
      const response = await fetch(`${API_URL}/auth/verify`, {
        headers: authHeaders()
      });
      
      if (response.status === 401) {
        removeToken();
        localStorage.removeItem('clareoia_current_user');
        return false;
      }
      
      const data = await response.json();
      
      if (data.success) {
        // Atualiza os dados do usuário no localStorage
        localStorage.setItem('clareoia_current_user', JSON.stringify(data.user));
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Erro ao verificar autenticação:', error);
      return false;
    }
  },
  
  verificarAdmin: async () => {
    try {
      const response = await fetch(`${API_URL}/auth/admin`, {
        headers: authHeaders()
      });
      
      return response.status === 200;
    } catch (error) {
      console.error('Erro ao verificar admin:', error);
      return false;
    }
  },
  
  getUsuarioAtual: () => {
    const userJson = localStorage.getItem('clareoia_current_user');
    return userJson ? JSON.parse(userJson) : null;
  },
  
  // Usuários
  getUsuarios: async () => {
    try {
      const response = await fetch(`${API_URL}/users`, {
        headers: authHeaders()
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Erro ao obter usuários:', error);
      return { success: false, message: 'Erro de conexão' };
    }
  },
  
  // Prompts
  getPrompts: async () => {
    try {
      const response = await fetch(`${API_URL}/prompts`, {
        headers: authHeaders()
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Erro ao obter prompts:', error);
      return { success: false, message: 'Erro de conexão' };
    }
  },
  
  // Integrações
  validarAPI: async (provider, apiKey) => {
    try {
      const response = await fetch(`${API_URL}/integrations/validate`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ provider, apiKey })
      });
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Erro ao validar API:', error);
      return { success: false, message: 'Erro de conexão' };
    }
  }
};

// Exporta para uso global
window.api = api;
